# PokeCom (M1.1)

개인 플레이 전용 포켓몬 싱글 컴까기 PWA. GitHub Pages 로 배포한다.

## 규칙
- Pokémon Showdown `[Gen 9 Champions] BSS Reg M-C` (싱글, 6마리 중 3마리, Lv50)
- 기믹은 메가진화만 (테라스탈·Z기술·다이맥스 없음). Champions 에 나온 메가(Z-A·Z메가 포함)
- 능력 포인트(SP): 능력치당 최대 32, 합계 66. HP = 종족값+SP+75, 그 외 = (종족값+SP+20)×성격

## 구조
- `vendor/ps-sim.js` — Showdown master 시뮬레이터(Champions 모드) 브라우저 번들. `scripts/build-sim.mjs` 로 생성
- `src/core` — format(룰·능력치 계산), session(BattleStream 래퍼), view(프로토콜→한국어 로그), agents(랜덤 AI), teams(상대 파티·샘플 세트·검사), ko(한국어), store(설정·저장 파티)
- `src/ui` — home, builder(파티 짜기: 5열 포켓몬 표·기술 표·성격 5×5·SP), battle, settings
- `src/sprites.ts` — PokeAPI/sprites → IndexedDB (BW 애니 → Showdown 애니 → PNG)
- `src/data` — `scripts/gen-data.mjs` 가 만든 한국어 이름·설명(ko.json), 스프라이트 ID(sprites.json)

## 명령
```
npm install
npm run dev            # 개발 서버
npm run build          # dist/ (이 내용을 Pages 저장소 루트에 올린다)
npm run test:headless  # 랜덤 vs 랜덤 대전 N판 (N=100 npm run test:headless)

# 데이터 다시 만들기 (Showdown·PokeAPI 최신화할 때)
git clone --depth 1 https://github.com/smogon/pokemon-showdown /tmp/ps
PS_DIR=/tmp/ps npm run build:sim
# scripts/csv 에 PokeAPI CSV, /tmp/sprites-tree.txt 에 PokeAPI/sprites 파일 목록 필요 (gen-data.mjs 주석 참고)
PS_DIR=/tmp/ps npm run gen:data
```

## 출처
배틀 엔진 Pokémon Showdown (MIT), 스프라이트 PokeAPI/sprites, 한국어 Showdown 번역·PokeAPI. Pokémon © Nintendo · Creatures · GAME FREAK.
M1 소스는 배포 번들에서 복원했다(2026-09-26).
