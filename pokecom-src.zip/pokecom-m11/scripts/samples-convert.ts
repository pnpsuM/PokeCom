// 일본어 구축 기사 샘플(scripts/samples-raw/*.json) → 영어 세트 + 합법성 검사. PokeAPI CSV(CSV_DIR) 필요
// 사용: esbuild scripts/samples-convert.ts --bundle --platform=node --format=esm --outfile=.tmp/sc.mjs && CSV_DIR=<csv 폴더> node .tmp/sc.mjs scripts/samples-raw/*.json
// 일본어 샘플(json) → CuratedFile 세트 (영어 이름) + 합법성 검사
import fs from 'node:fs';
import { dex, STATS } from '../src/core/format';
import { toID } from '../src/sim';
import { validateSet, validateTeam, normalize } from '../src/core/teams';
const CSV = process.env.CSV_DIR || 'scripts/csv';
function csv(name: string) {
  const text = fs.readFileSync(`${CSV}/${name}.csv`, 'utf8'); const rows: string[][] = []; let row: string[] = [], cur = '', q = false;
  for (let i = 0; i < text.length; i++) { const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; continue; }
    if (c === '"') q = true; else if (c === ',') { row.push(cur); cur = ''; } else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.length > 1 || row[0]) rows.push(row); row = []; } else cur += c; }
  if (cur || row.length) { row.push(cur); rows.push(row); }
  const [cols, ...body] = rows; return body.map(r => Object.fromEntries(cols.map((c, i) => [c, r[i]])));
}
const JA = new Set(['1', '11']);
const norm = (s: string) => s.normalize('NFKC').replace(/[\s・]/g, '').replace(/[ァ-ン]/g, ''+'$&');
function table(base: string, names: string, key: string) {
  const ident = new Map(csv(base).map(r => [r.id, r.identifier]));
  const m = new Map<string, string>();
  for (const r of csv(names)) if (JA.has(r.local_language_id)) m.set(norm(r.name), ident.get(r[key])!);
  return m;
}
const SPEC = table('pokemon_species', 'pokemon_species_names', 'pokemon_species_id');
const MOVE = table('moves', 'move_names', 'move_id');
const ITEM = table('items', 'item_names', 'item_id');
const ABIL = table('abilities', 'ability_names', 'ability_id');
const NAT = table('natures', 'nature_names', 'nature_id');
const EXTRA_ITEM: Record<string, string> = {};
const miss: string[] = [];
function look(m: Map<string, string>, raw: string, kind: string, get: (id: string) => any) {
  const hit = m.get(norm(raw));
  const r = hit ? get(toID(hit)) : null;
  if (r?.exists) return r.name;
  miss.push(`${kind}:${raw}`); return '';
}
const FORMS: Record<string, string> = { 'ウォッシュロトム': 'Rotom-Wash', 'ヒートロトム': 'Rotom-Heat', 'フロストロトム': 'Rotom-Frost', 'スピンロトム': 'Rotom-Fan', 'カットロトム': 'Rotom-Mow',
  'フラエッテ(えいえんのはな)': 'Floette-Eternal', 'ルガルガン(まよなかのすがた)': 'Lycanroc-Midnight', 'ルガルガン(たそがれのすがた)': 'Lycanroc-Dusk', 'ストリンダー(ローなすがた)': 'Toxtricity-Low-Key',
  'ケンタロス(パルデアのすがたブレイズ種)': 'Tauros-Paldea-Blaze', 'ケンタロス(パルデアのすがたウォーター種)': 'Tauros-Paldea-Aqua', 'ニャオニクス(メス)': 'Meowstic-F', 'イエッサン(メス)': 'Indeedee-F', 'イエッサン(メスのすがた)': 'Indeedee-F', 'イダイトウ(メス)': 'Basculegion-F', 'イダイトウ(メスのすがた)': 'Basculegion-F' };
function species(raw: string) {
  const nk = raw.normalize('NFKC').replace(/\s/g, '');
  if (FORMS[nk.replace(/^メガ/, '')]) return FORMS[nk.replace(/^メガ/, '')];
  let s = nk;
  const regional0: Record<string, string> = { 'ヒスイ': '-Hisui', 'ガラル': '-Galar', 'アローラ': '-Alola', 'パルデア': '-Paldea' };
  let suffix = '';
  for (const [k, v] of Object.entries(regional0)) if (s.startsWith(k)) { suffix = v; s = s.slice(k.length); }
  if (suffix) { s = s.replace(/[(（].*?[)）]/g, ''); const h = SPEC.get(norm(s)); if (h && dex.species.get(h + suffix).exists) return dex.species.get(h + suffix).name; }
  let female = /[(（]?(メス|めす)/.test(s);
  s = s.replace(/[(（].*?[)）]/g, '');
  let hit = SPEC.get(norm(s));
  if (!hit) { s = s.replace(/^メガ/, '').replace(/[XYZ]$/, ''); hit = SPEC.get(norm(s)); }
  if (!hit) { miss.push('species:' + raw); return ''; }
  const regional: Record<string, string> = { 'ヒスイ': '-Hisui', 'ガラル': '-Galar', 'アローラ': '-Alola', 'パルデア': '-Paldea' };
  let name = dex.species.get(hit).name;
  for (const [k, v] of Object.entries(regional)) if (raw.includes(k)) name = dex.species.get(hit + v).name || name;
  if (female && dex.species.get(name + '-F').exists) name = name + '-F';
  return name;
}
function item(raw: string | null) {
  if (!raw) return '';
  const s = raw.normalize('NFKC');
  const hit = ITEM.get(norm(s));
  if (hit && dex.items.get(hit).exists) return dex.items.get(hit).name;
  // 새 메가스톤: "<종>ナイト[XYZ]" → dex 에서 megaStone 으로 찾기
  const m = s.match(/^(.*)ナイト([XYZ]?)$/);
  if (m) {
    for (const it of dex.items.all()) if (it.megaStone) {
      const bases = Object.keys(it.megaStone);
      const want = m[2];
      for (const b of bases) { const bk = [...SPEC].find(([k, v]) => toID(v) === toID(dex.species.get(b).baseSpecies)); if (!bk) continue;
        const ja = bk[0]; if ((ja.startsWith(m[1].slice(0, 2)) || m[1].startsWith(ja.slice(0, 2))) && (!want || it.name.endsWith(' ' + want))) return it.name; }
    }
  }
  miss.push('item:' + raw); return '';
}
function points(p: string) { const sp = [0, 0, 0, 0, 0, 0]; for (const [, k, v] of p.normalize('NFKC').matchAll(/([HABCDS])\s*(\d+)/g)) sp['HABCDS'.indexOf(k)] = +v; return sp; }
function inferNature(sp: number[], moves: string[]) {
  const [H, A, B, C, D, S] = sp; const cats = moves.map(m => dex.moves.get(m).category);
  const phys = cats.filter(c => c === 'Physical').length, spec = cats.filter(c => c === 'Special').length;
  const main = A >= C ? 'atk' : 'spa';
  const NAT: Record<string, string> = { 'atk+spa-': 'Adamant', 'spa+atk-': 'Modest', 'spe+spa-': 'Jolly', 'spe+atk-': 'Timid', 'def+atk-': 'Bold', 'def+spa-': 'Impish', 'spd+atk-': 'Calm', 'spd+spa-': 'Careful' };
  const minus = main === 'atk' ? (spec ? 'def' : 'spa') : (phys ? 'def' : 'atk');
  if (S >= 28 && Math.max(A, C) > 0) return NAT[`spe+${main === 'atk' ? 'spa' : 'atk'}-`];
  if (Math.max(A, C) >= 20) { if (S >= 28 && S >= Math.max(A, C) - 8 && !(H >= 28)) return NAT[`spe+${main === 'atk' ? 'spa' : 'atk'}-`]; return NAT[`${main}+${main === 'atk' ? 'spa' : 'atk'}-`]; }
  const def = B >= D ? 'def' : 'spd'; return NAT[`${def}+${phys > spec ? 'spa' : 'atk'}-`] ?? 'Bold';
}
const files = process.argv.slice(2);
const out: any[] = []; let bad = 0;
for (const f of files) {
  const src = JSON.parse(fs.readFileSync(f, 'utf8'));
  for (const t of src.teams) {
    miss.length = 0;
    const sets = t.members.map((m: any) => ({
      species: species(m.species), item: item(m.item), ability: look(ABIL, m.ability, 'ability', (i) => dex.abilities.get(i)),
      nature: m.nature ? look(NAT, m.nature, 'nature', (i) => dex.natures.get(i)) : '', sp: points(m.points),
      moves: m.moves.map((mv: string) => look(MOVE, mv, 'move', (i) => dex.moves.get(i))),
    }));
    for (const s of sets) if (!s.nature) { s.nature = inferNature(s.sp, s.moves); s.fixed = (s.fixed ? s.fixed + ', ' : '') + '성격 추정 ' + s.nature; }
    for (const s of sets) {
      const sp = dex.species.get(s.species);
      if (s.ability && sp.exists && !Object.values(sp.abilities).includes(s.ability)) { s.fixed = `특성 ${s.ability}→${sp.abilities[0]}`; s.ability = sp.abilities[0]; }
    }
    const team = sets.map((s: any) => normalize({ ...s, evs: Object.fromEntries(STATS.map((k, i) => [k, s.sp[i] ?? 0])) }));
    const probs = validateTeam(team);
    const tag = `${t.team} (${t.season} ${t.rank ?? ''})`;
    if (miss.length || probs) { bad++; console.log('✗', tag, miss.join(', '), probs?.join(' | ') ?? ''); }
    else console.log('✓', tag, sets.map((s: any) => s.species + '@' + (s.item || '-') + (s.fixed ? `[${s.fixed}]` : '')).join(', '));
    out.push({ ...t, source: src.source, url: t.url ?? src.url, sets, ok: !miss.length && !probs, problems: [...miss, ...(probs ?? [])] });
  }
}
fs.writeFileSync(process.env.OUT || '.tmp/converted.json', JSON.stringify(out, null, 1));
console.log('teams', out.length, 'bad', bad);
