// 한국어 이름·설명과 스프라이트 ID 맵을 만든다.
// 입력: PS_DIR(Showdown 소스, data/text/ko), scripts/csv(PokeAPI CSV), SPRITES_TREE(PokeAPI/sprites 파일 목록)
// 출력: src/data/ko.json, src/data/sprites.json
import fs from 'node:fs';
import path from 'node:path';
import { Dex, toID } from '../vendor/ps-sim.js';

const ROOT = path.resolve(import.meta.dirname, '..');
const PS = process.env.PS_DIR || '/tmp/ps';
const TREE = process.env.SPRITES_TREE || '/tmp/sprites-tree.txt';
const CSV = path.join(ROOT, 'scripts/csv');
const FORMAT = 'gen9championsbssregmc';
const dex = Dex.forFormat(Dex.formats.get(FORMAT));
const KO = 3; // PokeAPI local_language_id

// ---------- CSV ----------
function csv(name) {
	const text = fs.readFileSync(path.join(CSV, name + '.csv'), 'utf8');
	const rows = []; let row = [], cur = '', q = false;
	for (let i = 0; i < text.length; i++) {
		const c = text[i];
		if (q) { if (c === '"' && text[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; continue; }
		if (c === '"') q = true;
		else if (c === ',') { row.push(cur); cur = ''; }
		else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); cur = ''; if (row.length > 1 || row[0]) rows.push(row); row = []; }
		else cur += c;
	}
	if (cur || row.length) { row.push(cur); rows.push(row); }
	const [cols, ...body] = rows;
	return body.map(r => Object.fromEntries(cols.map((c, i) => [c, r[i]])));
}
// 한국어 설명: 가장 최신 버전 그룹의 도감 문구
function flavor(file, key) {
	const m = new Map();
	for (const r of csv(file)) {
		if (+r.language_id !== KO) continue;
		const id = +r[key], vg = +r.version_group_id;
		const prev = m.get(id);
		if (!prev || vg > prev.vg) m.set(id, { vg, text: r.flavor_text.replace(/\s*\n\s*/g, ' ').trim() });
	}
	return new Map([...m].map(([k, v]) => [k, v.text]));
}
const pokemonCsv = csv('pokemon');
const idByIdent = new Map(pokemonCsv.map(r => [r.identifier, +r.id]));
const koSpeciesById = new Map(csv('pokemon_species_names').filter(r => +r.local_language_id === KO).map(r => [+r.pokemon_species_id, r.name]));
const koNames = (file, key) => {
	const m = new Map();
	for (const r of csv(file)) if (+r.local_language_id === KO) m.set(+r[key], r.name);
	return m;
};
const koMoveById = koNames('move_names', 'move_id');
const koItemById = koNames('item_names', 'item_id');
const koAbilityById = koNames('ability_names', 'ability_id');

// ---------- Showdown ko 텍스트 (이름 + 공식 설명 주석) ----------
function parseText(file) {
	const src = fs.readFileSync(`${PS}/data/text/ko/${file}.ts`, 'utf8');
	const out = {};
	let cur = null, depth = 0;
	for (const line of src.split('\n')) {
		const m = line.match(/^\t([a-z0-9]+): \{/);
		if (m) { cur = out[m[1]] = {}; depth = 1; continue; }
		if (!cur) continue;
		if (/^\t\},?$/.test(line)) { cur = null; continue; }
		// 세대별 하위 블록(gen6: {...})은 건너뛴다
		if (/^\t\t\w+: \{/.test(line)) { depth++; continue; }
		if (depth > 1) { if (/^\t\t\},?$/.test(line)) depth--; continue; }
		let mm = line.match(/^\t\tname: "(.*)",/);
		if (mm) cur.name = mm[1];
		mm = line.match(/^\t\t\/\/ Official flavor text: "(.*)"$/);
		if (mm && !cur.desc) cur.desc = mm[1];
		mm = line.match(/^\t\tshortDesc: "(.*)",/);
		if (mm) cur.short = mm[1];
	}
	return out;
}
const tMoves = parseText('moves');
const tItems = parseText('items');
const tAbilities = parseText('abilities');
const tDex = parseText('pokedex');

// ---------- 종 ----------
const FORME_KO = {
	Mega: '메가', 'Mega-X': '메가 X', 'Mega-Y': '메가 Y', 'Mega-Z': '메가 Z',
	Alola: '알로라', Galar: '가라르', Hisui: '히스이', Paldea: '팔데아',
	'Paldea-Combat': '팔데아 컴뱃종', 'Paldea-Blaze': '팔데아 블레이즈종', 'Paldea-Aqua': '팔데아 워터종',
	F: '암컷', M: '수컷', 'M-Mega': '수컷 메가', 'F-Mega': '암컷 메가',
	Therian: '영물폼', Origin: '오리진폼', Sky: '스카이폼', Blade: '블레이드폼', Busted: '들킨 모습',
	Hero: '마이티폼', Hangry: '배고픈 모양', Noice: '나이스페이스', School: '군집의 모습', Zen: '달마모드',
	Pirouette: '스텝폼', Resolute: '각오의 모습', Crowned: '검왕', Eternal: '영원의 꽃', Complete: '퍼펙트폼',
	Dusk: '황혼의 갈기', Midnight: '한밤중의 모습', Low: '로우한 모습', 'Low-Key': '로우한 모습',
	'Rapid-Strike': '연격의 태세', Ice: '백마 탄 모습', Shadow: '흑마 탄 모습', Wellspring: '우물의 가면',
	Hearthflame: '화덕의 가면', Cornerstone: '주춧돌의 가면', Terastal: '테라스탈폼', Stellar: '스텔라폼',
	Bloodmoon: '붉은 달', Roaming: '도보폼', Four: '네 식구', Curly: '젖힌 모습', Droopy: '늘어진 모습',
	Stretchy: '뻗은 모습', Sunny: '태양의 모습', Rainy: '빗방울의 모습', Snowy: '설운의 모습',
	Heat: '히트', Wash: '워시', Frost: '프로스트', Fan: '스핀', Mow: '커트',
	Attack: '어택폼', Defense: '디펜스폼', Speed: '스피드폼', Sandy: '모래땅도롱', Trash: '슈레도롱',
	Sensu: '하늘하늘춤', 'Pom-Pom': '파칙파칙스타일', "Pa'u": '훌라훌라스타일',
	Dada: '아빠', Totem: '주인', Starter: '', Original: '오리지널', Bond: '유대', Ash: '지우',
	'Blue-Striped': '파랑줄무늬', 'White-Striped': '하양줄무늬', Galar_Zen: '가라르 달마모드',
	Gmax: '거다이맥스', Antique: '진작품', Artisan: '걸작품', Masterpiece: '걸작품', 'Blue': '파랑', 'Yellow': '노랑', 'Orange': '주황', 'White': '하양',
};
function koForme(forme) {
	if (FORME_KO[forme] !== undefined) return FORME_KO[forme];
	const parts = forme.split('-');
	if (parts.every(p => FORME_KO[p] !== undefined)) return parts.map(p => FORME_KO[p]).join(' ');
	return forme;
}
function koSpecies(s) {
	const id = s.id;
	if (tDex[id]?.name) return tDex[id].name;
	const base = dex.species.get(s.baseSpecies);
	const baseKo = tDex[base.id]?.name || koSpeciesById.get(base.num) || base.name;
	if (!s.forme) return baseKo;
	// 겉모습만 다른 폼(마휘핑 크림 등)은 기본 이름
	if (base.cosmeticFormes?.includes(s.name)) return baseKo;
	const f = koForme(s.forme);
	if (!f) return baseKo;
	if (/^메가|^알로라|^가라르|^히스이|^팔데아|^수컷 메가|^암컷 메가/.test(f)) {
		if (f.startsWith('수컷 메가') || f.startsWith('암컷 메가')) return `메가${baseKo}(${f.slice(0, 2)})`;
		const m = f.match(/^메가(?: ([XYZ]))?$/);
		if (m) return `메가${baseKo}${m[1] ?? ''}`;
		return `${f.split(' ')[0]} ${baseKo}${f.includes(' ') ? `(${f.split(' ').slice(1).join(' ')})` : ''}`;
	}
	return `${baseKo}(${f})`;
}

// 대상 종: champions 에서 쓸 수 있는 종 + 그 폼 전부
const legal = dex.species.all().filter(s => !s.isNonstandard && s.tier !== 'Illegal' && !s.battleOnly);
const bases = new Set(legal.map(s => s.baseSpecies));
const allSpecies = dex.species.all().filter(s => bases.has(s.baseSpecies) && s.exists).sort((a, b) => (a.forme ? 1 : 0) - (b.forme ? 1 : 0));
const speciesKo = {};
for (const s of allSpecies) speciesKo[s.id] = koSpecies(s);

// ---------- 스프라이트 ID ----------
const tree = fs.readFileSync(TREE, 'utf8').split('\n');
const has = new Set(tree);
const P = 'sprites/pokemon';
const m1 = JSON.parse(fs.readFileSync(path.join(ROOT, 'scripts/m1-sprite-map.json'), 'utf8'));
function identOf(s) {
	let n = s.name.toLowerCase().replace(/[.’':%]/g, '').replace(/é/g, 'e').replace(/ /g, '-');
	const fix = {
		'meowstic-m-mega': 'meowstic-male-mega', 'meowstic-f-mega': 'meowstic-female-mega', 'meowstic-f': 'meowstic-female',
		'indeedee-f': 'indeedee-female', 'basculegion-f': 'basculegion-female', 'oinkologne-f': 'oinkologne-female',
		'tauros-paldea-combat': 'tauros-paldea-combat-breed', 'tauros-paldea-blaze': 'tauros-paldea-blaze-breed',
		'tauros-paldea-aqua': 'tauros-paldea-aqua-breed', 'lycanroc': 'lycanroc-midday', 'toxtricity': 'toxtricity-amped',
		'mimikyu': 'mimikyu-disguised', 'mimikyu-busted': 'mimikyu-busted', 'aegislash': 'aegislash-shield',
		'palafin': 'palafin-zero', 'morpeko': 'morpeko-full-belly', 'eiscue': 'eiscue-ice', 'eiscue-noice': 'eiscue-noice',
		'wishiwashi': 'wishiwashi-solo', 'darmanitan': 'darmanitan-standard', 'maushold': 'maushold-family-of-three',
		'maushold-four': 'maushold-family-of-four', 'tatsugiri': 'tatsugiri-curly', 'squawkabilly': 'squawkabilly-green-plumage',
		'indeedee': 'indeedee-male', 'basculegion': 'basculegion-male', 'oinkologne': 'oinkologne-male', 'meowstic': 'meowstic-male',
		'dudunsparce': 'dudunsparce-two-segment', 'floette-mega': 'floette-mega', 'urshifu': 'urshifu-single-strike',
		'gourgeist': 'gourgeist-average', 'pumpkaboo': 'pumpkaboo-average', 'minior': 'minior-red-meteor', 'zygarde': 'zygarde-50',
		'enamorus': 'enamorus-incarnate', 'landorus': 'landorus-incarnate', 'thundurus': 'thundurus-incarnate', 'tornadus': 'tornadus-incarnate',
		'keldeo': 'keldeo-ordinary', 'meloetta': 'meloetta-aria', 'giratina': 'giratina-altered', 'shaymin': 'shaymin-land', 'deoxys': 'deoxys-normal',
		'wormadam': 'wormadam-plant', 'basculin': 'basculin-red-striped', 'oricorio': 'oricorio-baile', 'oricorio-pau': 'oricorio-pau',
		'castform': 'castform', 'rotom-fan': 'rotom-fan', 'sinistcha': 'sinistcha', 'poltchageist': 'poltchageist',
	};
	return fix[n] ?? n;
}
const sprites = {};
let missing = [];
for (const s of allSpecies) {
	let pid = idByIdent.get(identOf(s)) ?? (s.forme ? 0 : s.num);
	if (!pid && m1[s.id]?.p) pid = m1[s.id].p;
	const bw = [];
	const bwKey = m1[s.id]?.bw ?? [];
	for (const k of bwKey) if (has.has(`${P}/versions/generation-v/black-white/animated/${k}.gif`)) bw.push(k);
	if (!bw.length && !s.forme && s.num <= 649 && has.has(`${P}/versions/generation-v/black-white/animated/${s.num}.gif`)) bw.push(String(s.num));
	const sd = pid > 0 && has.has(`${P}/other/showdown/${pid}.gif`);
	const png = pid > 0 && has.has(`${P}/${pid}.png`);
	if (!bw.length && !sd && !png) {
		// 스프라이트가 없는 폼은 기본 모습으로
		const base = dex.species.get(s.baseSpecies);
		if (base.id !== s.id && sprites[base.id]) { sprites[s.id] = sprites[base.id]; continue; }
		missing.push(s.name);
	}
	sprites[s.id] = { n: s.num, p: pid, bw, sd: sd ? 1 : 0, png: png ? 1 : 0 };
}

// ---------- 기술·도구·특성 ----------
const moveIdByIdent = new Map(csv('move_names').filter(r => +r.local_language_id === 9).map(r => [toID(r.name), +r.move_id]));
const itemIdByIdent = new Map(csv('item_names').filter(r => +r.local_language_id === 9).map(r => [toID(r.name), +r.item_id]));
const abilityIdByIdent = new Map(csv('ability_names').filter(r => +r.local_language_id === 9).map(r => [toID(r.name), +r.ability_id]));
const koMoveFlavor = flavor('move_flavor_text', 'move_id');
const koItemFlavor = flavor('item_flavor_text', 'item_id');
const koAbilityFlavor = flavor('ability_flavor_text', 'ability_id');
const table = (all, t, byIdent, koById, flav) => {
	const names = {}, desc = {};
	for (const x of all) {
		const name = t[x.id]?.name || koById.get(byIdent.get(x.id)) || null;
		if (name) names[x.id] = name;
		const d = t[x.id]?.short || t[x.id]?.desc || flav.get(byIdent.get(x.id));
		if (d) desc[x.id] = d;
	}
	return [names, desc];
};
const movesAll = dex.moves.all().filter(m => !m.isNonstandard || m.isNonstandard === 'Unobtainable');
const itemsAll = dex.items.all().filter(i => !i.isNonstandard);
const abilitiesAll = dex.abilities.all().filter(a => !a.isNonstandard && a.id !== 'noability');
const [moves, moveDesc] = table(movesAll, tMoves, moveIdByIdent, koMoveById, koMoveFlavor);
const [items, itemDesc] = table(itemsAll, tItems, itemIdByIdent, koItemById, koItemFlavor);
const [abilities, abilityDesc] = table(abilitiesAll, tAbilities, abilityIdByIdent, koAbilityById, koAbilityFlavor);
// 메가스톤 이름 보충 (예: 가브리아스나이트Z)
for (const i of itemsAll) {
	if (items[i.id] || !i.megaStone) continue;
	const [base, mega] = Object.entries(i.megaStone)[0];
	const bko = speciesKo[toID(base)] ?? base;
	items[i.id] = `${bko}나이트${/-Z$/.test(mega) ? 'Z' : /-X$/.test(mega) ? 'X' : /-Y$/.test(mega) ? 'Y' : ''}`;
}

const types = { bug: '벌레', dark: '악', dragon: '드래곤', electric: '전기', fairy: '페어리', fighting: '격투', fire: '불꽃', flying: '비행', ghost: '고스트', grass: '풀', ground: '땅', ice: '얼음', normal: '노말', poison: '독', psychic: '에스퍼', rock: '바위', steel: '강철', water: '물', stellar: '스텔라' };
const natures = { hardy: '노력', bold: '대담', modest: '조심', calm: '차분', timid: '겁쟁이', lonely: '외로움', docile: '온순', mild: '의젓', gentle: '얌전', hasty: '성급', adamant: '고집', impish: '장난꾸러기', bashful: '수줍음', careful: '신중', rash: '덜렁', jolly: '명랑', naughty: '개구쟁이', lax: '촐랑', quirky: '변덕', naive: '천진난만', brave: '용감', relaxed: '무사태평', quiet: '냉정', sassy: '건방', serious: '성실' };

const ko = { species: speciesKo, moves, items, abilities, types, natures, moveDesc, abilityDesc, itemDesc };
fs.mkdirSync(path.join(ROOT, 'src/data'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'src/data/ko.json'), JSON.stringify(ko));
fs.writeFileSync(path.join(ROOT, 'src/data/sprites.json'), JSON.stringify(sprites));

const miss = (all, names) => all.filter(x => !names[x.id]).map(x => x.name);
console.log('species', Object.keys(speciesKo).length, 'legal', legal.length, 'sprites missing', missing.length, missing.slice(0, 20).join(', '));
console.log('moves', Object.keys(moves).length, '/', movesAll.length, 'missing:', miss(movesAll, moves).slice(0, 15).join(', '));
console.log('items', Object.keys(items).length, '/', itemsAll.length, 'missing:', miss(itemsAll, items).slice(0, 25).join(', '));
console.log('abilities', Object.keys(abilities).length, '/', abilitiesAll.length, 'missing:', miss(abilitiesAll, abilities).join(', '));
console.log('desc', Object.keys(moveDesc).length, Object.keys(itemDesc).length, Object.keys(abilityDesc).length);
const untranslated = Object.entries(speciesKo).filter(([, v]) => /[A-Za-z]/.test(v)).map(([k, v]) => v);
console.log('species w/ latin', untranslated.length, untranslated.slice(0, 40).join(', '));
