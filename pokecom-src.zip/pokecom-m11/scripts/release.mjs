// 릴리스: 빌드 → releases/v<버전>/ 에 전체본·올릴 파일(바뀐 것만)·변경 목록·소스 zip
// 사용: npm run release            (비교 기준 = releases/DEPLOYED 에 적힌, 마지막으로 올린 버전)
//       npm run release -- --base releases/v1.2.0/full   (비교 기준 직접 지정)
//       npm run release -- --full   (비교 없이 전부 올리기)
// 올린 뒤: npm run mark-deployed   (이 버전을 "배포됨"으로 기록 → 다음 릴리스의 비교 기준)
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execSync } from 'node:child_process';

const ROOT = path.resolve(import.meta.dirname, '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const args = process.argv.slice(2);
const opt = (k) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : undefined; };

// 1) 버전: src/config/version.ts 가 기준, package.json 을 맞춘다
const version = read('src/config/version.ts').match(/APP_VERSION = '([^']+)'/)[1];
const pkg = JSON.parse(read('package.json'));
if (pkg.version !== version) { pkg.version = version; fs.writeFileSync(path.join(ROOT, 'package.json'), JSON.stringify(pkg, null, 2) + '\n'); console.log(`package.json 버전 → ${version}`); }

// 2) 시뮬레이터 커밋 확인
const simCommit = read('src/config/manifest.ts').match(/commit: '([0-9a-f]+)'/)?.[1];
const vendorCommit = read('vendor/PS_COMMIT').trim();
if (simCommit !== vendorCommit) { console.error(`✗ manifest 시뮬레이터 커밋(${simCommit})과 vendor/PS_COMMIT(${vendorCommit})이 다르다. npm run build:sim 또는 manifest 수정`); process.exit(1); }

// 3) 빌드
console.log(`v${version} 빌드 중…`);
execSync('npx vite build', { cwd: ROOT, stdio: ['ignore', 'ignore', 'inherit'] });

const REL = path.join(ROOT, 'releases');
const out = path.join(REL, `v${version}`);
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(path.join(out, 'full'), { recursive: true });
fs.cpSync(path.join(ROOT, 'dist'), path.join(out, 'full'), { recursive: true });

// 4) 소스 zip (배포본 안에도 pokecom-src.zip 으로)
const srcZip = path.join(out, `pokecom-src-v${version}.zip`);
execSync(`cd .. && zip -qr ${JSON.stringify(srcZip)} ${path.basename(ROOT)} -x '*/node_modules/*' '*/dist/*' '*/releases/*' '*/.tmp/*' '*/scripts/.ps-*' '*/scripts/shims/*'`, { cwd: ROOT });
fs.copyFileSync(srcZip, path.join(out, 'full', 'pokecom-src.zip'));

// 5) 비교 기준
const sha = (f) => crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
const list = (dir) => { const r = {}; const walk = (d, pre = '') => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const rel = pre + e.name; if (e.isDirectory()) walk(path.join(d, e.name), rel + '/'); else r[rel] = path.join(d, e.name); } }; walk(dir); return r; };
let baseDir = opt('--base');
let baseName = baseDir;
if (!baseDir && !args.includes('--full')) {
	const dep = fs.existsSync(path.join(REL, 'DEPLOYED')) ? fs.readFileSync(path.join(REL, 'DEPLOYED'), 'utf8').trim() : '';
	if (dep && dep !== `v${version}` && fs.existsSync(path.join(REL, dep, 'full'))) { baseDir = path.join(REL, dep, 'full'); baseName = dep; }
}
const now = list(path.join(out, 'full'));
const before = baseDir ? list(path.resolve(ROOT, baseDir)) : {};
const changed = [], same = [];
for (const [rel, f] of Object.entries(now)) {
	if (before[rel] && sha(before[rel]) === sha(f)) same.push(rel); else changed.push(rel);
}
const unused = Object.keys(before).filter((r) => !now[r]);
fs.mkdirSync(path.join(out, 'upload'), { recursive: true });
for (const rel of changed) { fs.mkdirSync(path.dirname(path.join(out, 'upload', rel)), { recursive: true }); fs.copyFileSync(now[rel], path.join(out, 'upload', rel)); }

// 6) 변경 목록
const kb = (f) => (fs.statSync(f).size / 1024).toFixed(0) + 'KB';
const role = (n) => n.startsWith('sim-') ? '시뮬레이터' : n.startsWith('data-ko') ? '한국어 데이터' : n.startsWith('data-sprites') ? '스프라이트 번호표' : n.startsWith('data-ratings') ? 'AI 레이팅' : n.startsWith('config-') ? '정책·룰·버전' : n.startsWith('ai-') ? 'AI 판단' : n.startsWith('index-') ? '앱 화면·로직' : n.startsWith('DungGeunMo') ? '글꼴' : '';
const md = [
	`# PokeCom v${version} 릴리스`,
	'',
	`- 비교 기준: ${baseName ? baseName : '없음 (전체 올리기)'}`,
	`- 올릴 파일 ${changed.length}개 (upload/ 폴더), 그대로인 파일 ${same.length}개`,
	'',
	'## 올릴 파일 (upload/ 안의 파일 전부를 저장소 루트에 업로드)',
	...changed.sort().map((r) => `- ${r} (${kb(now[r])})${role(r) ? ' — ' + role(r) : ''}`),
	'',
	'## 그대로인 파일 (올릴 필요 없음)',
	...(same.length ? same.sort().map((r) => `- ${r}`) : ['- (없음)']),
	'',
	'## 더 이상 안 쓰는 파일 (저장소에 남아 있어도 무해, 지워도 됨)',
	...(unused.length ? unused.sort().map((r) => `- ${r}`) : ['- (없음)']),
	'',
];
fs.writeFileSync(path.join(out, 'CHANGES.md'), md.join('\n'));
console.log(md.join('\n'));
console.log(`→ ${path.relative(ROOT, out)}/  (full/ 전체본, upload/ 올릴 파일, CHANGES.md, 소스 zip)`);
