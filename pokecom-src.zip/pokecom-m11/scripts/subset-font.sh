#!/bin/sh
# 둥근모꼴 부분 글꼴 만들기 (한글 KS X 1001 2350자 + 앱 데이터·소스에 쓰인 글자)
# 필요: pip install fonttools brotli, npm pack @noonnu/dung-geun-mo
set -e
SRC=${1:-/tmp/fontpk/package/fonts/dunggeunmo-normal.woff}
python3 - <<'PY'
import glob
chars=set()
for b1 in range(0xB0,0xC9):
    for b2 in range(0xA1,0xFF):
        try: chars.add(bytes([b1,b2]).decode('euc-kr'))
        except: pass
for f in glob.glob('src/**/*.ts',recursive=True)+glob.glob('src/**/*.json',recursive=True)+['index.html']:
    chars|=set(open(f,encoding='utf-8').read())
chars|=set(chr(c) for c in range(0x20,0x7f))|set('·…—–→←↑↓♂♀×½¼¾%「」“”‘’')
open('/tmp/glyphs.txt','w',encoding='utf-8').write(''.join(sorted(c for c in chars if ord(c)>=0x20)))
PY
pyftsubset "$SRC" --text-file=/tmp/glyphs.txt --flavor=woff2 --output-file=src/assets/DungGeunMo.woff2 --layout-features='*'
ls -la src/assets/DungGeunMo.woff2
