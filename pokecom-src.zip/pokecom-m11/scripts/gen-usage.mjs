// Smogon chaos json → 줄인 사용률 파일 (src/data/usage/<format>-<month>-<cutoff>.json)
// 사용: node scripts/gen-usage.mjs <chaos.json 경로 또는 URL> [--month 2026-08] [--cutoff 1630] [--top 120]
//   예) node scripts/gen-usage.mjs https://www.smogon.com/stats/2026-08/chaos/gen9championsbssregmb-1630.json
// 만든 뒤 src/data/usage/index.ts 에 import 한 줄을 추가한다 (data-usage 조각만 바뀜)
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..');
const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf(k); return i >= 0 ? args[i + 1] : d; };
const src = args[0];
if (!src) { console.error('chaos json 경로 또는 URL 이 필요하다'); process.exit(1); }
const text = /^https?:/.test(src) ? await (await fetch(src)).text() : fs.readFileSync(src, 'utf8');
const chaos = JSON.parse(text);
const m = src.match(/(\d{4}-\d{2})\/chaos\/([a-z0-9]+)-(\d+)\.json/);
const month = opt('--month', m?.[1] ?? 'unknown');
const format = m?.[2] ?? chaos.info?.metagame ?? 'gen9championsbssregmb';
const cutoff = +opt('--cutoff', m?.[3] ?? chaos.info?.cutoff ?? 0);
const TOP = +opt('--top', 120);

const norm = (obj, k) => {
	const e = Object.entries(obj ?? {}).filter(([n, w]) => w > 0 && n !== 'nothing' && n !== '');
	const total = e.reduce((a, [, w]) => a + w, 0) || 1;
	return e.sort((a, b) => b[1] - a[1]).slice(0, k).map(([n, w]) => [n, Math.round((w / total) * 1000) / 1000]);
};
const species = Object.entries(chaos.data)
	.map(([name, d]) => ({ name, d, usage: d.usage ?? 0 }))
	.sort((a, b) => b.usage - a.usage).slice(0, TOP)
	.map(({ name, d, usage }) => ({
		name, usage: Math.round(usage * 10000) / 10000,
		abilities: norm(d.Abilities, 4), items: norm(d.Items, 8),
		// "Jolly:2/32/0/0/0/32" → ['Jolly', [2,32,0,0,0,32], w]  (Champions 는 EVs 칸 = SP)
		spreads: norm(d.Spreads, 6).map(([k, w]) => { const [nat, ev] = k.split(':'); return [nat, ev.split('/').map(Number), w]; }),
		moves: norm(d.Moves, 14), teammates: norm(d.Teammates, 12),
	}));
const out = { format, month, cutoff, battles: chaos.info?.['number of battles'] ?? 0, species };
const file = path.join(ROOT, 'src/data/usage', `${format}-${month}-${cutoff}.json`);
fs.writeFileSync(file, JSON.stringify(out));
console.log(`${path.relative(ROOT, file)}: ${species.length}종, ${(fs.statSync(file).size / 1024).toFixed(0)}KB, 배틀 ${out.battles}`);
console.log(species.slice(0, 15).map(s => `${s.name} ${(s.usage * 100).toFixed(1)}%`).join(', '));
