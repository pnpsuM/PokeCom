// pkmnchamps.com 랭커 파티(API showdown_slots 줄인 형식) → src/data/samples/pkmnchamps.json (CuratedFile)
// 입력: scripts/samples-raw/pkmnchamps.json  [{ id, t(제목), o(작성자), d(날짜), u(원문 링크), s: ["종;도구;특성;성격;HP/A/B/C/D/S;기술,기술,…"] }]
// 사용: npx tsx scripts/pkmnchamps-convert.ts
import fs from 'node:fs';
import path from 'node:path';
import { dex, STATS, type PokemonSet } from '../src/core/format';
import { validateTeam } from '../src/core/teams';

const ROOT = path.resolve(import.meta.dirname, '..');
const raw = JSON.parse(fs.readFileSync(path.join(ROOT, 'scripts/samples-raw/pkmnchamps.json'), 'utf8'));
const id = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

// 사이트 표기 → 시뮬레이터 이름 (틀린 철자·폼 표기)
const ITEM_FIX: Record<string, string> = { dragonitite: 'dragoninite', dragoniteite: 'dragoninite', dragonitenite: 'dragoninite', floettenite: 'floettite' };
function speciesOf(name: string, ability: string, moves: string[]): string {
	let n = name.replace(/-mega(-[xy])?$/, '').replace(/-(shield|male)$/, '');
	if (n === 'rotom' && moves.includes('hydro-pump')) n = 'rotom-wash';
	if (n === 'samurott' && (ability === 'sharpness' || moves.includes('ceaseless-edge'))) n = 'samurott-hisui';
	const sp = dex.species.get(n);
	return sp.exists ? sp.name : '';
}
function abilityOf(species: string, ab: string): string {
	const sp = dex.species.get(species);
	const legal = Object.values(sp.abilities as Record<string, string>);
	const a = dex.abilities.get(ab);
	// 메가 전 특성이 아닌 값(메가 특성 등)이면 기본 특성으로
	return a.exists && legal.includes(a.name) ? a.name : legal[0];
}

const out: any[] = []; const dropped: string[] = [];
for (const p of raw) {
	const sets: any[] = [];
	for (const line of p.s as string[]) {
		const [pk, item, ab, nature, evs, mv] = line.split(';');
		const moves = mv.split(',');
		const species = speciesOf(pk, ab, moves);
		const it = item ? dex.items.get(ITEM_FIX[id(item)] ?? item) : null;
		sets.push({
			species, item: it?.exists ? it.name : '', ability: species ? abilityOf(species, ab) : '',
			nature: dex.natures.get(nature).name, sp: evs.split('/').map(Number), moves: moves.map((m) => dex.moves.get(m).name),
		});
	}
	const team: PokemonSet[] = sets.map((s) => ({ name: '', species: s.species, item: s.item, ability: s.ability, nature: s.nature, gender: '', level: 50,
		evs: Object.fromEntries(STATS.map((k, i) => [k, s.sp[i] ?? 0])) as any, ivs: Object.fromEntries(STATS.map((k) => [k, 31])) as any, moves: s.moves } as PokemonSet));
	const bad = sets.some((s) => !s.species) ? ['알 수 없는 종'] : validateTeam(team);
	const rate = p.t.match(/^\[(\d{4})\]/)?.[1] ?? '';
	const title = p.t.replace(/^\[\d{4}\]\s*/, '');
	if (bad) { dropped.push(`${p.t}: ${bad.join(' / ')}`); continue; }
	out.push({ id: `pkmnchamps-${p.id.slice(0, 8)}`, title, season: p.d.slice(0, 7), rank: rate ? `R${rate}` : '', url: p.u, original: p.t, author: p.o, sets });
}
const file = {
	source: 'pkmnchamps.com 랭커 파티 (싱글)', short: 'pkmnchamps', linkLabel: '출처', collectedAt: new Date().toISOString().slice(0, 10),
	note: 'pkmnchamps.com/en/archive 의 싱글 랭커 파티(레이트 순). 메가진화 후 특성으로 적힌 칸은 메가 전 특성으로 바꿈. 규칙 검사에 걸린 파티는 뺌',
	parties: out,
};
fs.writeFileSync(path.join(ROOT, 'src/data/samples/pkmnchamps.json'), JSON.stringify(file) + '\n');
console.log(`통과 ${out.length} / ${raw.length}`);
for (const d of dropped) console.log('  제외:', d);
