// 대체 빌드 (Vite 를 설치할 수 없는 환경용): esbuild 로 dist/ 를 만든다.
// 결과 구조는 Vite 빌드와 같다: 평평한 dist/, index.html, sw.js, public/ 파일, 조각(sim·data-*·config·ai·index).
// 사용: node scripts/build-esbuild.mjs   (ESBUILD_PATH, JSZIP_DIR 환경 변수로 위치 지정 가능)
// 조각: esbuild 는 공유 코드를 "진입점" 단위로 나누므로, 조각마다 진입점을 하나씩 둔다.
//       안 바뀐 조각은 내용이 같아 파일 이름(해시)도 그대로 남는다.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';

const ROOT = path.resolve(import.meta.dirname, '..');
const require = createRequire(import.meta.url);
const esbuild = require(process.env.ESBUILD_PATH || 'esbuild');
const OUT = path.join(ROOT, 'dist');

// 앱 진입점 + 조각 진입점 (조각 진입점 파일은 해당 모듈을 다시 내보내기만 한다)
const GROUPS = {
	sim: 'vendor/ps-sim.js',
	'data-ko': 'src/data/ko.json',
	'data-sprites': 'src/data/sprites.json',
	'data-ratings': 'src/data/ratings/champions-bss-regmc.json',
	'data-samples': 'src/data/samples/index.ts',
	config: 'src/config/manifest.ts',
	ai: 'src/core/ai/agent.ts',
};

fs.rmSync(OUT, { recursive: true, force: true });
const result = await esbuild.build({
	absWorkingDir: ROOT,
	entryPoints: { index: 'src/main.ts', ...GROUPS },
	bundle: true, splitting: true, format: 'esm', platform: 'browser', target: 'es2022',
	outdir: OUT, entryNames: '[name]-[hash]', chunkNames: 'chunk-[hash]', assetNames: '[name]-[hash]',
	minify: false, keepNames: true, // L3 탐색(State)이 클래스 이름을 쓴다 — 압축·이름 바꾸기 금지
	loader: { '.woff2': 'file', '.png': 'file', '.svg': 'file' },
	define: { 'import.meta.env.PROD': 'true', 'import.meta.env.DEV': 'false' },
	nodePaths: [process.env.JSZIP_DIR || path.join(ROOT, 'node_modules')],
	metafile: true, logLevel: 'warning', charset: 'utf8', legalComments: 'none',
});

// 조각 이름 붙이기: chunk-<해시>.js 를 담긴 모듈에 따라 sim-/data-*/config-/ai-/lib- 로 바꾸고,
// 다시 내보내기만 하는 조각 진입점 파일은 지운다 (아무도 불러오지 않는다)
const NAME_RULES = [
	['sim', /^vendor\/ps-sim/], ['data-ko', /^src\/data\/ko\.json/], ['data-sprites', /^src\/data\/sprites\.json/],
	['data-ratings', /^src\/data\/ratings\//], ['data-samples', /^src\/data\/samples\//], ['config', /^src\/config\//],
	['ai', /^src\/core\/ai\//], ['lib', /node_modules/],
];
const rel = (p) => path.relative(OUT, path.join(ROOT, p));
const renames = {};
for (const [p, o] of Object.entries(result.metafile.outputs)) {
	const f = rel(p);
	if (o.entryPoint && Object.values(GROUPS).includes(o.entryPoint) && f.endsWith('.js')) { renames[f] = null; continue; }
	if (!/^chunk-/.test(f)) continue;
	// 가장 큰 모듈 기준으로 이름을 정한다
	const top = Object.entries(o.inputs).sort((a, b) => b[1].bytesInOutput - a[1].bytesInOutput)[0]?.[0] ?? '';
	const hit = NAME_RULES.find(([, re]) => re.test(top));
	renames[f] = (hit ? hit[0] : 'app') + f.slice('chunk'.length);
}
for (const [from, to] of Object.entries(renames)) {
	if (to === null) fs.rmSync(path.join(OUT, from)); else fs.renameSync(path.join(OUT, from), path.join(OUT, to));
}
for (const f of fs.readdirSync(OUT).filter(f => f.endsWith('.js'))) {
	let s = fs.readFileSync(path.join(OUT, f), 'utf8'), changed = false;
	for (const [from, to] of Object.entries(renames)) if (to && s.includes(from)) { s = s.split(from).join(to); changed = true; }
	if (changed) fs.writeFileSync(path.join(OUT, f), s);
}
const renamed = (f) => (f in renames ? renames[f] : f);

// public/ 복사
for (const f of fs.readdirSync(path.join(ROOT, 'public'))) fs.copyFileSync(path.join(ROOT, 'public', f), path.join(OUT, f));

// index.html: 진입 스크립트·CSS·조각 미리 받기
const outs = Object.keys(result.metafile.outputs).map(p => renamed(path.relative(OUT, path.join(ROOT, p)))).filter(Boolean);
const indexJs = outs.find(f => /^index-.*\.js$/.test(f));
const css = outs.filter(f => f.endsWith('.css'));
const jsAll = outs.filter(f => f.endsWith('.js'));
// index 가 정적으로 가져오는 파일만 modulepreload
const meta = result.metafile.outputs[path.relative(ROOT, path.join(OUT, indexJs))];
const statics = (meta.imports || []).filter(i => i.kind === 'import-statement').map(i => renamed(path.relative(OUT, path.join(ROOT, i.path)))).filter(Boolean);
let html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const head = [
	`  <script type="module" crossorigin src="./${indexJs}"></script>`,
	...statics.map(f => `  <link rel="modulepreload" crossorigin href="./${f}">`),
	...css.map(f => `  <link rel="stylesheet" crossorigin href="./${f}">`),
].join('\n');
html = html.replace(/\s*<script type="module" src="\/src\/main.ts"><\/script>/, '').replace('</head>', head + '\n</head>');
fs.writeFileSync(path.join(OUT, 'index.html'), html);

// sw.js (Vite 플러그인과 같은 방식: 파일 목록 해시 = 캐시 버전)
function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }
const files = ['./', 'index.html', 'manifest.webmanifest', 'icon.svg', 'icon-192.png', 'icon-180.png', ...outs.filter(f => !f.endsWith('.map'))];
const uniq = [...new Set(files)];
const version = hash(JSON.stringify([...uniq].sort()));
const tpl = fs.readFileSync(path.join(ROOT, 'scripts/sw.template.js'), 'utf8');
fs.writeFileSync(path.join(OUT, 'sw.js'), tpl.replace('__VERSION__', version).replace('__FILES__', JSON.stringify(uniq)));

const size = (f) => (fs.statSync(path.join(OUT, f)).size / 1024).toFixed(0) + 'KB';
console.log(outs.map(f => `${f} ${size(f)}`).join('\n'));
console.log(`js ${jsAll.length}개, css ${css.length}개 → dist/`);
