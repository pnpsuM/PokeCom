// 지금 버전(또는 인자로 준 버전)을 "저장소에 올림"으로 기록한다. 다음 npm run release 의 비교 기준이 된다.
// 사용: npm run mark-deployed            (src/config/version.ts 의 버전)
//       npm run mark-deployed -- v1.2.0
import fs from 'node:fs';
import path from 'node:path';
const ROOT = path.resolve(import.meta.dirname, '..');
const v = process.argv[2] ?? 'v' + fs.readFileSync(path.join(ROOT, 'src/config/version.ts'), 'utf8').match(/APP_VERSION = '([^']+)'/)[1];
if (!fs.existsSync(path.join(ROOT, 'releases', v, 'full'))) console.warn(`주의: releases/${v}/full 이 없다. 다음 릴리스는 전체 올리기가 된다 (PC 보관본을 releases/${v}/full 에 넣으면 비교 가능)`);
fs.mkdirSync(path.join(ROOT, 'releases'), { recursive: true });
fs.writeFileSync(path.join(ROOT, 'releases', 'DEPLOYED'), v + '\n');
console.log(`배포됨으로 기록: ${v}`);
