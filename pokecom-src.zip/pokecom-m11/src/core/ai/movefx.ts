// 기술 효과를 시뮬레이터 데이터(Dex)에서 읽어 AI 가 쓰는 형태로 정리한다.
// 이름 목록으로 판단하지 않는다. 데이터에 드러나지 않는(함수로만 구현된) 소수의 기술만 EXCEPTIONS 에 적는다.
import { toID } from '../../sim';
import { dex } from '../format';

export type Boosts = Partial<Record<'atk' | 'def' | 'spa' | 'spd' | 'spe' | 'accuracy' | 'evasion', number>>;

export interface MoveFx {
  id: string; name: string; type: string;
  category: 'Physical' | 'Special' | 'Status';
  priority: number;
  acc: number;                       // 0~1 (반드시 맞는 기술은 1)
  targetsFoe: boolean;               // 상대를 겨냥하는가 (방어·도발·대타 판정용)
  selfBoosts?: Boosts;               // 사용자 능력 변화 (칼춤, 인파이트의 방어 하락 등)
  foeBoosts?: Boosts;                // 상대 능력 변화 (애교 등)
  status?: string;                   // 확정 상태이상 (도깨비불 등)
  secondaryStatus?: { status: string; chance: number };
  flinchChance?: number;
  volatile?: string;                 // substitute, taunt, leechseed, protect, curse …
  heal?: number;                     // 최대 HP 대비 회복 비율
  drain?: number;                    // 준 데미지 대비 회복 비율
  recoil?: number;                   // 준 데미지 대비 반동 비율
  selfdestruct?: boolean;
  sideCondition?: string; sideTarget?: 'foe' | 'self';
  weather?: string; terrain?: string; pseudoWeather?: string;
  selfSwitch?: boolean; forceSwitch?: boolean;
  protect?: boolean;
  special?: string;                  // EXCEPTIONS 의 처리 이름
}

/** 데이터만으로는 효과가 드러나지 않는 기술 (함수로 구현됨) */
const EXCEPTIONS: Record<string, Partial<MoveFx>> = {
  moonlight: { heal: 0.5, special: 'weatherheal' }, synthesis: { heal: 0.5, special: 'weatherheal' }, morningsun: { heal: 0.5, special: 'weatherheal' },
  shoreup: { heal: 0.5 }, rest: { special: 'rest' }, painsplit: { special: 'painsplit' },
  bellydrum: { special: 'bellydrum' }, curse: { special: 'curse' },
  defog: { special: 'defog' }, rapidspin: { special: 'rapidspin' },
  knockoff: { special: 'knockoff' }, partingshot: { foeBoosts: { atk: -1, spa: -1 } },
  fakeout: { special: 'firstturn' }, firstimpression: { special: 'firstturn' },
  trick: { special: 'trick' }, switcheroo: { special: 'trick' },
  yawn: { special: 'yawn' }, haze: { special: 'haze' }, clearsmog: { special: 'clearfoe' },
  suckerpunch: { special: 'sucker' }, focuspunch: { special: 'focuspunch' },
  wish: { heal: 0.5 }, strengthsap: { heal: 0.4, foeBoosts: { atk: -1 } },
};

const cache = new Map<string, MoveFx>();
export function moveFx(name: string): MoveFx {
  const id = toID(name);
  const hit = cache.get(id);
  if (hit) return hit;
  const m = dex.moves.get(id);
  const fx: MoveFx = {
    id: m.id, name: m.name, type: m.type, category: m.category as MoveFx['category'], priority: m.priority,
    acc: m.accuracy === true ? 1 : (m.accuracy || 100) / 100,
    targetsFoe: !['self', 'allySide', 'all', 'foeSide', 'allyTeam', 'adjacentAlly', 'adjacentAllyOrSelf'].includes(m.target),
  };
  if (m.id.startsWith('hiddenpower') && m.id.length > 11) {
    const t = m.id.slice(11).replace(/\d+$/, '');
    fx.type = t.charAt(0).toUpperCase() + t.slice(1);
  }
  if (m.boosts) { if (m.target === 'self' || m.target === 'adjacentAllyOrSelf') fx.selfBoosts = m.boosts as Boosts; else fx.foeBoosts = m.boosts as Boosts; }
  if (m.self?.boosts) fx.selfBoosts = m.self.boosts as Boosts;
  if (m.status) fx.status = m.status;
  const sec = m.secondary;
  if (sec?.status) fx.secondaryStatus = { status: sec.status, chance: (sec.chance ?? 100) / 100 };
  if (sec?.volatileStatus === 'flinch') fx.flinchChance = (sec.chance ?? 100) / 100;
  if (m.volatileStatus) fx.volatile = m.volatileStatus;
  if (m.stallingMove) fx.protect = true;
  if (m.heal) fx.heal = m.heal[0] / m.heal[1];
  if (m.drain) fx.drain = m.drain[0] / m.drain[1];
  if (m.recoil) fx.recoil = m.recoil[0] / m.recoil[1];
  if (m.selfdestruct) fx.selfdestruct = true;
  if (m.sideCondition) { fx.sideCondition = m.sideCondition; fx.sideTarget = m.target === 'foeSide' ? 'foe' : 'self'; }
  if (m.weather) fx.weather = m.weather;
  if (m.terrain) fx.terrain = m.terrain;
  if (m.pseudoWeather) fx.pseudoWeather = m.pseudoWeather;
  if (m.selfSwitch) fx.selfSwitch = true;
  if (m.forceSwitch) fx.forceSwitch = true;
  Object.assign(fx, EXCEPTIONS[m.id] ?? {});
  cache.set(id, fx);
  return fx;
}

/** 상태이상이 걸리는가 (타입 면역만 본다) */
export function statusImmune(status: string, types: string[], moveId = ''): boolean {
  if (status === 'brn') return types.includes('Fire');
  if (status === 'par') return types.includes('Electric') || (moveId === 'thunderwave' && types.includes('Ground'));
  if (status === 'psn' || status === 'tox') return types.includes('Poison') || types.includes('Steel');
  if (status === 'frz') return types.includes('Ice');
  if (status === 'slp' && ['spore', 'sleeppowder'].includes(moveId)) return types.includes('Grass');
  return false;
}
