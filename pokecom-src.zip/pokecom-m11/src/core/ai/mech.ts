// 규칙 계산 창구: 데미지·스피드를 Showdown 시뮬레이터(Champions 규칙)에서 직접 얻는다.
// 가능한 상황(월드)마다 계산 전용 배틀을 하나 만들고, 질문할 때마다 그 상황으로 포켓몬 상태를 맞춘다.
import { Battle, Teams, toID } from '../../sim';
import { FORMAT, type PokemonSet } from '../format';

export interface MechMon { key: string; set: PokemonSet }
export interface MechState {
	key: string; species: string; hp: number; status: string; boosts: Record<string, number>; itemGone?: boolean; item?: string;
	/** 바뀐 타입 (변환자재 등). 없으면 종족 타입 */
	types?: string[];
	/** 지금 특성 id (메가 폼 반영). 변환자재·리베로 판정용 */
	ability?: string;
	/** 변환자재·리베로를 이미 썼는지 */
	shiftUsed?: boolean;
}
const TYPE_SHIFT = ['protean', 'libero'];
export interface MechField { weather: string; terrain: string; screens: [Record<string, number>, Record<string, number>] }

const ROLL_AVG = 7;   // 85~100% 난수 중 가운데
const ROLL_MIN = 15;

export class Mech {
	b: any;
	private byKey = new Map<string, any>();
	private cache = new Map<string, { avg: number; min: number }>();
	private roll = ROLL_AVG;

	constructor(sides: [MechMon[], MechMon[]]) {
		const b: any = new Battle({ formatid: FORMAT.id });
		const pack = (ms: MechMon[]) => Teams.pack(ms.map(m => ({ ...m.set, name: m.key, evs: { ...m.set.evs }, ivs: { ...m.set.ivs }, moves: [...m.set.moves] })));
		b.setPlayer('p1', { name: 'A', team: pack(sides[0]) });
		b.setPlayer('p2', { name: 'B', team: pack(sides[1]) });
		b.randomChance = () => false;                     // 급소 없음
		b.randomizer = (d: number) => Math.trunc(Math.trunc(d * (100 - this.roll)) / 100);
		for (const side of [b.p1, b.p2]) for (const p of side.pokemon) this.byKey.set(`${side.id}:${p.name}`, p);
		this.b = b;
	}

	private sync(sideIdx: 0 | 1, s: MechState) {
		const side = sideIdx === 0 ? this.b.p1 : this.b.p2;
		const p = this.byKey.get(`${side.id}:${s.key}`);
		if (!p) return null;
		if (p.species.name !== s.species) { try { p.formeChange(s.species, null, true); } catch { /* 폼 불가 */ } }
		if (side.active[0] !== p) { if (side.active[0]) side.active[0].isActive = false; side.active[0] = p; p.isActive = true; p.position = 0; }
		p.hp = Math.max(1, Math.round((p.maxhp * s.hp) / 100));
		p.status = s.status || '';
		p.boosts = { atk: 0, def: 0, spa: 0, spd: 0, spe: 0, accuracy: 0, evasion: 0, ...s.boosts };
		p.item = s.itemGone ? '' : toID(s.item ?? p.set.item);
		p.types = s.types?.length ? [...s.types] : [...p.species.types];
		p.addedType = '';
		return p;
	}
	private syncField(f: MechField, defSide: 0 | 1 | null) {
		const field = this.b.field;
		const w = toID(f.weather); const t = toID(f.terrain);
		if (field.weather !== w) { field.weather = w; field.weatherState = { id: w }; }
		if (field.terrain !== t) { field.terrain = t; field.terrainState = { id: t }; }
		for (const si of [0, 1] as const) {
			const side = si === 0 ? this.b.p1 : this.b.p2;
			for (const k of ['reflect', 'lightscreen', 'auroraveil', 'tailwind']) {
				const on = (f.screens[si][k] ?? 0) > 0 && (k === 'tailwind' || defSide === null || defSide === si);
				if (on && !side.sideConditions[k]) side.sideConditions[k] = { id: k, target: side, duration: 3 };
				else if (!on && side.sideConditions[k]) delete side.sideConditions[k];
			}
		}
	}

	/** att 가 move 로 def 에게 주는 데미지 (def 최대 HP 대비 %) */
	damage(att: MechState, def: MechState, attSide: 0 | 1, move: string, f: MechField): { avg: number; min: number } {
		const key = `${attSide}|${att.key}|${att.species}|${att.types?.join() ?? ''}|${att.shiftUsed ? 1 : 0}|${def.types?.join() ?? ''}|${JSON.stringify(att.boosts)}|${att.status}|${att.itemGone ? 1 : 0}|${att.item ?? ''}|${Math.round(att.hp / 10)}|` +
			`${def.key}|${def.species}|${JSON.stringify(def.boosts)}|${def.status}|${def.itemGone ? 1 : 0}|${def.item ?? ''}|${Math.round(def.hp / 10)}|${move}|${f.weather}|${f.terrain}|${JSON.stringify(f.screens[1 - attSide])}`;
		const hit = this.cache.get(key);
		if (hit) return hit;
		let out = { avg: 0, min: 0 };
		try {
			this.syncField(f, (1 - attSide) as 0 | 1);
			const a = this.sync(attSide, att); const d = this.sync((1 - attSide) as 0 | 1, def);
			if (a && d) {
				const mv = this.b.dex.getActiveMove(toID(move));
				const hits = typeof mv.multihit === 'number' ? mv.multihit : Array.isArray(mv.multihit) ? (a.hasAbility?.('skilllink') ? mv.multihit[1] : 3.1) : 1;
				// 특성·기술 효과로 바뀌는 타입(스카이스킨 등)을 실제 규칙대로 반영
				const typed = () => { const m = this.b.dex.getActiveMove(toID(move)); this.b.singleEvent('ModifyType', m, null, a, d, m, m); this.b.runEvent('ModifyType', a, d, m, m); return m; };
				// 변환자재·리베로: 쓰기 직전 기술 타입이 되므로 자속 보정을 받는다
				if (!att.shiftUsed && TYPE_SHIFT.includes(toID(att.ability ?? ''))) { const t = typed().type; if (t && t !== '???') a.types = [t]; }
				this.roll = ROLL_AVG;
				const avg = this.b.actions.getDamage(a, d, typed(), true);
				this.roll = ROLL_MIN;
				const min = this.b.actions.getDamage(a, d, typed(), true);
				this.roll = ROLL_AVG;
				const toPct = (x: unknown) => (typeof x === 'number' && x > 0 ? (x * hits / d.maxhp) * 100 : 0);
				out = { avg: toPct(avg), min: toPct(min) };
			}
		} catch { /* 계산 불가 기술 = 0 */ }
		this.b.log.length = 0;
		if (this.cache.size > 30000) this.cache.clear();
		this.cache.set(key, out);
		return out;
	}

	/** att 가 move 를 쓸 때의 실제 타입 (특성·기술 효과 반영) */
	moveType(att: MechState, attSide: 0 | 1, move: string, f: MechField): string {
		let t = '';
		try {
			this.syncField(f, null);
			const a = this.sync(attSide, att);
			const side = attSide === 0 ? this.b.p2 : this.b.p1;
			const m = this.b.dex.getActiveMove(toID(move));
			if (a) { this.b.singleEvent('ModifyType', m, null, a, side.active[0], m, m); this.b.runEvent('ModifyType', a, side.active[0], m, m); }
			t = m.type;
		} catch { /* 원래 타입 */ }
		this.b.log.length = 0;
		return t;
	}

	/** 행동 스피드 (랭크·도구·특성·마비·순풍·날씨 반영) */
	speed(s: MechState, sideIdx: 0 | 1, f: MechField): number {
		try {
			this.syncField(f, null);
			const p = this.sync(sideIdx, s);
			return p ? p.getStat('spe') : 0;
		} catch { return 0; }
	}

	/** 최대 HP 실수치 (%, 회복량 계산 등) */
	maxhp(sideIdx: 0 | 1, key: string): number {
		const side = sideIdx === 0 ? this.b.p1 : this.b.p2;
		return this.byKey.get(`${side.id}:${key}`)?.maxhp ?? 100;
	}
}
