// "가능한 상황(월드)": 숨은 정보까지 채운 판 전체. 0번 편 = 판단하는 AI, 1번 편 = 상대.
// L1·L2 는 여기의 근사 턴 진행(step)을, L3 는 실제 시뮬레이터를 쓴다. 평가는 모두 evaluate.ts 의 같은 함수.
import { toID } from '../../sim';
import { dex, type PokemonSet } from '../format';
import type { Mech, MechState, MechField } from './mech';
import { moveFx, statusImmune, type Boosts } from './movefx';

export interface WMon {
  key: string;            // 편 안에서 고유 (요청 순서 인덱스 등)
  set: PokemonSet;
  hp: number;             // 0~100 (%)
  status: string;
  alive: boolean;
  boosts: Boosts;
  vol: Record<string, number>;   // substitute, taunt, leechseed, yawn …
  itemGone?: boolean;
  lastMove?: string;
  activeTurns: number;
}
export interface WSide {
  mons: WMon[];
  active: number;
  hazards: { stealthrock: number; spikes: number; toxicspikes: number; stickyweb: number };
  screens: { reflect: number; lightscreen: number; auroraveil: number; tailwind: number };
  megaUsed: boolean; zUsed: boolean;
}
export interface World {
  sides: [WSide, WSide];
  weather: string; weatherTurns: number;
  terrain: string; terrainTurns: number;
  trickRoom: number;
  turn: number;
  /** 규칙 계산기 (이 상황의 파티로 만든 계산 전용 배틀, 복사해도 공유) */
  mech: Mech;
}

export type WAction =
  | { kind: 'move'; move: string; mega?: boolean; z?: boolean; choice?: string }
  | { kind: 'switch'; to: number; choice?: string }
  | { kind: 'pass' };

// ---------- 복사 ----------
export function cloneWorld(w: World): World {
  return {
    ...w,
    sides: w.sides.map((s) => ({
      ...s,
      hazards: { ...s.hazards }, screens: { ...s.screens },
      mons: s.mons.map((m) => ({ ...m, boosts: { ...m.boosts }, vol: { ...m.vol }, set: m.set })),
    })) as [WSide, WSide],
  };
}

export const activeOf = (s: WSide) => s.mons[s.active];
export const aliveCount = (s: WSide) => s.mons.filter((m) => m.alive).length;
export function typesOf(m: WMon): string[] { return dex.species.get(m.set.species).types; }

// ---------- 계산기 연결 ----------
export function mechState(m: WMon): MechState {
  return { key: m.key, species: m.set.species, hp: m.hp, status: m.status, boosts: m.boosts as Record<string, number>, itemGone: m.itemGone, item: m.set.item };
}
export function fieldOf(w: World): MechField {
  return { weather: w.weather, terrain: w.terrain, screens: [w.sides[0].screens, w.sides[1].screens] as MechField['screens'] };
}
/** attacker → defender 기대 데미지 (% of defender max HP), 명중률 반영 */
export function expectedDamage(w: World, attSide: 0 | 1, move: string, _z = false): { avg: number; min: number } {
  const A = w.sides[attSide], D = w.sides[1 - attSide];
  const a = activeOf(A), d = activeOf(D);
  if (!a?.alive || !d?.alive) return { avg: 0, min: 0 };
  const fx = moveFx(move);
  if (fx.category === 'Status') return { avg: 0, min: 0 };
  const r = w.mech.damage(mechState(a), mechState(d), attSide, move, fieldOf(w));
  return { avg: r.avg * fx.acc, min: r.min };
}
export function bestDamage(w: World, attSide: 0 | 1): number {
  const a = activeOf(w.sides[attSide]);
  if (!a?.alive) return 0;
  let best = 0;
  for (const mv of a.set.moves) best = Math.max(best, expectedDamage(w, attSide, mv).avg);
  return best;
}

export function speed(w: World, side: 0 | 1): number {
  const m = activeOf(w.sides[side]);
  if (!m?.alive) return 0;
  return w.mech.speed(mechState(m), side, fieldOf(w));
}
/** +1: side0 먼저, -1: side1 먼저 */
export function order(w: World, pri0: number, pri1: number): number {
  if (pri0 !== pri1) return pri0 > pri1 ? 1 : -1;
  let a = speed(w, 0), b = speed(w, 1);
  if (w.trickRoom > 0) { a = -a; b = -b; }
  return a === b ? (w.turn % 2 ? 1 : -1) : a > b ? 1 : -1;
}

// ---------- 교체 ----------
function effRock(types: string[]) { return Math.pow(2, dex.getEffectiveness('Rock', types)); }

export function switchIn(w: World, sideIdx: 0 | 1, to: number) {
  const s = w.sides[sideIdx];
  const out = activeOf(s);
  if (out) { out.boosts = {}; out.vol = {}; out.activeTurns = 0; if (toID(out.set.ability) === 'regenerator' && out.alive) out.hp = Math.min(100, out.hp + 33); if (toID(out.set.ability) === 'naturalcure') out.status = ''; }
  s.active = to;
  const m = activeOf(s);
  m.activeTurns = 0;
  const types = typesOf(m);
  const grounded = !types.includes('Flying') && toID(m.set.ability) !== 'levitate' && toID(m.set.item) !== 'airballoon';
  if (toID(m.set.item) !== 'heavydutyboots') {
    if (s.hazards.stealthrock) m.hp -= 12.5 * effRock(types);
    if (grounded && s.hazards.spikes) m.hp -= [0, 12.5, 16.7, 25][Math.min(3, s.hazards.spikes)];
    if (grounded && s.hazards.toxicspikes && !m.status && !statusImmune('psn', types)) {
      if (types.includes('Poison')) s.hazards.toxicspikes = 0; else m.status = s.hazards.toxicspikes >= 2 ? 'tox' : 'psn';
    }
    if (grounded && s.hazards.stickyweb) m.boosts.spe = (m.boosts.spe ?? 0) - 1;
  }
  if (m.hp <= 0) { m.hp = 0; m.alive = false; return; }
  // 등장 특성 (위협, 날씨)
  const ab = toID(m.set.ability);
  const foe = activeOf(w.sides[1 - sideIdx]);
  if (ab === 'intimidate' && foe?.alive && !['clearbody', 'hypercutter', 'whitesmoke', 'fullmetalbody'].includes(toID(foe.set.ability))) foe.boosts.atk = Math.max(-6, (foe.boosts.atk ?? 0) - 1);
  const wx: Record<string, string> = { drizzle: 'RainDance', drought: 'SunnyDay', sandstream: 'Sandstorm', snowwarning: 'Hail' };
  if (wx[ab]) { w.weather = wx[ab]; w.weatherTurns = 5; }
  const tx: Record<string, string> = { electricsurge: 'Electric Terrain', psychicsurge: 'Psychic Terrain', grassysurge: 'Grassy Terrain', mistysurge: 'Misty Terrain' };
  if (tx[ab]) { w.terrain = tx[ab]; w.terrainTurns = 5; }
}

/** 기절·교체 기술 후 들어갈 포켓몬: 상대에게 주는 데미지 − 받는 데미지가 가장 큰 쪽 */
export function bestReplacement(w: World, sideIdx: 0 | 1): number {
  const s = w.sides[sideIdx];
  let best = -1, bestScore = -Infinity;
  s.mons.forEach((m, i) => {
    if (!m.alive || i === s.active) return;
    const t = cloneWorld(w); t.sides[sideIdx].active = i;
    const sc = bestDamage(t, sideIdx) - bestDamage(t, (1 - sideIdx) as 0 | 1) + m.hp * 0.2;
    if (sc > bestScore) { bestScore = sc; best = i; }
  });
  return best;
}

// ---------- 한 턴 근사 진행 (기대값 기반, 결정적) ----------
const BOOST_KEYS = ['atk', 'def', 'spa', 'spd', 'spe', 'accuracy', 'evasion'] as const;
function applyBoosts(m: WMon, b: Boosts | undefined, mult = 1) {
  if (!b) return;
  const contrary = toID(m.set.ability) === 'contrary';
  for (const k of BOOST_KEYS) {
    const v = b[k]; if (!v) continue;
    m.boosts[k] = Math.max(-6, Math.min(6, (m.boosts[k] ?? 0) + Math.round(v * mult * (contrary ? -1 : 1))));
  }
}

function useMove(w: World, u: 0 | 1, act: Extract<WAction, { kind: 'move' }>, protectedFoe: boolean, flinched: boolean) {
  const U = w.sides[u], T = w.sides[1 - u];
  const me = activeOf(U), foe = activeOf(T);
  if (!me?.alive) return;
  const fx = moveFx(act.move);
  me.lastMove = fx.id;
  if (flinched) return;
  if (me.status === 'slp') { me.vol.sleepTurns = (me.vol.sleepTurns ?? 0) + 1; if (me.vol.sleepTurns < 2) return; me.status = ''; me.vol.sleepTurns = 0; }
  if (me.status === 'frz') return;
  let eff = me.status === 'par' ? 0.75 : 1; // 마비: 25% 행동 불가를 기대값으로
  if (me.vol.taunt && fx.category === 'Status') return;
  if (fx.special === 'firstturn' && me.activeTurns > 0) return;
  if (fx.protect) { return; } // 방어는 턴 시작에 처리
  if (fx.targetsFoe && protectedFoe) return;
  const acc = fx.acc * eff;
  const foeTypes = foe ? typesOf(foe) : [];
  // 데미지
  if (fx.category !== 'Status' && foe?.alive) {
    const d = expectedDamage(w, u, act.move, act.z);
    let dealt = Math.min(foe.hp, d.avg * eff);
    if (foe.vol.substitute && !act.z) { foe.vol.substitute = 0; dealt = 0; }
    foe.hp -= dealt;
    if (fx.drain) me.hp = Math.min(100, me.hp + dealt * fx.drain);
    if (fx.recoil) me.hp -= dealt * fx.recoil;
    if (!me.itemGone && toID(me.set.item) === 'lifeorb' && dealt > 0) me.hp -= 10;
    if (fx.special === 'knockoff' && dealt > 0) foe.itemGone = true;
    if (fx.secondaryStatus && !foe.status && foe.hp > 0 && fx.secondaryStatus.chance * acc >= 0.5 && !statusImmune(fx.secondaryStatus.status, foeTypes)) foe.status = fx.secondaryStatus.status;
    applyBoosts(me, fx.selfBoosts, acc >= 0.5 ? 1 : 0);
    if (fx.foeBoosts && foe.hp > 0) applyBoosts(foe, fx.foeBoosts, acc);
  } else {
    // 변화 기술
    if (fx.status && foe?.alive && !foe.status && !foe.vol.substitute && acc >= 0.7 && !statusImmune(fx.status, foeTypes, fx.id)) {
      if (fx.status === 'slp' && w.sides[1 - u].mons.some((m) => m.status === 'slp')) { /* 수면 클로즈 */ } else foe.status = fx.status;
    }
    if (fx.selfBoosts) applyBoosts(me, fx.selfBoosts);
    if (fx.foeBoosts && foe?.alive && !foe.vol.substitute && acc >= 0.5) applyBoosts(foe, fx.foeBoosts);
    if (fx.heal) {
      let h = fx.heal * 100;
      if (fx.special === 'weatherheal') h = /sunny/i.test(w.weather) ? 66.7 : w.weather ? 25 : 50;
      me.hp = Math.min(100, me.hp + h);
    }
    switch (fx.special) {
      case 'rest': if (me.hp < 100) { me.hp = 100; me.status = 'slp'; me.vol.sleepTurns = 0; } break;
      case 'painsplit': if (foe?.alive) { const avg = (me.hp + foe.hp) / 2; me.hp = avg; foe.hp = avg; } break;
      case 'bellydrum': if (me.hp > 50) { me.hp -= 50; me.boosts.atk = 6; } break;
      case 'curse': if (typesOf(me).includes('Ghost')) { me.hp -= 50; if (foe) foe.vol.curse = 1; } else applyBoosts(me, { atk: 1, def: 1, spe: -1 }); break;
      case 'defog': T.hazards = { stealthrock: 0, spikes: 0, toxicspikes: 0, stickyweb: 0 }; U.hazards = { stealthrock: 0, spikes: 0, toxicspikes: 0, stickyweb: 0 }; T.screens.reflect = T.screens.lightscreen = T.screens.auroraveil = 0; break;
      case 'haze': for (const s of w.sides) { const a = activeOf(s); if (a) a.boosts = {}; } break;
      case 'yawn': if (foe && !foe.status) foe.vol.yawn = 2; break;
      case 'trick': if (foe) { const x = me.set.item; me.set = { ...me.set, item: foe.set.item }; foe.set = { ...foe.set, item: x }; } break;
    }
    if (fx.volatile && fx.volatile !== 'protect') {
      if (fx.volatile === 'substitute') { if (me.hp > 25 && !me.vol.substitute) { me.hp -= 25; me.vol.substitute = 1; } }
      else if (foe && fx.targetsFoe && acc >= 0.7) { if (!(fx.volatile === 'leechseed' && foeTypes.includes('Grass'))) foe.vol[fx.volatile] = fx.volatile === 'taunt' ? 3 : 1; }
    }
    if (fx.sideCondition) {
      const side = fx.sideTarget === 'foe' ? T : U;
      const sc = fx.sideCondition;
      if (sc in side.hazards) { const k = sc as keyof WSide['hazards']; const max = k === 'spikes' ? 3 : k === 'toxicspikes' ? 2 : 1; side.hazards[k] = Math.min(max, side.hazards[k] + 1); }
      else if (sc in side.screens) { const k = sc as keyof WSide['screens']; if (!side.screens[k]) side.screens[k] = k === 'tailwind' ? 4 : toID(me.set.item) === 'lightclay' ? 8 : 5; }
    }
    if (fx.weather) { w.weather = fx.weather; w.weatherTurns = 5; }
    if (fx.terrain) { w.terrain = dex.moves.get(fx.terrain).name || fx.terrain; w.terrainTurns = 5; }
    if (fx.pseudoWeather === 'trickroom') w.trickRoom = w.trickRoom ? 0 : 5;
  }
  if (fx.special === 'rapidspin') { U.hazards = { stealthrock: 0, spikes: 0, toxicspikes: 0, stickyweb: 0 }; }
  if (fx.selfdestruct) me.hp = 0;
  if (foe && foe.hp <= 0) { foe.hp = 0; foe.alive = false; }
  if (me.hp <= 0) { me.hp = 0; me.alive = false; }
  // 교체 기술 / 강제 교체
  if (fx.selfSwitch && me.alive && foe?.alive !== undefined) { const r = bestReplacement(w, u); if (r >= 0) switchIn(w, u, r); }
  if (fx.forceSwitch && foe?.alive) { const alts = T.mons.map((m, i) => (m.alive && i !== T.active ? i : -1)).filter((i) => i >= 0); if (alts.length) switchIn(w, (1 - u) as 0 | 1, alts[0]); }
}

function endOfTurn(w: World) {
  const wt = toID(w.weather);
  for (const si of [0, 1] as const) {
    const s = w.sides[si];
    const m = activeOf(s);
    if (m?.alive) {
      const t = typesOf(m); const ab = toID(m.set.ability); const item = m.itemGone ? '' : toID(m.set.item);
      if (wt === 'sandstorm' && !t.some((x) => ['Rock', 'Ground', 'Steel'].includes(x)) && !['overcoat', 'sandveil', 'sandrush', 'sandforce', 'magicguard'].includes(ab) && item !== 'safetygoggles') m.hp -= 6.25;
      if (wt === 'hail' && !t.includes('Ice') && !['overcoat', 'icebody', 'snowcloak', 'magicguard'].includes(ab) && item !== 'safetygoggles') m.hp -= 6.25;
      if (ab !== 'magicguard') {
        if (m.status === 'brn') m.hp -= 6.25;
        if (m.status === 'psn') m.hp -= ab === 'poisonheal' ? -12.5 : 12.5;
        if (m.status === 'tox') { m.vol.toxN = (m.vol.toxN ?? 0) + 1; m.hp -= ab === 'poisonheal' ? -12.5 : 6.25 * m.vol.toxN; }
        if (m.vol.curse) m.hp -= 25;
      }
      if (item === 'leftovers' || (item === 'blacksludge' && t.includes('Poison'))) m.hp += 6.25;
      if (item === 'blacksludge' && !t.includes('Poison')) m.hp -= 12.5;
      if (toID(w.terrain) === 'grassyterrain') m.hp += 6.25;
      if (m.vol.leechseed) { const foe = activeOf(w.sides[1 - si]); m.hp -= 12.5; if (foe?.alive) foe.hp = Math.min(100, foe.hp + 12.5); }
      if (m.vol.yawn) { m.vol.yawn--; if (!m.vol.yawn && !m.status) m.status = 'slp'; }
      if (m.vol.taunt) m.vol.taunt--;
      if (ab === 'speedboost') m.boosts.spe = Math.min(6, (m.boosts.spe ?? 0) + 1);
      m.hp = Math.min(100, m.hp);
      if (m.hp <= 0) { m.hp = 0; m.alive = false; }
      m.activeTurns++;
    }
    for (const k of Object.keys(s.screens) as Array<keyof WSide['screens']>) if (s.screens[k] > 0) s.screens[k]--;
  }
  if (w.weather && --w.weatherTurns <= 0 && !/desolate|primordial|delta/i.test(w.weather)) w.weather = '';
  if (w.terrain && --w.terrainTurns <= 0) w.terrain = '';
  if (w.trickRoom > 0) w.trickRoom--;
  // 쓰러진 포켓몬 교체
  for (const si of [0, 1] as const) {
    const s = w.sides[si];
    if (!activeOf(s)?.alive && aliveCount(s) > 0) { const r = bestReplacement(w, si); if (r >= 0) switchIn(w, si, r); }
  }
  w.turn++;
}

/** 한 턴 진행한 새 월드 (a0: 0번 편 행동, a1: 1번 편 행동) */
export function step(w0: World, a0: WAction, a1: WAction): World {
  const w = cloneWorld(w0);
  const acts: [WAction, WAction] = [a0, a1];
  // 1) 교체 먼저
  for (const si of [0, 1] as const) {
    const a = acts[si];
    if (a.kind === 'switch') switchIn(w, si, a.to);
  }
  // 2) 메가진화
  for (const si of [0, 1] as const) {
    const a = acts[si];
    if (a.kind === 'move' && a.mega) {
      const m = activeOf(w.sides[si]);
      const forme = megaFormeOf(m.set);
      if (forme) { const sp = dex.species.get(forme); m.set = { ...m.set, species: sp.name, ability: sp.abilities[0] }; w.sides[si].megaUsed = true; }
    }
    if (a.kind === 'move' && a.z) w.sides[si].zUsed = true;
  }
  // 3) 방어
  const prot: [boolean, boolean] = [false, false];
  for (const si of [0, 1] as const) {
    const a = acts[si];
    if (a.kind === 'move' && moveFx(a.move).protect) {
      const m = activeOf(w.sides[si]);
      prot[si] = !(m.lastMove && moveFx(m.lastMove).protect);
      m.lastMove = moveFx(a.move).id;
    }
  }
  // 4) 기술 순서
  const pri = (a: WAction) => (a.kind === 'move' ? moveFx(a.move).priority : -99);
  const first: 0 | 1 = acts[0].kind !== 'move' ? 1 : acts[1].kind !== 'move' ? 0 : order(w, pri(acts[0]), pri(acts[1])) > 0 ? 0 : 1;
  const second = (1 - first) as 0 | 1;
  let flinch = false;
  const aF = acts[first];
  if (aF.kind === 'move') {
    // 기습: 상대가 공격하지 않으면 실패
    const fxF = moveFx(aF.move);
    const tgtAct = acts[second];
    if (!(fxF.special === 'sucker' && !(tgtAct.kind === 'move' && moveFx(tgtAct.move).category !== 'Status'))) useMove(w, first, aF, prot[second], false);
    flinch = (fxF.flinchChance ?? 0) >= 0.5 && (fxF.special !== 'firstturn' || activeOf(w.sides[first]).activeTurns === 0);
  }
  const aS = acts[second];
  if (aS.kind === 'move') {
    const fxS = moveFx(aS.move);
    if (!(fxS.special === 'sucker')) useMove(w, second, aS, prot[first], flinch);
  }
  endOfTurn(w);
  return w;
}

/** 메가스톤으로 바뀌는 폼 이름 ('' = 없음) */
export function megaFormeOf(set: PokemonSet): string {
  const stone = dex.items.get(set.item).megaStone as unknown;
  if (!stone) return '';
  if (typeof stone === 'string') return stone;
  const map = stone as Record<string, string>;
  const base = dex.species.get(set.species);
  return map[base.name] ?? map[base.baseSpecies] ?? Object.values(map)[0] ?? '';
}

// ---------- 행동 후보 ----------
export function sideActions(w: World, si: 0 | 1): WAction[] {
  const s = w.sides[si]; const m = activeOf(s);
  const out: WAction[] = [];
  if (m?.alive) {
    const canMega = !s.megaUsed && !!megaFormeOf(m.set) && !dex.species.get(m.set.species).isMega;
    for (const mv of m.set.moves) out.push({ kind: 'move', move: mv, mega: canMega || undefined });
  }
  s.mons.forEach((x, i) => { if (x.alive && i !== s.active) out.push({ kind: 'switch', to: i }); });
  return out.length ? out : [{ kind: 'pass' }];
}
