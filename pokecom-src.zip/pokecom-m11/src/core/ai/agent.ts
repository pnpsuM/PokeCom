// 통일 판단 파이프라인: 가능한 상황 N개 → 행동 후보 → 한 턴 진행 → 상황 점수 → 선택(ε).
// 단계(L1~L3)는 설정값(상황 수, 진행 방식, 깊이, 상대 응수 모델)만 다르다.
import type { Agent, AgentContext } from '../session';
import { legalChoices, RandomAgent } from '../agents';
import { sampleWorlds, previewWorld } from './belief';
import { matchupTerm } from './evaluate';
import { evaluate, DEFAULT_WEIGHTS, type Weights } from './evaluate';
import { step, sideActions, switchIn, cloneWorld, megaFormeOf, type WAction, type World } from './world';
import { simSearch } from './simsearch';

import { PROFILES, type Profile } from '../../config/ai';
export { PROFILES, type Profile };

/** 요청의 choice 문자열 → 월드 행동 */
export function toWAction(req: any, choice: string): WAction {
  const [kind, n, ...rest] = choice.split(' ');
  if (kind === 'switch') return { kind: 'switch', to: +n - 1, choice };
  if (kind === 'move') {
    const mv = req.active![0].moves[+n - 1];
    return { kind: 'move', move: mv.move, mega: rest.includes('mega'), z: rest.includes('zmove'), choice };
  }
  return { kind: 'pass' };
}

/** 모든 합법 행동 (메가는 켠 것만, 끈 것은 제외해 후보 수를 줄인다) */
export function myChoices(req: any): string[] {
  const all = legalChoices(req);
  const a = req.active?.[0];
  if (a?.canMegaEvo) return all.filter((c) => !c.startsWith('move') || c.includes('mega'));
  return all;
}

const PASS: WAction = { kind: 'pass' };
const replyCache = new WeakMap<World, WAction[]>();

/** 한쪽의 탐욕 행동: 상대가 가만히 있다고 보고 자기 점수를 가장 올리는 행동 */
export function greedy(w: World, side: 0 | 1, W: Weights): WAction {
  let best: WAction = PASS, bv = -Infinity;
  for (const x of sideActions(w, side)) {
    if (x.kind === 'switch') continue;
    const v = side === 0 ? evaluate(step(w, x, PASS), W) : -evaluate(step(w, PASS, x), W);
    if (v > bv) { bv = v; best = x; }
  }
  return best;
}
/** 상대 응수 후보: 상대 입장에서 좋은 행동 상위 k개 (내가 가만히 있다고 볼 때) */
export function topReplies(w: World, k: number, W: Weights): WAction[] {
  const opts = sideActions(w, 1).map((b) => ({ b, v: evaluate(step(w, PASS, b), W) }));
  opts.sort((x, y) => x.v - y.v);
  return opts.slice(0, k).map((x) => x.b);
}

/** L1·L2 공통: 행동 a 의 값 */
function valueOf(worlds: World[], a: WAction, p: Profile, W: Weights, forced: boolean): number {
  let total = 0;
  for (const w of worlds) {
    if (forced) {
      const t = cloneWorld(w);
      if (a.kind === 'switch') switchIn(t, 0, a.to);
      total += evaluate(t, W);
      continue;
    }
    if (p.level <= 1) { total += evaluate(step(w, a, PASS), W); continue; }
    const replies = replyCache.get(w) ?? topReplies(w, p.replies ?? 99, W);
    replyCache.set(w, replies);
    const vals = replies.map((b) => {
      let w1 = step(w, a, b);
      for (let d = 1; d < (p.depth ?? 1); d++) w1 = step(w1, greedy(w1, 0, W), greedy(w1, 1, W));
      return evaluate(w1, W);
    });
    const min = Math.min(...vals), mean = vals.reduce((x, y) => x + y, 0) / vals.length;
    const reply = p.lambda * min + (1 - p.lambda) * mean;
    // greedyMix: 상대가 가만히 있다고 본 1턴 값(L1)을 섞는다 — 응수만 보면 지나치게 소극적이 된다
    const g = p.greedyMix ?? 0;
    total += g ? g * evaluate(step(w, a, PASS), W) + (1 - g) * reply : reply;
  }
  return total / worlds.length;
}

export interface Decision { choice: string; scores: Array<{ choice: string; value: number }>; sims?: number; ms?: number }

export async function decide(req: any, ctx: AgentContext, p: Profile): Promise<Decision> {
  const rng = ctx.rng;
  const W = p.weights ?? DEFAULT_WEIGHTS;
  const choices = myChoices(req);
  if (choices.length === 1) return { choice: choices[0], scores: [] };
  const n = p.level === 1 ? 1 : p.worlds;
  const worlds = sampleWorlds(req, ctx.view, ctx.team, n, rng);
  if (p.level === 3 && !req.forceSwitch) {
    // 1) 근사 모델(L2 설정)로 전체 행동을 훑고 상위 K개만 실제 시뮬레이터로 확인
    const pre = { ...p, level: 2 as const, depth: 1, replies: 3, lambda: 0.6, greedyMix: 0.5 };
    const approxWorlds = worlds.slice(0, 3);
    const approx = choices.map((c) => ({ choice: c, value: valueOf(approxWorlds, toWAction(req, c), pre, W, false) }));
    approx.sort((a, b) => b.value - a.value);
    const keep = approx.slice(0, p.topK ?? 4).map((x) => x.choice);
    const d = await simSearch(req, ctx, p, worlds.slice(0, p.simWorlds ?? 4), keep, keep.map((c) => toWAction(req, c)), W);
    // 2) 시뮬레이션 값(표본 잡음 있음)과 근사 값을 섞어 최종 판단
    const mix = p.priorWeight ?? 0.3;
    const scores = d.scores.map((s) => ({ choice: s.choice, value: (1 - mix) * s.value + mix * (approx.find((a) => a.choice === s.choice)?.value ?? 0) - (s.choice.startsWith('switch') ? W.switchCost : 0) }));
    const best = scores.reduce((a, b) => (b.value > a.value ? b : a), scores[0]);
    return { choice: best?.choice ?? keep[0], scores, sims: d.sims, ms: d.ms };
  }
  const scores = choices.map((c) => ({ choice: c, value: valueOf(worlds, toWAction(req, c), p, W, !!req.forceSwitch) - (!req.forceSwitch && c.startsWith('switch') ? W.switchCost : 0) }));
  const max = Math.max(...scores.map((s) => s.value));
  const top = scores.filter((s) => s.value >= max - 1e-9);
  return { choice: top[Math.floor(rng() * top.length)].choice, scores };
}

export function makeAgent(p: Profile): Agent {
  return {
    id: p.id, label: p.label,
    async choose(req, ctx) {
      if (p.level === 0 || ctx.rng() < p.epsilon) return RandomAgent.choose(req, ctx);
      if (req.teamPreview) return teamPreview(req, ctx);
      if (!req.active?.[0] && !req.forceSwitch) return 'default';
      const d = await decide(req, ctx, p);
      if ((globalThis as { AI_DEBUG?: boolean }).AI_DEBUG) console.log(`[${p.id}] ${d.choice} ${d.sims ? `(${d.sims} sims, ${d.ms}ms)` : ''} | ${d.scores.map((s) => `${s.choice.replace('move ', 'm')}:${s.value.toFixed(2)}`).join(' ')}`);
      return d.choice;
    },
  };
}

/** 팀 프리뷰: 우리 6 × 상대 6 대면 점수표로 3마리와 선봉을 고른다 (모든 단계 공통)
 *  - 상대 6마리 중 나올 법한 쪽(우리 파티 상대로 평균 대면이 좋은 쪽)에 가중
 *  - 메가진화는 한 판에 1번 → 메가스톤 든 포켓몬 2마리 이상 선출은 감점
 *  - 선봉은 상대 예상 선봉(나올 법한 쪽 가중을 더 세게)에 가장 강한 포켓몬 */
export const PREVIEW = { oppSharp: 2.5, leadSharp: 5, megaPenalty: 0.35, meanWeight: 0.5, noise: 0.05 };
function teamPreview(req: any, ctx: AgentContext): string {
  const pick = ctx.format.pickSize;
  const w = previewWorld(req, ctx.view, ctx.team);
  const [me, op] = w.sides;
  if (!op.mons.length) return RandomAgent.choose(req, ctx) as string;
  const M = me.mons.map((_, i) => op.mons.map((_, j) => { me.active = i; op.active = j; return matchupTerm(w); }));
  const n = me.mons.length, m = op.mons.length;
  const avg = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;
  // 상대 j 가 나올 가능성: 우리 파티 전체를 상대로 한 평균 대면(상대 입장)이 좋을수록 높다
  const oppEdge = op.mons.map((_, j) => -avg(M.map((row) => row[j])));
  const soft = (k: number) => { const e = oppEdge.map((x) => Math.exp(k * x)); const s = e.reduce((a, b) => a + b, 0); return e.map((x) => x / s); };
  const q = soft(PREVIEW.oppSharp), lead = soft(PREVIEW.leadSharp);
  const wavg = (row: number[], p: number[]) => row.reduce((a, x, j) => a + x * p[j], 0);
  const isMega = me.mons.map((x) => !!megaFormeOf(x.set));
  const combos: number[][] = [];
  const rec = (start: number, acc: number[]) => { if (acc.length === pick) { combos.push([...acc]); return; } for (let i = start; i < n; i++) rec(i + 1, [...acc, i]); };
  rec(0, []);
  let best: number[] = combos[0] ?? [0, 1, 2]; let bestScore = -Infinity;
  for (const trio of combos) {
    let cover = 0;
    for (let j = 0; j < m; j++) cover += q[j] * Math.max(...trio.map((i) => M[i][j]));
    const mean = avg(trio.map((i) => wavg(M[i], q)));
    const megas = trio.filter((i) => isMega[i]).length;
    const s = cover + PREVIEW.meanWeight * mean - PREVIEW.megaPenalty * Math.max(0, megas - 1) + ctx.rng() * PREVIEW.noise;
    if (s > bestScore) { bestScore = s; best = trio; }
  }
  // 선봉: 상대 예상 선봉에 가장 강한 쪽, 나머지는 나올 법한 상대 기준 평균 순
  const leadIdx = best.reduce((a, b) => (wavg(M[b], lead) > wavg(M[a], lead) ? b : a), best[0]);
  const rest = best.filter((i) => i !== leadIdx).sort((x, y) => wavg(M[y], q) - wavg(M[x], q));
  return `team ${[leadIdx, ...rest].map((i) => i + 1).join('')}`;
}
