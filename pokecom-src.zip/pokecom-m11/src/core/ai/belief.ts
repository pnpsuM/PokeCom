// 공개 정보(BattleView + 내 요청) → 가능한 상황(World) N개.
// 상대의 숨은 정보(데려온 포켓몬, 세트)는 Champions 샘플 세트 중 드러난 정보와 맞는 것에서 뽑는다.
import { toID } from '../../sim';
import { dex, FORMAT, type PokemonSet } from '../format';
import { sampleSets } from '../teams';
import type { BattleView, MonState } from '../view';
import { Mech } from './mech';
import type { World, WMon, WSide } from './world';

type SideID = 'p1' | 'p2';

// ---------- 세트 후보 ----------
const setCache = new Map<string, PokemonSet[]>();
function setsFor(species: string): PokemonSet[] {
	const base = dex.species.get(species);
	const id = toID(base.baseSpecies && base.isMega ? base.baseSpecies : base.name);
	let v = setCache.get(id);
	if (!v) {
		try { v = sampleSets(base.isMega ? base.baseSpecies : base.name, 6).map(x => x.set); } catch { v = []; }
		setCache.set(id, v);
	}
	return v;
}

/** 샘플 세트가 없을 때: 종족값으로 공격 성향을 정하고 자속 기술 몇 개를 넣은 일반 세트 */
function genericSet(species: string): PokemonSet {
	const sp = dex.species.get(species);
	const phys = sp.baseStats.atk >= sp.baseStats.spa;
	const moves: string[] = [];
	for (const m of dex.moves.all()) {
		if (moves.length >= 3) break;
		if (m.isNonstandard || m.category === 'Status' || !sp.types.includes(m.type) || m.basePower < 70 || m.basePower > 100) continue;
		if ((m.category === 'Physical') !== phys) continue;
		moves.push(m.name);
	}
	const stat = phys ? 'atk' : 'spa';
	return {
		name: '', species: sp.name, item: '', ability: sp.abilities['0'], nature: phys ? 'Adamant' : 'Modest',
		evs: { hp: 32, atk: 0, def: 0, spa: 0, spd: 0, spe: 2, [stat]: 32 } as PokemonSet['evs'],
		ivs: { hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31 }, moves, level: FORMAT.level, gender: '',
	};
}

/** 드러난 기술·도구·특성과 맞는 세트 후보 */
export function candidates(mon: MonState): PokemonSet[] {
	const sp = dex.species.get(mon.species);
	const known = mon.moves.map(m => toID(m));
	const itemId = mon.item === undefined ? null : toID(mon.item);
	const abilityId = mon.ability ? toID(mon.ability) : null;
	const fit = setsFor(mon.species).filter(s => {
		const mv = s.moves.map(m => toID(m));
		if (!known.every(k => mv.includes(k))) return false;
		if (itemId && toID(s.item) !== itemId) return false;
		if (abilityId && !sp.isMega && toID(s.ability) !== abilityId) return false;
		if (sp.isMega && !dex.items.get(s.item).megaStone) return false;
		return true;
	});
	const base = fit.length ? fit : [(() => {
		const g = setsFor(mon.species)[0] ? { ...setsFor(mon.species)[0], moves: [...setsFor(mon.species)[0].moves] } : genericSet(mon.species);
		// 드러난 기술로 앞에서부터 바꿔 넣는다
		for (const k of mon.moves) if (!g.moves.map(m => toID(m)).includes(toID(k))) { if (g.moves.length >= 4) g.moves.pop(); g.moves.unshift(dex.moves.get(k).name); }
		if (mon.item) g.item = mon.item;
		if (mon.ability && !sp.isMega) g.ability = mon.ability;
		return g;
	})()];
	return base.map(s => ({
		...s,
		species: sp.isMega ? sp.name : dex.species.get(s.species).isMega ? dex.species.get(s.species).baseSpecies : sp.name,
		item: mon.item === '' ? '' : (mon.item || s.item),
	}));
}

// ---------- 요청 → 내 편 ----------
function hpPct(cond: string) { const [hp] = cond.split(' '); if (hp === '0') return 0; const [a, b] = hp.split('/').map(Number); return b ? (a / b) * 100 : 0; }
function statusOf(cond: string) { const s = cond.split(' ')[1] ?? ''; return s === 'fnt' ? '' : s; }

function ownSet(team: PokemonSet[] | undefined, p: any): PokemonSet {
	const species = p.details.split(',')[0];
	const num = dex.species.get(species).num;
	const set = team?.find(s => dex.species.get(s.species).num === num);
	const base = set ?? genericSet(species);
	return {
		...base, species, item: p.item ? dex.items.get(p.item).name : '',
		ability: dex.abilities.get(p.ability ?? p.baseAbility).name || base.ability,
		moves: (p.moves as string[]).map(m => dex.moves.get(m).name || m),
	};
}

const HAZ = ['stealthrock', 'spikes', 'toxicspikes', 'stickyweb'] as const;
const SCR = ['reflect', 'lightscreen', 'auroraveil', 'tailwind'] as const;
function sideConds(view: BattleView | undefined, id: SideID): Pick<WSide, 'hazards' | 'screens'> {
	const c = (view?.state.sides[id].conditions ?? []).map(x => toID(x));
	const hazards = { stealthrock: 0, spikes: 0, toxicspikes: 0, stickyweb: 0 };
	const screens = { reflect: 0, lightscreen: 0, auroraveil: 0, tailwind: 0 };
	for (const k of HAZ) if (c.includes(k)) hazards[k] = 1;
	for (const k of SCR) if (c.includes(k)) screens[k] = 3;
	return { hazards, screens };
}
function vols(view: BattleView | undefined, id: SideID): Record<string, number> {
	const v: Record<string, number> = {};
	for (const x of view?.state.sides[id].volatiles ?? []) if (['substitute', 'taunt', 'leechseed', 'yawn', 'curse', 'encore'].includes(x)) v[x] = x === 'taunt' ? 2 : 1;
	if (view?.state.sides[id].proteanUsed) v.protean = 1;
	return v;
}

/** 가능한 상황 n개. 첫 번째는 가장 그럴듯한 상황(각 포켓몬의 첫 후보) */
export function sampleWorlds(req: any, view: BattleView | undefined, team: PokemonSet[] | undefined, n: number, rng: () => number): World[] {
	const meId: SideID = req.side.id; const opId: SideID = meId === 'p1' ? 'p2' : 'p1';
	const turn = view?.state.turn ?? 0;
	const reqMons: any[] = req.side.pokemon;
	const mine: WMon[] = reqMons.map((p, i) => {
		const set = ownSet(team, p);
		const orig = team?.find(s => dex.species.get(s.species).num === dex.species.get(set.species).num);
		return {
			key: `m${i}`, set, hp: hpPct(p.condition), status: statusOf(p.condition),
			alive: !p.condition.endsWith(' fnt') && !p.condition.startsWith('0'),
			boosts: p.active ? { ...(view?.state.sides[meId].boosts ?? {}) } : {},
			vol: p.active ? vols(view, meId) : {},
			itemGone: !!orig?.item && !p.item,
			lastMove: p.active ? toID(view?.lastMove[meId] ?? '') : undefined,
			activeTurns: p.active && turn > 1 ? 1 : 0,
			types: p.active ? view?.state.sides[meId].types ?? undefined : undefined,
		};
	});
	const myActive = Math.max(0, reqMons.findIndex(p => p.active));
	const a0 = req.active?.[0];
	const myMega = reqMons.some(p => /-Mega/.test(p.details)) || (!!a0 && !a0.canMegaEvo && !!dex.items.get(mine[myActive]?.set.item ?? '').megaStone);

	const opTeam = view?.state.sides[opId].team ?? [];
	const revealed = opTeam.filter(m => m.revealed);
	const hidden = opTeam.filter(m => !m.revealed);
	const opActiveView = view?.state.sides[opId].active ?? null;
	const worlds: World[] = [];
	for (let k = 0; k < n; k++) {
		const pool = [...hidden];
		for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
		const brought = [...revealed, ...pool.slice(0, Math.max(0, FORMAT.pickSize - revealed.length))];
		const theirs: WMon[] = brought.map((mv, i) => {
			const c = candidates(mv);
			const set = k === 0 ? c[0] : c[Math.floor(rng() * c.length)];
			const isActive = mv === opActiveView;
			return {
				key: `o${i}`, set, hp: mv.maxhp ? (mv.hp / mv.maxhp) * 100 : 100, status: mv.status, alive: !mv.fainted,
				boosts: isActive ? { ...(view?.state.sides[opId].boosts ?? {}) } : {},
				vol: isActive ? vols(view, opId) : {},
				itemGone: mv.item === '',
				lastMove: isActive ? toID(view?.lastMove[opId] ?? '') : undefined,
				activeTurns: isActive && turn > 1 ? 1 : 0,
				types: isActive ? view?.state.sides[opId].types ?? undefined : undefined,
			};
		});
		const mech = new Mech([mine.map(m => ({ key: m.key, set: m.set })), theirs.map(m => ({ key: m.key, set: m.set }))]);
		worlds.push({
			sides: [
				{ mons: mine.map(m => ({ ...m, boosts: { ...m.boosts }, vol: { ...m.vol } })), active: myActive, ...sideConds(view, meId), megaUsed: myMega, zUsed: true },
				{ mons: theirs, active: Math.max(0, brought.findIndex(m => m === opActiveView)), ...sideConds(view, opId), megaUsed: brought.some(m => dex.species.get(m.species).isMega), zUsed: true },
			],
			weather: view?.state.weather ?? '', weatherTurns: 3,
			terrain: view?.state.terrain.find(t => /Terrain/.test(t)) ?? '', terrainTurns: 3,
			trickRoom: view?.state.terrain.some(t => toID(t) === 'trickroom') ? 3 : 0,
			turn, mech,
		});
	}
	return worlds;
}

/** 팀 프리뷰용: 양쪽 6마리 전부 (상대는 첫 후보 세트) */
export function previewWorld(req: any, view: BattleView | undefined, team: PokemonSet[] | undefined): World {
	const meId: SideID = req.side.id; const opId: SideID = meId === 'p1' ? 'p2' : 'p1';
	const mk = (key: string, set: PokemonSet): WMon => ({ key, set, hp: 100, status: '', alive: true, boosts: {}, vol: {}, activeTurns: 0 });
	const mine = (req.side.pokemon as any[]).map((p, i) => mk(`m${i}`, ownSet(team, p)));
	const theirs = (view?.state.sides[opId].team ?? []).map((m, i) => mk(`o${i}`, candidates(m)[0]));
	const mech = new Mech([mine.map(m => ({ key: m.key, set: m.set })), theirs.map(m => ({ key: m.key, set: m.set }))]);
	const empty = () => ({ hazards: { stealthrock: 0, spikes: 0, toxicspikes: 0, stickyweb: 0 }, screens: { reflect: 0, lightscreen: 0, auroraveil: 0, tailwind: 0 }, megaUsed: false, zUsed: true });
	return { sides: [{ mons: mine, active: 0, ...empty() }, { mons: theirs, active: 0, ...empty() }], weather: '', weatherTurns: 0, terrain: '', terrainTurns: 0, trickRoom: 0, turn: 0, mech };
}
