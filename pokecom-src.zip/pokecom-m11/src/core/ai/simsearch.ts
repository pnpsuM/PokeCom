// L3: 가능한 상황마다 실제 시뮬레이터로 판을 재구성하고, 내 행동 × 상대 응수를 2턴 굴려 본다.
// 시간 제한(기본 5초)과 시뮬레이션 상한 안에서 돈다. UI 가 멈추지 않도록 중간중간 양보한다.
import { Battle, State, Teams, toID, PRNG } from '../../sim';
import { dex, FORMAT, type PokemonSet } from '../format';
import type { AgentContext } from '../session';
import { legalChoices } from '../agents';
import { evaluate, type Weights } from './evaluate';
import { step, sideActions, expectedDamage, type World, type WAction, type WMon, type WSide } from './world';
import type { Decision, Profile } from './agent';

type SimBattle = any;
type SimSide = any;

function clearLog(b: SimBattle) { b.log.length = 0; (b as unknown as { sentLogPos: number }).sentLogPos = 0; }

// ---------- 월드 → 시뮬레이터 ----------
function toPokemonSet(m: WMon): PokemonSet {
  const sp = dex.species.get(m.set.species);
  const base = sp.battleOnly ? (Array.isArray(sp.battleOnly) ? sp.battleOnly[0] : sp.battleOnly) : sp.name;
  const baseSp = dex.species.get(base);
  const full = (o: Partial<Record<string, number>> | undefined, d: number) => ({ hp: o?.hp ?? d, atk: o?.atk ?? d, def: o?.def ?? d, spa: o?.spa ?? d, spd: o?.spd ?? d, spe: o?.spe ?? d });
  return {
    name: m.key, species: baseSp.name, item: m.itemGone ? '' : m.set.item,
    ability: sp.isMega ? baseSp.abilities[0] : m.set.ability || baseSp.abilities[0],
    nature: m.set.nature, evs: full(m.set.evs, 0), ivs: full(m.set.ivs, 31), moves: m.set.moves, level: m.set.level, gender: '',
  } as PokemonSet;
}

function applySide(b: SimBattle, side: SimSide, ws: WSide, foe: SimSide) {
  let left = 0;
  for (const p of side.pokemon) {
    const m = ws.mons.find((x) => x.key === p.name);
    if (!m) continue;
    if (!m.alive) { p.hp = 0; p.fainted = true; p.status = 'fnt' as never; continue; }
    left++;
    const sp = dex.species.get(m.set.species);
    if (sp.name !== p.species.name) { try { p.formeChange(sp.name, p.getItem(), true); } catch { /* 폼 불가 */ } }
    p.hp = Math.max(1, Math.round((p.maxhp * m.hp) / 100));
    if (m.status) { try { p.setStatus(m.status, p, null, true); } catch { /* */ } }
    p.boosts = { atk: 0, def: 0, spa: 0, spd: 0, spe: 0, accuracy: 0, evasion: 0, ...m.boosts } as never;
    if (m.itemGone) p.item = '' as never;
    if (p.isActive) {
      if (m.vol.substitute) p.addVolatile('substitute');
      if (m.vol.taunt) p.addVolatile('taunt');
      if (m.vol.leechseed && foe.active[0]) p.addVolatile('leechseed', foe.active[0]);
    }
  }
  side.pokemonLeft = left;
  if (ws.megaUsed) for (const p of side.pokemon) p.canMegaEvo = null;
  if (ws.zUsed) side.zMoveUsed = true;
  const src = side.active[0];
  const foeSrc = foe.active[0];
  for (const k of ['stealthrock', 'spikes', 'toxicspikes', 'stickyweb'] as const) for (let i = 0; i < ws.hazards[k]; i++) side.addSideCondition(k, foeSrc);
  for (const k of ['reflect', 'lightscreen', 'auroraveil', 'tailwind'] as const) {
    if (ws.screens[k] > 0 && side.addSideCondition(k, src)) side.sideConditions[k].duration = ws.screens[k];
  }
  void b;
}

function buildBattle(w: World, seed: number): SimBattle | null {
  try {
    const order = (s: WSide) => [s.mons[s.active], ...s.mons.filter((_, i) => i !== s.active)];
    const b = new Battle({ formatid: FORMAT.id, seed: `${seed},7,11,13` as never });
    b.setPlayer('p1', { name: 'A', team: Teams.pack(order(w.sides[0]).map(toPokemonSet)) });
    b.setPlayer('p2', { name: 'B', team: Teams.pack(order(w.sides[1]).map(toPokemonSet)) });
    b.choose('p1', 'team ' + w.sides[0].mons.map((_, i) => i + 1).join(''));
    b.choose('p2', 'team ' + w.sides[1].mons.map((_, i) => i + 1).join(''));
    b.field.clearWeather();
    applySide(b, b.p1, w.sides[0], b.p2);
    applySide(b, b.p2, w.sides[1], b.p1);
    const src = b.p1.active[0];
    if (w.weather) b.field.setWeather(toID(w.weather) as never, src);
    if (w.terrain) b.field.setTerrain(toID(w.terrain) as never, src);
    if (w.trickRoom > 0) b.field.addPseudoWeather('trickroom', src);
    clearLog(b);
    // 다음 턴 요청을 새로 만든다 (상태를 바꿨으므로)
    b.makeRequest('move');
    return b;
  } catch (e) {
    if ((globalThis as { AI_DEBUG?: boolean }).AI_DEBUG) console.warn('L3 재구성 실패', e);
    return null;
  }
}

// ---------- 시뮬레이터 → 월드 ----------
function simToWorld(b: SimBattle, base: World): World {
  const side = (s: SimSide, ws: WSide): WSide => {
    const mons: WMon[] = ws.mons.map((m) => {
      const p = s.pokemon.find((x) => x.name === m.key);
      if (!p) return m;
      const boosts: Record<string, number> = {};
      for (const [k, v] of Object.entries(p.boosts)) if (v) boosts[k] = v as number;
      return {
        ...m, set: { ...m.set, species: p.species.name }, hp: p.fainted ? 0 : (p.hp / p.maxhp) * 100,
        status: p.fainted ? '' : (p.status as string), alive: !p.fainted && p.hp > 0, boosts,
        vol: { substitute: p.volatiles.substitute ? 1 : 0, taunt: p.volatiles.taunt ? 1 : 0, leechseed: p.volatiles.leechseed ? 1 : 0 },
        itemGone: !p.item, activeTurns: p.activeTurns,
      };
    });
    const act = s.active[0];
    const active = Math.max(0, ws.mons.findIndex((m) => m.key === act?.name));
    const sc = s.sideConditions as Record<string, { layers?: number; duration?: number }>;
    return {
      mons, active,
      hazards: { stealthrock: sc.stealthrock ? 1 : 0, spikes: sc.spikes?.layers ?? 0, toxicspikes: sc.toxicspikes?.layers ?? 0, stickyweb: sc.stickyweb ? 1 : 0 },
      screens: { reflect: sc.reflect?.duration ?? 0, lightscreen: sc.lightscreen?.duration ?? 0, auroraveil: sc.auroraveil?.duration ?? 0, tailwind: sc.tailwind?.duration ?? 0 },
      megaUsed: ws.megaUsed || s.pokemon.some((p) => p.species.isMega), zUsed: s.zMoveUsed,
    };
  };
  const pw = b.field.pseudoWeather as Record<string, { duration?: number }>;
  return {
    sides: [side(b.p1, base.sides[0]), side(b.p2, base.sides[1])],
    weather: b.field.weather as string, weatherTurns: b.field.weatherState?.duration ?? 3,
    terrain: b.field.terrain as string, terrainTurns: b.field.terrainState?.duration ?? 3,
    trickRoom: pw.trickroom?.duration ?? 0, turn: b.turn, mech: base.mech,
  };
}

// ---------- 행동 변환 ----------
function simSwitchChoice(side: SimSide, key: string): string | null {
  const i = side.pokemon.findIndex((p) => p.name === key);
  return i >= 0 ? `switch ${i + 1}` : null;
}
function worldActionToSim(side: SimSide, ws: WSide, a: WAction): string {
  if (a.kind === 'switch') return simSwitchChoice(side, ws.mons[a.to].key) ?? 'default';
  if (a.kind === 'move') {
    const p = side.active[0];
    const j = p.moveSlots.findIndex((s) => s.id === toID(a.move) || (toID(a.move).startsWith('hiddenpower') && s.id.startsWith('hiddenpower')));
    return j >= 0 ? `move ${j + 1}${a.mega ? ' mega' : ''}` : 'default';
  }
  return 'default';
}

/** 빠른 정책 (2턴째·교체 요청용): 가장 센 기술 / 점수가 가장 좋은 교체 */
function quickChoice(b: SimBattle, sideIdx: 0 | 1, base: World): string {
  const side = sideIdx === 0 ? b.p1 : b.p2;
  const req = side.activeRequest;
  if (!req || req.wait) return 'default';
  const legal = legalChoices(req);
  if (!legal.length) return 'default';
  const w = simToWorld(b, base);
  const sign = sideIdx === 0 ? 1 : -1;
  if (req.forceSwitch) {
    let best = legal[0], bs = -Infinity;
    for (const c of legal) {
      if (!c.startsWith('switch')) continue;
      const pos = +c.split(' ')[1] - 1; const key = side.pokemon[pos]?.name;
      const idx = w.sides[sideIdx].mons.findIndex((m) => m.key === key);
      if (idx < 0) continue;
      const t = { ...w, sides: [...w.sides] as [WSide, WSide] };
      t.sides[sideIdx] = { ...w.sides[sideIdx], active: idx };
      const s = sign * evaluate(t);
      if (s > bs) { bs = s; best = c; }
    }
    return best;
  }
  let best = 'default', bd = -1;
  for (const c of legal) {
    if (!c.startsWith('move')) continue;
    const i = +c.split(' ')[1] - 1;
    const mv = side.active[0]?.moveSlots[i]?.move;
    if (!mv) continue;
    const d = expectedDamage(w, sideIdx, mv).avg;
    if (d > bd) { bd = d; best = c; }
  }
  return best;
}

function settleSwitches(b: SimBattle, base: World) {
  for (let guard = 0; guard < 4 && !b.ended; guard++) {
    const s1 = b.p1.requestState === 'switch', s2 = b.p2.requestState === 'switch';
    if (!s1 && !s2) break;
    if (s1) b.choose('p1', quickChoice(b, 0, base));
    if (s2) b.choose('p2', quickChoice(b, 1, base));
  }
}

function rollout(ser: ReturnType<typeof State.serializeBattle>, base: World, myChoice: string, oppChoice: string, seed: number, depth: number, W: Weights): number | null {
  const b = State.deserializeBattle(ser) as SimBattle;
  (b as unknown as { prng: unknown }).prng = new PRNG(`${seed},${seed * 3 + 1},17,29` as never);
  clearLog(b);
  if (!b.choose('p1', myChoice)) { (globalThis as any).L3NULL = ((globalThis as any).L3NULL ?? 0) + 1; if ((globalThis as any).AI_DEBUG) console.log('choose fail', myChoice, JSON.stringify(b.p1.activeRequest)?.slice(0, 300)); return null; }
  if (!b.choose('p2', oppChoice)) { (globalThis as any).L3OPPFAIL = ((globalThis as any).L3OPPFAIL ?? 0) + 1; b.choose('p2', 'default'); }
  settleSwitches(b, base);
  for (let d = 1; d < depth && !b.ended; d++) {
    b.choose('p1', quickChoice(b, 0, base));
    b.choose('p2', quickChoice(b, 1, base));
    settleSwitches(b, base);
    clearLog(b);
  }
  if (b.ended) return b.winner === 'A' ? W.win + 3 : b.winner === 'B' ? -W.win - 3 : 0;
  return evaluate(simToWorld(b, base), W);
}

/** 상대 응수 후보: 근사 모델에서 내 평균 점수를 가장 낮추는 상위 k개 */
function opponentReplies(w: World, myActs: WAction[], k: number, W: Weights): WAction[] {
  const opp = sideActions(w, 1);
  const scored = opp.map((b) => ({ b, v: myActs.reduce((s, a) => s + evaluate(step(w, a, b), W), 0) / myActs.length }));
  scored.sort((x, y) => x.v - y.v);
  return scored.slice(0, k).map((x) => x.b);
}

export async function simSearch(req: any, ctx: AgentContext, p: Profile, worlds: World[], choices: string[], myActs: WAction[], W: Weights): Promise<Decision> {
  void req;
  const t0 = Date.now();
  const timeMs = p.timeMs ?? 5000, maxSims = p.maxSims ?? 400;
  let lastYield = Date.now();
  const yieldUI = async () => { if (Date.now() - lastYield > 25) { await new Promise((r) => setTimeout(r, 0)); lastYield = Date.now(); } };
  // 각 상황 준비: 재구성 + 상대 응수 후보
  const prepared: Array<{ w: World; ser: ReturnType<typeof State.serializeBattle>; replies: string[]; mine: string[] }> = [];
  for (const [i, w] of worlds.entries()) {
    const b = buildBattle(w, 1000 + i);
    if (!b) continue;
    const replies = opponentReplies(w, myActs, 2, W).map((a) => worldActionToSim(b.p2, w.sides[1], a));
    const mine = myActs.map((a, ai) => (a.kind === 'switch' ? (simSwitchChoice(b.p1, w.sides[0].mons[a.to].key) ?? 'default') : choices[ai]));
    prepared.push({ w, ser: State.serializeBattle(b), replies: [...new Set(replies)], mine });
    await yieldUI();
  }
  // 값 누적: [행동][상황][응수] → 합, 횟수
  const acc = choices.map(() => prepared.map((pw) => pw.replies.map(() => ({ sum: 0, n: 0 }))));
  let sims = 0, round = 0;
  outer: while (true) {
    for (let wi = 0; wi < prepared.length; wi++) {
      const pw = prepared[wi];
      for (let ri = 0; ri < pw.replies.length; ri++) {
        for (let ai = 0; ai < choices.length; ai++) {
          const v = rollout(pw.ser, pw.w, pw.mine[ai], pw.replies[ri], round * 7919 + wi * 131 + ri * 17 + ai, 2, W);
          if (v !== null) { acc[ai][wi][ri].sum += v; acc[ai][wi][ri].n++; }
          sims++;
          await yieldUI();
        }
        if (Date.now() - t0 > timeMs || sims >= maxSims) break outer;
      }
    }
    round++;
    if (round > 50) break;
  }
  const scores = choices.map((c, ai) => {
    let tot = 0, nw = 0;
    acc[ai].forEach((perW) => {
      const means = perW.filter((x) => x.n).map((x) => x.sum / x.n);
      if (!means.length) return;
      const min = Math.min(...means), mean = means.reduce((s, x) => s + x, 0) / means.length;
      tot += p.lambda * min + (1 - p.lambda) * mean; nw++;
    });
    return { choice: c, value: nw ? tot / nw : -Infinity };
  });
  const max = Math.max(...scores.map((s) => s.value));
  const top = scores.filter((s) => s.value >= max - 1e-9);
  return { choice: top[Math.floor(ctx.rng() * top.length)]?.choice ?? choices[0], scores, sims, ms: Date.now() - t0 };
}
