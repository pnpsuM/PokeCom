// 기술의 실제 타입: 특성(스카이스킨·페어리스킨·프리즈스킨·일렉트릭스킨·노말스킨·촉촉보이스 …),
// 기술 자체 조건(웨더볼·대지의파동 …)을 시뮬레이터 규칙(ModifyType 이벤트)으로 계산한다.
// 화면(내 기술 버튼)과 AI(데미지 계산)가 같은 함수를 쓴다.
import { toID } from '../sim';

export interface MoveTypeInfo {
	id: string;
	/** 실제로 나갈 타입 */
	type: string;
	/** 원래 타입 */
	baseType: string;
	/** 바뀐 이유 (특성 이름 또는 기술 효과). 안 바뀌었으면 '' */
	cause: '' | 'ability' | 'move';
	/** 특성이 바꿨다면 특성 id */
	abilityId?: string;
	/** 변환자재·리베로: 이 기술을 쓰면 사용자 타입이 바뀐다 (이번에 나온 뒤 아직 안 썼을 때만) */
	becomes?: { abilityId: string; type: string; stab: boolean };
}

/** 쓰는 기술 타입으로 사용자 타입을 바꾸는 특성 (한 번 나올 때 한 번) */
export const TYPE_SHIFT_ABILITIES = ['protean', 'libero'];

/**
 * 변환자재·리베로가 이 기술에 발동하는지. 시뮬레이터 onPrepareHit 조건과 같게:
 * 이번에 나온 뒤 아직 안 썼고, 다른 기술을 부르는 기술이 아니며, 지금 타입과 다를 때.
 */
export function typeShift(pokemon: any, move: { type: string; category: string; callsMove?: boolean; flags?: any }, abilityId: string, used: boolean, currentTypes: string[]): MoveTypeInfo['becomes'] {
	if (!TYPE_SHIFT_ABILITIES.includes(abilityId) || used) return undefined;
	if (move.callsMove || move.flags?.futuremove || !move.type || move.type === '???') return undefined;
	if (currentTypes.join() === move.type) return undefined;
	void pokemon;
	return { abilityId, type: move.type, stab: move.category !== 'Status' && !currentTypes.includes(move.type) };
}

/**
 * battle 안의 pokemon 이 move 를 쓸 때의 타입. 부작용 없이 계산한다 (로그를 되돌림).
 * abilityOverride: 메가진화 예정일 때 메가 폼 특성으로 미리 보기
 */
export function resolveMoveType(battle: any, pokemon: any, target: any, moveId: string, abilityOverride?: string): MoveTypeInfo {
	const base = battle.dex.moves.get(moveId);
	const out: MoveTypeInfo = { id: base.id, type: base.type, baseType: base.type, cause: '' };
	const ability = toID(abilityOverride ?? pokemon.ability);
	// 메가진화로 특성이 바뀌면 특성 상태도 새로 시작한다
	const used = abilityOverride && toID(abilityOverride) !== toID(pokemon.ability) ? false : !!pokemon.abilityState?.[ability];
	// 변화 기술은 타입이 바뀌어도 의미가 거의 없어 원래대로 둔다 (방어가 페어리로 보이는 혼란 방지). 변환자재는 변화 기술에도 발동
	if (base.category === 'Status') { out.becomes = typeShift(pokemon, base, ability, used, pokemon.getTypes()); return out; }
	const logLen = battle.log.length;
	const savedAbility = pokemon.ability;
	try {
		if (abilityOverride) pokemon.ability = toID(abilityOverride);
		const move = battle.dex.getActiveMove(base.id);
		battle.singleEvent('ModifyType', move, null, pokemon, target, move, move);
		const afterMove = move.type;
		battle.runEvent('ModifyType', pokemon, target, move, move);
		out.type = move.type;
		if (move.type !== base.type) {
			if (move.type !== afterMove) { out.cause = 'ability'; out.abilityId = toID(pokemon.ability); }
			else out.cause = 'move';
		}
		out.becomes = typeShift(pokemon, move, ability, used, pokemon.getTypes());
	} catch { /* 계산 불가: 원래 타입 */ }
	finally {
		pokemon.ability = savedAbility;
		battle.log.length = logLen;
	}
	return out;
}
