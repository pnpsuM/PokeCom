// 설정·저장 파티 (localStorage). 실패해도 앱은 동작해야 한다.
import type { PokemonSet } from './format';
import { MANIFEST } from '../config/manifest';

export interface Settings {
	spriteConsent: 'unknown' | 'yes' | 'no';
	spriteMode: 'ondemand' | 'all';
	spriteAllDone: boolean;
	speed: 'slow' | 'normal' | 'fast' | 'instant';
	/** 배틀 연출: 켜기 / 움직임 줄이기(색만) / 끄기 */
	effects: 'on' | 'reduced' | 'off';
	playerName: string;
	/** 홈에서 고른 내 파티 id ('' = 랜덤 파티) */
	activeTeam: string;
}
const SKEY = MANIFEST.storage.settings;
const DEFAULTS: Settings = { spriteConsent: 'unknown', spriteMode: 'ondemand', spriteAllDone: false, speed: 'normal', effects: 'on', playerName: '나', activeTeam: '' };

function read<T>(key: string, fallback: T): T {
	try { const v = localStorage.getItem(key); if (v) return JSON.parse(v); } catch { /* 저장소 사용 불가 */ }
	return fallback;
}
function write(key: string, value: unknown) {
	try { localStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
}

export const settings: Settings = { ...DEFAULTS, ...read<Partial<Settings>>(SKEY, {}) };
export function saveSettings() { write(SKEY, settings); }

export interface SavedTeam { id: string; name: string; sets: PokemonSet[]; updated: number }
const TKEY = MANIFEST.storage.teams;
let teams: SavedTeam[] = read<SavedTeam[]>(TKEY, []);

export function listTeams(): SavedTeam[] { return [...teams].sort((a, b) => b.updated - a.updated); }
export function getTeam(id: string): SavedTeam | undefined { return teams.find(t => t.id === id); }
export function saveTeam(t: SavedTeam): boolean {
	t.updated = Date.now();
	const i = teams.findIndex(x => x.id === t.id);
	if (i >= 0) teams[i] = t; else teams.push(t);
	return write(TKEY, teams);
}
export function deleteTeam(id: string) {
	teams = teams.filter(t => t.id !== id);
	if (settings.activeTeam === id) { settings.activeTeam = ''; saveSettings(); }
	write(TKEY, teams);
}
export function newTeamId() { return 't' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
