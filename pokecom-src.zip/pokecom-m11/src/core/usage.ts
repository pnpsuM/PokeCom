// 사용률 통계(Smogon Champions BSS chaos json 을 줄인 파일) → 상대 파티 생성·종별 대표 세트
// 데이터: src/data/usage/*.json (scripts/gen-usage.mjs 로 만든다). 없으면 hasUsage() = false
import { toID, TeamValidator } from '../sim';
import { dex, STATS, FORMAT, type PokemonSet } from './format';
import { MANIFEST } from '../config/manifest';

/** 줄인 통계 파일 형식 */
export interface UsageFile {
	format: string; month: string; cutoff: number; battles?: number;
	species: Array<{
		name: string; usage: number;
		abilities: [string, number][]; items: [string, number][];
		/** [성격, [H,A,B,C,D,S], 비율] */
		spreads: [string, number[], number][];
		moves: [string, number][]; teammates: [string, number][];
	}>;
}
type Entry = UsageFile['species'][number];

export function usageFile(): UsageFile | null {
	const files = MANIFEST.data.usage as UsageFile[];
	return files.find(f => f.format === FORMAT.id.split('@@@')[0]) ?? files[0] ?? null;
}
export const hasUsage = () => !!usageFile()?.species.length;
export const usageLabel = () => { const u = usageFile(); return u ? `${u.month} ${u.cutoff}+ 통계` : ''; };

function pick<T>(list: [T, number][], rng: () => number, skip?: (x: T) => boolean): T | null {
	const ok = list.filter(([x, w]) => w > 0 && !(skip?.(x)));
	const total = ok.reduce((a, [, w]) => a + w, 0);
	if (!total) return null;
	let r = rng() * total;
	for (const [x, w] of ok) { r -= w; if (r <= 0) return x; }
	return ok[ok.length - 1][0];
}
let validator: any = null;
/** 이 룰에서 배울 수 있는 기술인가 (통계에는 시뮬레이터가 모르는 기술이 섞일 수 있다) */
function canLearn(move: string, species: string): boolean {
	validator ??= TeamValidator.get(FORMAT.id);
	try { return !validator.checkCanLearn(dex.moves.get(move), dex.species.get(species)); } catch { return true; }
}
const entryOf = (name: string) => usageFile()?.species.find(s => toID(s.name) === toID(name)) ?? null;

/** 통계 한 종에서 세트 하나 (도구 skip 목록 반영) */
export function usageSet(e: Entry, rng: () => number, usedItems: Set<string> = new Set(), allowMega = true): PokemonSet | null {
	const mega = dex.species.get(e.name);
	if (!mega.exists) return null;
	// Smogon 은 메가진화한 포켓몬을 "Gyarados-Mega" 처럼 따로 센다 → 파티에는 메가 전 종 + 메가스톤으로 넣는다
	const sp = mega.isMega ? dex.species.get(mega.battleOnly as string || mega.baseSpecies) : mega;
	if (mega.isMega && !allowMega) return null;
	const item = pick(e.items, rng, it => usedItems.has(toID(it)) || (!allowMega && !!dex.items.get(it).megaStone) || !dex.items.get(it).exists) ?? '';
	const baseAbilities = mega.isMega ? (entryOf(sp.name)?.abilities ?? []) : e.abilities;
	const ability = pick(baseAbilities, rng, a => !Object.values(sp.abilities).map(x => toID(x as string)).includes(toID(a))) ?? sp.abilities['0'];
	const spread = pick(e.spreads.map(([n, s, w]) => [[n, s] as [string, number[]], w] as [[string, number[]], number]), rng);
	const moves: string[] = [];
	for (let i = 0; i < 4; i++) {
		const m = pick(e.moves, rng, x => moves.some(y => toID(y) === toID(x)) || !dex.moves.get(x).exists || toID(x) === 'nothing' || !canLearn(x, sp.name));
		if (!m) break;
		moves.push(dex.moves.get(m).name);
	}
	const evs = Object.fromEntries(STATS.map((k, i) => [k, Math.min(FORMAT.spPerStat, spread?.[1][i] ?? 0)])) as PokemonSet['evs'];
	return {
		name: '', species: sp.name, item: item ? dex.items.get(item).name : '', ability: dex.abilities.get(ability).name,
		nature: spread?.[0] || 'Serious', evs, ivs: { hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31 },
		moves, level: FORMAT.level, gender: '',
	};
}

/** 사용률·동료 가중치로 6마리 (같은 종·같은 도구 없음, 메가스톤 최대 2개) */
export function usageTeam(rng: () => number = Math.random): PokemonSet[] | null {
	const u = usageFile();
	if (!u?.species.length) return null;
	const pool = u.species.filter(s => dex.species.get(s.name).exists);
	const team: PokemonSet[] = []; const picked: Entry[] = []; const bases = new Set<string>(); const items = new Set<string>();
	let megas = 0;
	for (let guard = 0; team.length < FORMAT.teamSize && guard < 60; guard++) {
		const weights: [Entry, number][] = pool.map(s => {
			if (bases.has(dex.species.get(s.name).baseSpecies)) return [s, 0];
			if (megas >= 2 && dex.species.get(s.name).isMega) return [s, 0];
			let w = s.usage;
			for (const t of picked) { const tm = t.teammates.find(([n]) => toID(n) === toID(s.name)); if (tm) w *= 1 + Math.max(0, tm[1]) * 4; }
			return [s, w];
		});
		const e = pick(weights, rng);
		if (!e) break;
		const set = usageSet(e, rng, items, megas < 2);
		if (!set || set.moves.length < 1) { bases.add(dex.species.get(e.name).baseSpecies); continue; }
		team.push(set); picked.push(e); bases.add(dex.species.get(set.species).baseSpecies);
		if (set.item) items.add(toID(set.item));
		if (dex.items.get(set.item).megaStone) megas++;
	}
	return team.length === FORMAT.teamSize ? team : null;
}

/** 한 종의 대표 세트 (가장 흔한 조합 + 무작위 몇 개) — 샘플 세트·AI 세트 추정용 */
export function usageSetsFor(speciesName: string, n = 2): PokemonSet[] {
	const sp = dex.species.get(speciesName);
	const base = sp.isMega ? dex.species.get(sp.battleOnly as string || sp.baseSpecies).name : sp.name;
	// 메가 전 종 이름으로 물으면 메가 항목(예: Gyarados-Mega)도 함께 본다 — 쓰는 비율이 높은 쪽 먼저
	const entries = (usageFile()?.species ?? []).filter(x => { const d = dex.species.get(x.name); return d.exists && (d.name === base || (d.isMega && (d.battleOnly || d.baseSpecies) === base)); })
		.sort((a, b) => b.usage - a.usage);
	if (!entries.length) return [];
	if (entries.length > 1) {
		const out: PokemonSet[] = [];
		for (const x of entries) for (const s of usageSetsFrom(x, n)) if (out.length < n + 1) out.push(s);
		return out;
	}
	return usageSetsFrom(entries[0], n);
}
function usageSetsFrom(e: Entry, n: number): PokemonSet[] {
	const top = (list: [string, number][], k = 1) => [...list].sort((a, b) => b[1] - a[1]).slice(0, k);
	const out: PokemonSet[] = [];
	// 1) 가장 흔한 것: 도구·특성·배분 1위 + 기술 상위 4
	const first = usageSet({ ...e, items: top(e.items), abilities: top(e.abilities), spreads: [...e.spreads].sort((a, b) => b[2] - a[2]).slice(0, 1), moves: top(e.moves, 4) }, () => 0.5);
	if (first) out.push(first);
	let seed = 1;
	const rng = () => { seed = (seed * 16807) % 2147483647; return seed / 2147483647; };
	for (let i = 0; out.length < n && i < n * 4; i++) {
		const s = usageSet(e, rng);
		if (s && !out.some(o => o.item === s.item && [...o.moves].sort().join() === [...s.moves].sort().join())) out.push(s);
	}
	return out;
}
