import { Dex } from '../sim';
import { MANIFEST } from '../config/manifest';
import { simFormatId, type RuleSet } from '../config/rules';

/** 실행 중 쓰는 룰 (config/rules.ts 의 RuleSet 에서 만든다) */
export interface Format {
	/** 시뮬레이터 포맷 id (커스텀 룰 포함) */
	id: string;
	/** config/rules.ts 의 key */
	key: string;
	label: string;
	gen: number;
	gameType: 'singles';
	teamSize: number;
	pickSize: number;
	level: number;
	/** 능력 포인트(SP): 능력치 하나당 최대, 합계 최대 */
	spPerStat: number;
	spTotal: number;
	gimmicks: { mega: boolean };
}

export function toFormat(r: RuleSet): Format {
	return {
		id: simFormatId(r), key: r.key, label: r.label, gen: r.gen, gameType: r.gameType,
		teamSize: r.teamSize, pickSize: r.pickSize, level: r.level, spPerStat: r.spPerStat, spTotal: r.spTotal, gimmicks: r.gimmicks,
	};
}

/** 이 버전의 룰 (config/manifest.ts → config/rules.ts) */
export const FORMAT = toFormat(MANIFEST.rules);
export const dex = Dex.forFormat(Dex.formats.get(FORMAT.id, true));

export type StatID = 'hp' | 'atk' | 'def' | 'spa' | 'spd' | 'spe';
export const STATS: StatID[] = ['hp', 'atk', 'def', 'spa', 'spd', 'spe'];

export interface PokemonSet {
	name: string;
	species: string;
	item: string;
	ability: string;
	nature: string;
	evs: Record<StatID, number>;
	ivs: Record<StatID, number>;
	moves: string[];
	level: number;
	gender: string;
}

/** Champions 능력치 계산 (Lv50, 개체값 없음): HP = 종족값+SP+75, 그 외 = (종족값+SP+20)×성격 */
export function calcStat(stat: StatID, base: number, sp: number, nature: string): number {
	if (stat === 'hp') return base === 1 ? 1 : base + sp + 75;
	let v = base + sp + 20;
	const n = dex.natures.get(nature);
	if (n.plus === stat) v = Math.floor((v * 110) / 100);
	else if (n.minus === stat) v = Math.floor((v * 90) / 100);
	return v;
}

/** 이 포맷에서 쓸 수 있는 종인가 (배틀 중에만 나오는 폼·메가 제외) */
export function isPickable(s: any): boolean {
	return s.exists && !s.isNonstandard && s.tier !== 'Illegal' && !s.battleOnly && !s.isMega && !s.cosmeticFormes?.includes?.(s.name);
}
