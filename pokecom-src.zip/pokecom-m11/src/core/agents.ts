import type { Agent } from './session';

/** 요청에서 가능한 선택지 목록 (싱글 기준, 메가진화만) */
export function legalChoices(req: any): string[] {
	const team = req.side.pokemon as any[];
	if (req.teamPreview) return [];
	// 부활의 기원(Revival Blessing): 기절한 포켓몬을 골라야 한다
	if (req.forceSwitch && team.some(p => p.reviving)) {
		const fainted = team.map((p, i) => ({ p, i: i + 1 })).filter(({ p }) => !p.active && p.condition.endsWith(' fnt')).map(({ i }) => `switch ${i}`);
		return fainted.length ? fainted : ['pass'];
	}
	const switches = team
		.map((p, i) => ({ p, i: i + 1 }))
		.filter(({ p }) => !p.active && !p.condition.endsWith(' fnt'))
		.map(({ i }) => `switch ${i}`);
	if (req.forceSwitch) return switches.length ? switches : ['pass'];
	const active = req.active?.[0];
	if (!active) return ['default'];
	const moves: string[] = [];
	active.moves.forEach((m: any, i: number) => {
		if (m.disabled || (m.pp <= 0 && m.maxpp > 0)) return;
		moves.push(`move ${i + 1}`);
		if (active.canMegaEvo) moves.push(`move ${i + 1} mega`);
	});
	if (!moves.length) moves.push('move 1');
	return active.trapped ? moves : [...moves, ...switches];
}

export const RandomAgent: Agent = {
	id: 'random',
	label: '랜덤 AI',
	choose(req, ctx) {
		const rng = ctx.rng;
		if (req.teamPreview) {
			const n = req.side.pokemon.length;
			const order = Array.from({ length: n }, (_, i) => i + 1);
			for (let i = n - 1; i > 0; i--) { const j = Math.floor(rng() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
			return `team ${order.slice(0, ctx.format.pickSize).join('')}`;
		}
		const all = legalChoices(req);
		const moves = all.filter(c => c.startsWith('move'));
		const switches = all.filter(c => c.startsWith('switch'));
		// 메가진화가 가능하면 메가 선택지를 우선
		const megas = moves.filter(c => c.endsWith('mega'));
		const pool = moves.length && (!switches.length || rng() < 0.85) ? (megas.length ? megas : moves) : switches.length ? switches : ['default'];
		return pool[Math.floor(rng() * pool.length)];
	},
};
