// Elo 래더: 내 레이팅, 전적, AI 상대 매칭. 기록은 이 기기의 IndexedDB 에만 저장한다.
import { MANIFEST } from '../config/manifest';
import { RATING_POLICY as P, GRADES, type Grade } from '../config/rating';
import { PROFILES, type Profile as AIProfile } from '../config/ai';
export { GRADES, type Grade };

export interface GameRecord {
	id?: number;
	at: number;                 // epoch ms
	result: 'W' | 'L' | 'T';
	opp: { id: string; label: string; rating: number };
	before: number; after: number; delta: number;
	myPicks: string[]; oppTeam: string[]; turns: number;
}
export interface LadderState {
	rating: number; games: number; wins: number; losses: number; ties: number;
	streak: number;             // 양수 연승, 음수 연패
	bestStreak: number; peak: number;
}

export const START_RATING = P.start;
const FRESH: LadderState = { rating: START_RATING, games: 0, wins: 0, losses: 0, ties: 0, streak: 0, bestStreak: 0, peak: START_RATING };

// ---------- 상대 프로필 (AI 자가 대전으로 측정한 레이팅) ----------
type Measured = { id: string; rating: number };
const MEASURED: Measured[] = MANIFEST.data.ratings.profiles;
export interface RatedProfile extends AIProfile { rating: number }
export const RATED: RatedProfile[] = PROFILES
	.map(p => ({ ...p, rating: MEASURED.find(m => m.id === p.id)?.rating ?? 800 }))
	.sort((a, b) => a.rating - b.rating);

/** 내 레이팅 근처 상대. 조금 더 센 쪽이 약간 더 자주 나온다 (−50 ~ +100). */
export function matchmake(rating: number, rng = Math.random): RatedProfile {
	const target = rating + P.matchWindow.min + rng() * (P.matchWindow.max - P.matchWindow.min);
	let best = RATED[0];
	for (const p of RATED) if (Math.abs(p.rating - target) < Math.abs(best.rating - target)) best = p;
	return best;
}

// ---------- Elo ----------
export function kFactor(games: number) { return games < P.placementGames ? P.kPlacement : P.kNormal; }
export function expected(me: number, opp: number) { return 1 / (1 + Math.pow(10, (opp - me) / 400)); }
export function eloDelta(me: number, opp: number, score: number, games: number) {
	return Math.round(kFactor(games) * (score - expected(me, opp)));
}

// ---------- 등급 (정의는 config/rating.ts) ----------
export function gradeOf(r: number): Grade { let g = GRADES[0]; for (const x of GRADES) if (r >= x.min) g = x; return g; }
export function nextGrade(r: number): Grade | null { return GRADES.find(g => g.min > r) ?? null; }

// ---------- 저장소 ----------
const DB = MANIFEST.storage.ladderDb;
let dbp: Promise<IDBDatabase | null> | null = null;
function db(): Promise<IDBDatabase | null> {
	if (!dbp) dbp = new Promise(res => {
		try {
			const r = indexedDB.open(DB, 1);
			r.onupgradeneeded = () => {
				r.result.createObjectStore('games', { keyPath: 'id', autoIncrement: true });
				r.result.createObjectStore('meta');
			};
			r.onsuccess = () => res(r.result);
			r.onerror = () => res(null);
		} catch { res(null); }
	});
	return dbp;
}
function req<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest | void): Promise<T | undefined> {
	return db().then(d => new Promise(res => {
		if (!d) return res(undefined);
		try {
			const t = d.transaction(store, mode);
			const r = fn(t.objectStore(store));
			t.oncomplete = () => res(r ? (r.result as T) : undefined);
			t.onerror = () => res(undefined);
		} catch { res(undefined); }
	}));
}

// IndexedDB 가 안 되는 환경(시크릿 창 등)을 위한 메모리 사본
let memState: LadderState = { ...FRESH };
let memGames: GameRecord[] = [];

export async function loadState(): Promise<LadderState> {
	const s = await req<LadderState>('meta', 'readonly', st => st.get('state'));
	if (s) memState = { ...FRESH, ...s };
	return { ...memState };
}
export async function loadGames(): Promise<GameRecord[]> {
	const g = await req<GameRecord[]>('games', 'readonly', st => st.getAll());
	if (g) memGames = g;
	return [...memGames].sort((a, b) => a.at - b.at);
}

/** 한 판 결과 반영. 반환값: 기록 (변동폭 포함) */
export async function recordGame(input: Omit<GameRecord, 'before' | 'after' | 'delta' | 'at'>): Promise<{ rec: GameRecord; state: LadderState }> {
	const s = await loadState();
	const score = input.result === 'W' ? 1 : input.result === 'L' ? 0 : P.tieScore;
	const delta = eloDelta(s.rating, input.opp.rating, score, s.games);
	const rec: GameRecord = { ...input, at: Date.now(), before: s.rating, after: Math.max(P.floor, s.rating + delta), delta };
	rec.delta = rec.after - rec.before;
	s.rating = rec.after; s.games++;
	if (input.result === 'W') { s.wins++; s.streak = s.streak > 0 ? s.streak + 1 : 1; }
	else if (input.result === 'L') { s.losses++; s.streak = s.streak < 0 ? s.streak - 1 : -1; }
	else { s.ties++; s.streak = 0; }
	s.bestStreak = Math.max(s.bestStreak, s.streak);
	s.peak = Math.max(s.peak, s.rating);
	memState = s; memGames.push(rec);
	await req('games', 'readwrite', st => st.add(rec));
	await req('meta', 'readwrite', st => st.put(s, 'state'));
	return { rec, state: { ...s } };
}

export async function resetLadder() {
	memState = { ...FRESH }; memGames = [];
	await req('games', 'readwrite', st => st.clear());
	await req('meta', 'readwrite', st => st.put({ ...FRESH }, 'state'));
}

/** 이 상대에게 이기면/지면 얼마나 움직이나 (미리보기용) */
export function preview(state: LadderState, oppRating: number) {
	return {
		win: eloDelta(state.rating, oppRating, 1, state.games),
		lose: eloDelta(state.rating, oppRating, 0, state.games),
		winProb: expected(state.rating, oppRating),
	};
}
