// 시뮬레이터 BattleStream 래퍼: p1 = 사람, p2 = Agent
import { BattleStream, getPlayerStreams, Teams } from '../sim';
import type { Format, PokemonSet } from './format';
import { BattleView } from './view';
import { resolveMoveType, type MoveTypeInfo } from './movetype';

export interface AgentContext {
	format: Format; log: string[]; rng: () => number;
	/** 이 에이전트 시점의 공개 정보 (AI 판단용) */
	view?: BattleView;
	/** 이 에이전트 자신의 파티 */
	team?: PokemonSet[];
}
export interface Agent {
	id: string;
	label: string;
	choose(request: any, ctx: AgentContext): string | Promise<string>;
}
export interface SessionOptions {
	format: Format;
	p1: { name: string; team: PokemonSet[] };
	p2: { name: string; team: PokemonSet[]; agent: Agent };
	seed?: number[];
	rng?: () => number;
}
export interface SessionEvents {
	onLine(line: string): void;
	onRequest(req: any): void;
	onEnd(winner: string | null): void;
	onError?(msg: string): void;
	onFlush?(): void;
}

function debounce(fn: () => void) {
	let t: ReturnType<typeof setTimeout> | null = null;
	return () => { if (t) clearTimeout(t); t = setTimeout(() => { t = null; fn(); }, 0); };
}

export class BattleSession {
	private streams: any;
	private stream: any;
	private p1Pending: any = null;
	private p2Pending: any = null;
	private lastP1Req: any = null;
	p1Log: string[] = [];
	p2Log: string[] = [];
	private p2View: BattleView;
	ended = false;
	winner: string | null = null;
	readonly format: Format;

	constructor(private opts: SessionOptions, private ev: SessionEvents) {
		this.format = opts.format;
		this.p2View = new BattleView(opts.p1.name, opts.p2.name);
		const stream = new BattleStream();
		this.stream = stream;
		this.streams = getPlayerStreams(stream);
		this.readP1(); this.readP2(); this.readOmni();
		const start: any = { formatid: opts.format.id };
		if (opts.seed) start.seed = opts.seed;
		this.streams.omniscient.write(
			`>start ${JSON.stringify(start)}\n` +
			`>player p1 ${JSON.stringify({ name: opts.p1.name, team: Teams.pack(opts.p1.team) })}\n` +
			`>player p2 ${JSON.stringify({ name: opts.p2.name, team: Teams.pack(opts.p2.team) })}`,
		);
	}

	private flushP1 = debounce(() => {
		this.ev.onFlush?.();
		if (this.ended) return;
		const req = this.p1Pending;
		this.p1Pending = null;
		if (req && !req.wait) { this.lastP1Req = req; this.ev.onRequest(req); }
	});

	private flushP2 = debounce(async () => {
		if (this.ended) return;
		const req = this.p2Pending;
		this.p2Pending = null;
		if (!req || req.wait) return;
		const rng = this.opts.rng ?? Math.random;
		let choice: string;
		try { choice = await this.opts.p2.agent.choose(req, { format: this.format, log: this.p2Log, rng, view: this.p2View, team: this.opts.p2.team }); }
		catch (e) { console.warn('[AI 판단 오류]', e); choice = 'default'; }
		this.streams.p2.write(choice);
	});

	/** 내(p1) 싸우는 포켓몬의 기술 타입 (특성·기술 효과 반영). mega: 메가진화 후 특성으로 미리 보기 */
	previewMoveTypes(mega = false): MoveTypeInfo[] | null {
		const b = this.stream?.battle;
		const p = b?.p1?.active?.[0];
		if (!b || !p) return null;
		let ability: string | undefined;
		if (mega && p.canMegaEvo) ability = b.dex.species.get(p.canMegaEvo).abilities['0'];
		return p.moveSlots.map((s: any) => resolveMoveType(b, p, b.p2.active[0], s.id, ability));
	}

	choose(choice: string) { if (!this.ended) this.streams.p1.write(choice); }
	forfeit() { if (!this.ended) this.streams.omniscient.write('>forcelose p1'); }

	private async readP1() {
		for await (const chunk of this.streams.p1) {
			for (const line of (chunk as string).split('\n')) {
				if (line.startsWith('|request|')) { const j = line.slice(9); if (j) this.p1Pending = JSON.parse(j); continue; }
				if (line.startsWith('|error|')) {
					this.ev.onError?.(line.slice(7));
					if (this.lastP1Req && !line.includes('[Unavailable choice]')) this.p1Pending = this.lastP1Req;
					continue;
				}
				if (line.startsWith('|win|')) this.winner = line.slice(5);
				if (line === '|tie') this.winner = null;
				this.p1Log.push(line);
				this.ev.onLine(line);
				if (line.startsWith('|win|') || line === '|tie') this.finish();
			}
			this.flushP1();
		}
	}
	private async readP2() {
		for await (const chunk of this.streams.p2) {
			for (const line of (chunk as string).split('\n')) {
				if (line.startsWith('|request|')) { const j = line.slice(9); if (j) this.p2Pending = JSON.parse(j); continue; }
				if (line.startsWith('|error|')) { console.warn('[AI 선택 오류]', line); continue; }
				this.p2Log.push(line);
				this.p2View.add(line);
			}
			this.flushP2();
		}
	}
	private async readOmni() { for await (const _ of this.streams.omniscient) { /* drain */ } }
	private finish() {
		if (this.ended) return;
		this.ended = true;
		setTimeout(() => { this.ev.onFlush?.(); this.ev.onEnd(this.winner); }, 0);
	}
}
