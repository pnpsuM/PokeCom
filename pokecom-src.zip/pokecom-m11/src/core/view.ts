// 배틀 프로토콜 → 화면 상태 + 한국어 로그 (M1 BattleView 복원 + Champions/9세대 보강)
import { toID } from '../sim';
import {
	koSpecies, koMove, koAbility, koItem, koType, koEffect, STAT_KO, STATUS_KO, josa, eun, iga, eul, euro,
} from './ko';

export interface MonState {
	nick: string; species: string; level: number; gender: string;
	hp: number; maxhp: number; status: string; fainted: boolean; revealed: boolean;
	moves: string[]; item?: string; ability?: string;
}
export interface SideState {
	id: 'p1' | 'p2'; name: string; team: MonState[]; active: MonState | null;
	boosts: Record<string, number>; volatiles: string[]; conditions: string[];
}
export interface LogEntry { kind: 'text' | 'major' | 'info' | 'turn' | 'hp' | 'win'; text: string; side?: string }
export interface ViewState {
	turn: number; weather: string; terrain: string[]; winner: string | null; ended: boolean;
	log: LogEntry[]; sides: { p1: SideState; p2: SideState };
}

export function parseDetails(details: string) {
	const parts = details.split(', ');
	let level = 100, gender = '';
	for (const p of parts.slice(1)) {
		if (/^L\d+$/.test(p)) level = +p.slice(1);
		else if (p === 'M' || p === 'F') gender = p;
	}
	return { species: parts[0], level, gender };
}
export function parseHP(cond: string) {
	const [hpPart, status = ''] = cond.split(' ');
	if (hpPart === '0' || status === 'fnt') return { hp: 0, maxhp: 0, status: '', fnt: true };
	const [hp, maxhp] = hpPart.split('/').map(Number);
	return { hp, maxhp: maxhp || 100, status, fnt: false };
}
const pct = (m: MonState) => (m.maxhp ? Math.round((m.hp / m.maxhp) * 100) : 0);

const WEATHER_START: Record<string, string> = {
	SunnyDay: '햇살이 강해졌다!', RainDance: '비가 내리기 시작했다!', Sandstorm: '모래바람이 불기 시작했다!',
	Hail: '싸라기눈이 내리기 시작했다!', Snowscape: '눈이 내리기 시작했다!', Snow: '눈이 내리기 시작했다!',
	DesolateLand: '햇살이 아주 강해졌다!', PrimordialSea: '강한 비가 내리기 시작했다!',
	DeltaStream: '수수께끼의 난기류가 비행 포켓몬을 지킨다!', none: '날씨가 원래대로 돌아왔다.',
};
export const WEATHER_KO: Record<string, string> = {
	SunnyDay: '쾌청', RainDance: '비', Sandstorm: '모래바람', Hail: '싸라기눈', Snowscape: '설경', Snow: '설경',
	DesolateLand: '끝의대지', PrimordialSea: '시작의바다', DeltaStream: '델타스트림',
};
const PROTECTS = ['protect', 'kingsshield', 'spikyshield', 'banefulbunker', 'detect', 'silktrap', 'burningbulwark', 'obstruct', 'maxguard'];

export class BattleView {
	state: ViewState;
	/** 각 편이 마지막으로 쓴 기술 (AI 판단용) */
	lastMove: Record<'p1' | 'p2', string> = { p1: '', p2: '' };

	constructor(p1Name: string, p2Name: string) {
		const side = (id: 'p1' | 'p2', name: string): SideState => ({ id, name, team: [], active: null, boosts: {}, volatiles: [], conditions: [] });
		this.state = { turn: 0, weather: '', terrain: [], winner: null, ended: false, log: [], sides: { p1: side('p1', p1Name), p2: side('p2', p2Name) } };
	}

	sideOf(ident: string) { return ident.slice(0, 2) as 'p1' | 'p2'; }
	nickOf(ident: string) { const i = ident.indexOf(': '); return i >= 0 ? ident.slice(i + 2) : ident; }
	monOf(ident: string): MonState | undefined {
		const side = this.state.sides[this.sideOf(ident)];
		const nick = this.nickOf(ident);
		if (/^p\da:/.test(ident) && side.active?.nick === nick) return side.active;
		return side.team.find(m => m.nick === nick);
	}
	who(ident: string): string {
		if (!ident) return '';
		const m = this.monOf(ident);
		const name = koSpecies(m ? m.species : this.nickOf(ident));
		return this.sideOf(ident) === 'p2' ? `상대 ${name}` : name;
	}
	sideName(ident: string) { return ident.startsWith('p2') ? '상대' : '우리'; }
	push(kind: LogEntry['kind'], text: string, side?: string) { this.state.log.push({ kind, text, side }); }

	/** 요청(request)에 담긴 내 파티 정보로 상태를 맞춘다 */
	setOwnTeam(pokemon: any[]) {
		const side = this.state.sides.p1;
		for (const p of pokemon) {
			const nick = this.nickOf(p.ident);
			const d = parseDetails(p.details);
			const hp = parseHP(p.condition);
			let m = side.team.find(x => x.nick === nick);
			if (!m) {
				m = { nick, species: d.species, level: d.level, gender: d.gender, hp: 0, maxhp: 0, status: '', fainted: false, revealed: false, moves: [] };
				side.team.push(m);
			}
			m.species = d.species; m.hp = hp.hp; m.maxhp = hp.maxhp; m.status = hp.status; m.fainted = hp.fnt;
			m.item = p.item; m.ability = p.baseAbility; m.moves = p.moves;
		}
	}

	upsert(sideId: 'p1' | 'p2', nick: string, details: string): MonState {
		const side = this.state.sides[sideId];
		const d = parseDetails(details);
		let m = side.team.find(x => x.nick === nick);
		if (!m) {
			m = side.team.find(x => !x.revealed && (x.species === d.species || toID(x.species) === toID(d.species.split('-')[0]) ||
				(x.species.endsWith('-*') && d.species.startsWith(x.species.slice(0, -2)))));
			if (m) m.nick = nick;
		}
		if (!m) {
			m = { nick, species: d.species, level: d.level, gender: d.gender, hp: 100, maxhp: 100, status: '', fainted: false, revealed: true, moves: [] };
			side.team.push(m);
		}
		m.species = d.species; m.level = d.level; m.gender = d.gender; m.revealed = true;
		return m;
	}

	setHP(ident: string, cond: string) {
		const m = this.monOf(ident);
		if (!m || !cond) return m;
		const hp = parseHP(cond);
		if (hp.fnt) { m.hp = 0; m.fainted = true; m.status = ''; } else { m.hp = hp.hp; m.maxhp = hp.maxhp; m.status = hp.status; }
		return m;
	}

	add(line: string) {
		if (!line.startsWith('|')) { if (line.trim()) this.push('info', line); return; }
		const parts = line.slice(1).split('|');
		const cmd = parts[0];
		const args = parts.slice(1).filter(p => !p.startsWith('['));
		const kw: Record<string, string> = {};
		for (const p of parts.slice(1)) { const m = p.match(/^\[(\w+)\]\s?(.*)$/); if (m) kw[m[1]] = m[2]; }
		const st = this.state;
		const from = kw.from ? koEffect(kw.from) : '';
		const of = kw.of ? this.who(kw.of) : '';
		const pre = kw.from ? `[${from}] ` : '';
		// [from] item:/ability: 로 드러난 도구·특성 기록 (AI 세트 추정용)
		if (kw.from && args[0] && /^p\d/.test(args[0])) {
			const fm = kw.from.match(/^(item|ability):\s*(.*)$/);
			if (fm) {
				const owner = fm[1] === 'ability' && kw.of ? this.monOf(kw.of) : this.monOf(args[0]);
				if (owner) { if (fm[1] === 'item') owner.item = fm[2]; else owner.ability = fm[2]; }
			}
		}
		if (cmd === 'move' && args[0]) this.lastMove[this.sideOf(args[0])] = args[1];

		switch (cmd) {
		case 'player': if (args[1]) st.sides[args[0] as 'p1'].name = args[1]; break;
		case 'poke': {
			const d = parseDetails(args[1]);
			st.sides[args[0] as 'p1'].team.push({ nick: d.species, species: d.species, level: d.level, gender: d.gender, hp: 100, maxhp: 100, status: '', fainted: false, revealed: false, moves: [] });
			break;
		}
		case 'teampreview': this.push('info', '팀 프리뷰: 선출할 포켓몬을 고른다'); break;
		case 'start': this.push('major', '배틀 시작!'); break;
		case 'turn': st.turn = +args[0]; this.push('turn', `${args[0]}턴`); break;
		case 'switch': case 'drag': case 'replace': {
			const sid = this.sideOf(args[0]);
			const side = st.sides[sid];
			const m = this.upsert(sid, this.nickOf(args[0]), args[1]);
			side.active = m; side.boosts = {}; side.volatiles = [];
			if (args[2]) this.setHP(args[0], args[2]);
			const name = koSpecies(m.species);
			const opp = sid === 'p2' ? '상대 ' : '';
			if (cmd === 'drag') this.push('text', `${opp}${iga(name)} 끌려 나왔다!`, sid);
			else if (cmd === 'replace') this.push('text', `${opp}${name}의 정체가 드러났다!`, sid);
			else if (sid === 'p1') this.push('major', `가랏! ${name}!`, 'p1');
			else this.push('major', `${eun(side.name)} ${eul(name)} 내보냈다!`, 'p2');
			break;
		}
		case 'detailschange': { const m = this.monOf(args[0]); if (m) m.species = parseDetails(args[1]).species; break; }
		case '-formechange': {
			const m = this.monOf(args[0]);
			if (m && args[1]) {
				m.species = args[1];
				if (!kw.silent) this.push('text', `${eun(this.who(args[0]))} ${euro(koSpecies(args[1]))} 모습을 바꿨다!`, this.sideOf(args[0]));
			}
			break;
		}
		case 'faint': {
			const m = this.monOf(args[0]);
			if (m) { m.fainted = true; m.hp = 0; }
			this.push('major', `${eun(this.who(args[0]))} 쓰러졌다!`, this.sideOf(args[0]));
			break;
		}
		case 'move': {
			const m = this.monOf(args[0]);
			if (m && this.sideOf(args[0]) === 'p2' && !m.moves.includes(args[1]) && !kw.from) m.moves.push(args[1]);
			this.push('text', `${pre}${this.who(args[0])}의 ${koMove(args[1])}!`, this.sideOf(args[0]));
			if (kw.miss !== undefined && args[2]) this.push('text', `${this.who(args[2])}에게는 맞지 않았다!`);
			break;
		}
		case 'cant': {
			const w = this.who(args[0]);
			const reason = toID(args[1]);
			const msg: Record<string, string> = {
				par: `${eun(w)} 몸이 저려서 움직일 수 없다!`, slp: `${eun(w)} 쿨쿨 잠들어 있다.`, frz: `${eun(w)} 얼어 버려서 움직일 수 없다!`,
				flinch: `${eun(w)} 풀이 죽어 기술을 쓸 수 없다!`, recharge: `${eun(w)} 공격의 반동으로 움직일 수 없다!`,
				nopp: `${w}의 기술은 PP가 없다!`, taunt: `${eun(w)} 도발당해서 ${args[2] ? eul(koMove(args[2])) : '기술을'} 쓸 수 없다!`,
				disable: `${w}의 ${args[2] ? koMove(args[2]) : '기술'}은(는) 사용할 수 없다!`, focuspunch: `${eun(w)} 집중이 흐트러져 기술을 쓸 수 없다!`,
				truant: `${eun(w)} 게으름을 피우고 있다!`,
			};
			this.push('text', msg[reason] ?? `${eun(w)} 움직일 수 없다! (${koEffect(args[1])})`, this.sideOf(args[0]));
			break;
		}
		case '-damage': case '-heal': case '-sethp': {
			const m = this.monOf(args[0]);
			const before = m ? pct(m) : 0;
			this.setHP(args[0], args[1]);
			const after = m ? pct(m) : 0;
			const w = this.who(args[0]);
			const sid = this.sideOf(args[0]);
			if (cmd === '-damage' && kw.from) {
				const src = toID(kw.from.replace(/^\w+:\s*/, ''));
				const msg: Record<string, string> = {
					brn: `${eun(w)} 화상 데미지를 입었다!`, psn: `${eun(w)} 독 데미지를 입었다!`, tox: `${eun(w)} 독 데미지를 입었다!`,
					recoil: `${eun(w)} 공격의 반동을 받았다!`, sandstorm: `모래바람이 ${eul(w)} 덮쳤다!`, hail: `싸라기눈이 ${eul(w)} 덮쳤다!`,
					lifeorb: `${eun(w)} 생명을 조금 깎았다!`, stealthrock: `뾰족한 바위가 ${w}에게 박혔다!`, spikes: `${eun(w)} 압정에 데미지를 입었다!`,
					confusion: '영문도 모른 채 자신을 공격했다!', leechseed: `씨뿌리기가 ${w}의 체력을 빼앗는다!`,
					roughskin: `${eun(w)} 상처를 입었다!`, ironbarbs: `${eun(w)} 상처를 입었다!`, rockyhelmet: `${eun(w)} 울퉁불퉁멧으로 데미지를 입었다!`,
					curse: `${eun(w)} 저주로 데미지를 입었다!`, partiallytrapped: `${eun(w)} 데미지를 입었다!`, saltcure: `${eun(w)} 소금절이 데미지를 입었다!`,
				};
				this.push('text', msg[src] ?? `${eun(w)} ${euro(from)} 데미지를 입었다!`, sid);
			} else if (cmd === '-heal' && kw.from && toID(kw.from) === 'drain') {
				this.push('text', `${of ? of + '의 ' : ''}체력을 흡수했다!`, sid);
			} else if (cmd === '-heal' && kw.from) {
				this.push('text', `${eun(w)} ${euro(from)} 체력을 회복했다!`, sid);
			} else if (cmd === '-heal' && !kw.silent) {
				this.push('text', `${w}의 체력이 회복되었다!`, sid);
			}
			if (m && !kw.silent && before !== after) {
				const own = sid === 'p1' ? ` (${m.hp}/${m.maxhp})` : '';
				const diff = after - before;
				this.push('hp', `${w} ${diff > 0 ? '+' : ''}${diff}% → ${after}%${own}`, sid);
			}
			break;
		}
		case '-supereffective': this.push('text', '효과가 굉장했다!'); break;
		case '-resisted': this.push('text', '효과가 별로인 듯하다…'); break;
		case '-immune': this.push('text', `${pre}${this.who(args[0])}에게는 효과가 없는 것 같다…`); break;
		case '-crit': this.push('text', '급소에 맞았다!'); break;
		case '-miss': this.push('text', `${args[1] ? this.who(args[1]) : this.who(args[0])}에게는 맞지 않았다!`); break;
		case '-fail': {
			const what = toID(args[1] ?? '');
			if (what === 'heal') this.push('text', `${this.who(args[0])}의 체력은 이미 가득 차 있다!`);
			else if (what === 'unboost') this.push('text', `${this.who(args[0])}의 능력은 떨어지지 않는다!`);
			else this.push('text', `${pre}그러나 실패했다!`);
			break;
		}
		case '-notarget': this.push('text', '그러나 상대가 없다!'); break;
		case '-hitcount': this.push('text', `${args[1]}번 맞았다!`); break;
		case '-ohko': this.push('text', '일격필살!'); break;
		case '-status': {
			const m = this.monOf(args[0]);
			if (m) m.status = args[1];
			const w = this.who(args[0]);
			const msg: Record<string, string> = {
				brn: `${eun(w)} 화상을 입었다!`, par: `${eun(w)} 마비되어 기술이 나오기 어려워졌다!`, slp: `${eun(w)} 잠들어 버렸다!`,
				frz: `${eun(w)} 얼어붙었다!`, psn: `${eun(w)} 독에 걸렸다!`, tox: `${eun(w)} 맹독을 입었다!`,
			};
			this.push('text', pre + (msg[args[1]] ?? `${w}: ${args[1]}`), this.sideOf(args[0]));
			break;
		}
		case '-curestatus': {
			const m = this.monOf(args[0]);
			if (m) m.status = '';
			if (!kw.silent) this.push('text', `${this.who(args[0])}의 ${iga(STATUS_KO[args[1]] ?? args[1])} 나았다!`, this.sideOf(args[0]));
			break;
		}
		case '-cureteam':
			for (const m of st.sides[this.sideOf(args[0])].team) m.status = '';
			this.push('text', `${this.sideName(args[0])} 편의 상태 이상이 모두 나았다!`);
			break;
		case '-boost': case '-unboost': {
			const sid = this.sideOf(args[0]);
			const delta = +args[2] * (cmd === '-boost' ? 1 : -1);
			const b = st.sides[sid].boosts;
			b[args[1]] = Math.max(-6, Math.min(6, (b[args[1]] ?? 0) + delta));
			if (!b[args[1]]) delete b[args[1]];
			const stat = STAT_KO[args[1]] ?? args[1];
			const w = this.who(args[0]);
			const n = Math.abs(+args[2]);
			const up = cmd === '-boost';
			if (n === 0) this.push('text', `${pre}${w}의 ${iga(stat)} 더 이상 ${up ? '올라가지' : '떨어지지'} 않는다!`, sid);
			else this.push('text', `${pre}${w}의 ${iga(stat)} ${n >= 3 ? '매우 크게 ' : n === 2 ? '크게 ' : ''}${up ? '올라갔다' : '떨어졌다'}!`, sid);
			break;
		}
		case '-setboost': {
			const sid = this.sideOf(args[0]);
			st.sides[sid].boosts[args[1]] = +args[2];
			this.push('text', `${this.who(args[0])}의 ${STAT_KO[args[1]] ?? args[1]} ${args[2]}단계!`, sid);
			break;
		}
		case '-clearboost':
			st.sides[this.sideOf(args[0])].boosts = {};
			this.push('text', `${this.who(args[0])}의 능력 변화가 원래대로 돌아왔다!`);
			break;
		case '-clearnegativeboost': {
			const b = st.sides[this.sideOf(args[0])].boosts;
			for (const k in b) if (b[k] < 0) delete b[k];
			break;
		}
		case '-clearallboost':
			st.sides.p1.boosts = {}; st.sides.p2.boosts = {};
			this.push('text', '모든 능력 변화가 원래대로 돌아왔다!');
			break;
		case '-invertboost': { const b = st.sides[this.sideOf(args[0])].boosts; for (const k in b) b[k] = -b[k]; break; }
		case '-copyboost': this.push('text', `${eun(this.who(args[0]))} ${this.who(args[1])}의 능력 변화를 복사했다!`); break;
		case '-swapboost': this.push('text', `${eun(this.who(args[0]))} 능력 변화를 바꿔 넣었다!`); break;
		case '-weather': {
			if (kw.upkeep !== undefined) break;
			st.weather = args[0] === 'none' ? '' : args[0];
			this.push('info', (kw.from ? `[${of ? of + '의 ' : ''}${from}] ` : '') + (WEATHER_START[args[0]] ?? args[0]));
			break;
		}
		case '-fieldstart': {
			const name = koEffect(args[0]);
			if (/terrain/i.test(args[0])) st.terrain = st.terrain.filter(t => !/terrain/i.test(t));
			st.terrain.push(args[0].replace(/^move:\s*/, ''));
			this.push('info', `${iga(name)} 펼쳐졌다!` + (of ? ` (${of})` : ''));
			break;
		}
		case '-fieldend': {
			const t = args[0].replace(/^move:\s*/, '');
			st.terrain = st.terrain.filter(x => x !== t);
			this.push('info', `${iga(koEffect(args[0]))} 사라졌다.`);
			break;
		}
		case '-sidestart': {
			const sid = args[0].slice(0, 2) as 'p1' | 'p2';
			const c = args[1].replace(/^move:\s*/, '');
			if (!st.sides[sid].conditions.includes(c)) st.sides[sid].conditions.push(c);
			this.push('info', `${this.sideName(sid)} 편: ${koEffect(args[1])}!`);
			break;
		}
		case '-sideend': {
			const sid = args[0].slice(0, 2) as 'p1' | 'p2';
			const c = args[1].replace(/^move:\s*/, '');
			st.sides[sid].conditions = st.sides[sid].conditions.filter(x => x !== c);
			this.push('info', `${this.sideName(sid)} 편의 ${iga(koEffect(args[1]))} 사라졌다.`);
			break;
		}
		case '-start': {
			const sid = this.sideOf(args[0]);
			const w = this.who(args[0]);
			const eff = toID(args[1].replace(/^\w+:\s*/, ''));
			if (eff === 'typechange') { this.push('text', `${eun(w)} ${args[2] ? koType(args[2]) : ''} 타입이 되었다!`, sid); break; }
			if (!st.sides[sid].volatiles.includes(eff)) st.sides[sid].volatiles.push(eff);
			const msg: Record<string, string> = {
				confusion: `${eun(w)} 혼란에 빠졌다!`, substitute: `${w}의 대타가 나타났다!`, taunt: `${eun(w)} 도발에 넘어갔다!`,
				leechseed: `${w}에게 씨앗을 심었다!`, encore: `${eun(w)} 앙코르를 받았다!`, perish3: `${w}: 멸망의노래 카운트 3`,
				perish2: `${w}: 멸망의노래 카운트 2`, perish1: `${w}: 멸망의노래 카운트 1`, perish0: `${w}: 멸망의노래 카운트 0`,
				yawn: `${eun(w)} 졸음이 몰려왔다!`, focusenergy: `${eun(w)} 기합이 들어갔다!`,
				disable: `${w}의 ${args[2] ? koMove(args[2]) : '기술'} 사용이 봉해졌다!`, flashfire: `${w}의 불꽃 위력이 올라갔다!`,
				slowstart: `${eun(w)} 제 컨디션을 발휘하지 못한다!`, curse: `${eun(w)} 저주를 받았다!`, torment: `${eun(w)} 트집을 잡혔다!`,
				attract: `${eun(w)} 헤롱헤롱해졌다!`, saltcure: `${eun(w)} 소금에 절여졌다!`,
				protosynthesis: `${w}의 ${iga(STAT_KO[toID(args[2] ?? '')] ?? '능력')} 올라갔다! (고대활성)`,
				quarkdrive: `${w}의 ${iga(STAT_KO[toID(args[2] ?? '')] ?? '능력')} 올라갔다! (쿼크차지)`,
			};
			if (eff.startsWith('perish') && !msg[eff]) break;
			this.push('text', pre + (msg[eff] ?? `${w}: ${koEffect(args[1])}`), sid);
			break;
		}
		case '-end': {
			const sid = this.sideOf(args[0]);
			const eff = toID(args[1].replace(/^\w+:\s*/, ''));
			st.sides[sid].volatiles = st.sides[sid].volatiles.filter(v => v !== eff);
			const w = this.who(args[0]);
			const msg: Record<string, string> = {
				confusion: `${w}의 혼란이 풀렸다!`, substitute: `${w}의 대타는 사라져 버렸다…`, taunt: `${w}의 도발 효과가 풀렸다!`,
				encore: `${w}의 앙코르가 끝났다!`, disable: `${w}의 사슬묶기가 풀렸다!`,
			};
			if (!kw.silent) this.push('text', msg[eff] ?? `${w}: ${koEffect(args[1])} 종료`, sid);
			break;
		}
		case '-singleturn': case '-activate': {
			const w = args[0] ? this.who(args[0]) : '';
			const eff = toID(args[1].replace(/^\w+:\s*/, ''));
			if (cmd === '-activate' && PROTECTS.includes(eff)) { this.push('text', `${eun(w)} 공격으로부터 몸을 지켰다!`); break; }
			const msg: Record<string, string> = {
				protect: `${eun(w)} 방어 태세에 들어갔다!`, endure: `${eun(w)} 버티기 태세에 들어갔다!`,
				focuspunch: `${eun(w)} 집중력을 높이고 있다!`, substitute: `대타가 ${w} 대신 공격을 받았다!`, confusion: `${eun(w)} 혼란에 빠져 있다!`,
				sturdy: `${eun(w)} 공격을 버텼다!`, focussash: `${eun(w)} 기합의띠로 버텼다!`, disguise: '탈이 대신 공격을 받았다!',
				trick: `${eun(w)} 도구를 서로 바꿨다!`, switcheroo: `${eun(w)} 도구를 서로 바꿨다!`, magicbounce: `${eun(w)} 기술을 되받아쳤다!`,
			};
			for (const p of PROTECTS) msg[p] ??= `${eun(w)} 방어 태세에 들어갔다!`;
			this.push('text', msg[eff] ?? `[${w ? w + ' · ' : ''}${koEffect(args[1])}]`);
			break;
		}
		case '-mega': this.push('major', `${eun(this.who(args[0]))} 메가진화했다!`, this.sideOf(args[0])); break;
		case '-primal': this.push('major', `${eun(this.who(args[0]))} 원시회귀했다!`); break;
		case '-zbroken': this.push('text', `${eun(this.who(args[0]))} 방어를 뚫고 공격받았다!`); break;
		case '-ability': {
			const m = this.monOf(args[0]);
			if (m) m.ability = args[1];
			this.push('text', `[${this.who(args[0])}의 특성: ${koAbility(args[1])}]`, this.sideOf(args[0]));
			break;
		}
		case '-endability': this.push('text', `${this.who(args[0])}의 특성이 효과를 잃었다!`); break;
		case '-item': {
			const m = this.monOf(args[0]);
			if (m) m.item = args[1];
			const it = koItem(args[1]);
			if (kw.from && /Frisk/i.test(kw.from)) this.push('text', `${eun(of || '')} ${this.who(args[0])}의 ${eul(it)} 통찰했다!`);
			else if (kw.from) this.push('text', `${eun(this.who(args[0]))} ${eul(it)} 얻었다! [${from}]`);
			else this.push('text', `${eun(this.who(args[0]))} ${eul(it)} 지니고 있다!`);
			break;
		}
		case '-enditem': {
			const m = this.monOf(args[0]);
			if (m) m.item = '';
			const it = koItem(args[1]);
			const w = this.who(args[0]);
			if (kw.eat !== undefined) this.push('text', `${eun(w)} ${eul(it)} 먹었다!`);
			else if (kw.from && /stealeat|bugbite|pluck/i.test(toID(kw.from))) this.push('text', `${w}의 ${iga(it)} 먹혀 버렸다!`);
			else if (kw.from) this.push('text', `${w}의 ${iga(it)} 없어졌다! [${from}]`);
			else this.push('text', `${w}의 ${iga(it)} 사라졌다!`);
			break;
		}
		case '-transform': this.push('text', `${eun(this.who(args[0]))} ${euro(koSpecies(args[1].replace(/^p\da: /, '')))} 변신했다!`); break;
		case '-prepare': this.push('text', `${eun(this.who(args[0]))} ${koMove(args[1])} 준비 중이다!`); break;
		case '-nothing': this.push('text', '그러나 아무 일도 일어나지 않았다!'); break;
		case '-message': case 'message': this.push('info', args.join(' ')); break;
		case 'win': st.winner = args[0]; st.ended = true; this.push('win', `${josa(args[0], '의', '의')} 승리!`); break;
		case 'tie': st.ended = true; this.push('win', '무승부!'); break;
		case '-singlemove': this.push('text', `${eun(this.who(args[0]))} ${koMove(args[1])} 태세다!`); break;
		case '-fieldactivate': this.push('info', `[${koEffect(args[0])}]`); break;
		case '-block': this.push('text', `${eun(this.who(args[0]))} ${args[1] ? koEffect(args[1]) + '(으)로 ' : ''}공격을 막았다!`); break;
		case 'swapsideconditions': {
			const a = st.sides.p1.conditions; st.sides.p1.conditions = st.sides.p2.conditions; st.sides.p2.conditions = a;
			this.push('info', '서로의 필드 효과가 바뀌었다!');
			break;
		}
		case '-mustrecharge': case '-waiting': case '-combine': case '-hint': case '-center': case 'upkeep': case '':
		case 't:': case 'gametype': case 'gen': case 'tier': case 'rule': case 'clearpoke': case 'teamsize': case 'j': case 'J':
		case 'l': case 'init': case 'title': case 'split': case 'rated': case '-anim': case 'seed': case 'debug': case 'inactive':
		case 'inactiveoff': case 'timestamp': case 'chat': case 'bigerror': case 'uhtml': case 'html': case 'raw':
			break;
		default:
			if (cmd.startsWith('-')) this.push('info', `(${cmd.slice(1)} ${args.join(' ')})`);
		}
	}
}
