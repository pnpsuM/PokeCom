import { dex } from './format';
import { toID } from '../sim';

export interface Badge { mult: number; label: string; cls: string }
export function badgeFor(mult: number): Badge {
	if (mult === 0) return { mult, label: '효과 없음 ×0', cls: 'e0' };
	if (mult <= 0.25) return { mult, label: '매우 별로 ×¼', cls: 'e14' };
	if (mult < 1) return { mult, label: '별로 ×½', cls: 'e12' };
	if (mult === 1) return { mult, label: '보통', cls: 'e1' };
	if (mult < 4) return { mult, label: '굉장 ×2', cls: 'e2' };
	return { mult, label: '매우 굉장 ×4', cls: 'e4' };
}

export function moveType(move: string): string {
	const id = toID(move);
	if (id.startsWith('hiddenpower') && id.length > 11) {
		const t = id.slice(11).replace(/\d+$/, '');
		return t.charAt(0).toUpperCase() + t.slice(1);
	}
	return dex.moves.get(move).type;
}

/** 공격 기술 → 상대 종 상성 배율 (변화 기술이면 null) */
export function effectiveness(move: string, targetSpecies: string, typeOverride?: string, targetTypes?: string[] | null): number | null {
	const m = dex.moves.get(move);
	if (!m.exists || m.category === 'Status') return null;
	const sp = dex.species.get(targetSpecies);
	if (!sp.exists) return null;
	// 변환자재 등으로 타입이 바뀌었으면 바뀐 타입으로
	const s = { types: targetTypes?.length ? targetTypes : sp.types };
	const type = typeOverride ?? moveType(move);
	if (!dex.getImmunity(type, s.types)) return m.id === 'thousandarrows' ? 1 : 0;
	let e = dex.getEffectiveness(type, s.types);
	if (m.id === 'freezedry' && s.types.includes('Water')) e += 2;
	if (m.id === 'flyingpress') e += dex.getEffectiveness('Flying', s.types);
	return 2 ** e;
}

export function moveInfo(move: string) {
	const m = dex.moves.get(move);
	return {
		type: moveType(move), category: m.category as string, power: m.basePower as number,
		accuracy: m.accuracy === true ? null : (m.accuracy as number), priority: m.priority as number,
		desc: (m.shortDesc || m.desc) as string, contact: !!m.flags.contact, pp: m.pp as number,
	};
}

export const speciesTypes = (s: string): string[] => dex.species.get(s).types;

/** 방어 상성: 공격 타입 → 배율 */
export function defensiveChart(types: string[]): Record<string, number> {
	const out: Record<string, number> = {};
	for (const t of dex.types.names()) {
		if (t === 'Stellar') continue;
		out[t] = dex.getImmunity(t, types) ? 2 ** dex.getEffectiveness(t, types) : 0;
	}
	return out;
}
