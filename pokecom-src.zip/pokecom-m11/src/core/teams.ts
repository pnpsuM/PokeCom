// 파티 생성·샘플 세트·합법성 검사
// 상대 파티/샘플 세트는 Showdown Champions 랜덤 배틀 데이터(역할별 기술 풀)로 만들고,
// 능력 포인트(SP)와 성격을 역할에 맞춰 다시 배분한다.
import { Dex, PRNG, RandomChampionsTeams, TeamValidator, Teams, toID } from '../sim';
import { FORMAT, dex, STATS, type Format, type PokemonSet, type StatID } from './format';
import { koItem, koMove, koSpecies } from './ko';

const fmt = Dex.formats.get(FORMAT.id);
let gen: any = null;
function generator() {
	if (!gen) gen = new RandomChampionsTeams(fmt, PRNG.generateSeed());
	return gen;
}
let validator: any = null;
function getValidator() {
	if (!validator) validator = TeamValidator.get(FORMAT.id);
	return validator;
}

export const ROLE_KO: Record<string, string> = {
	'Bulky Attacker': '내구형 어태커', 'Bulky Support': '내구형 서포터', 'Bulky Setup': '내구형 랭크업',
	'Fast Attacker': '고속 어태커', 'Fast Support': '고속 서포터', 'Fast Bulky Setup': '고속 내구 랭크업',
	'Setup Sweeper': '랭크업 스위퍼', Wallbreaker: '월브레이커', 'AV Pivot': '돌격조끼 피벗', 'Tera Blast user': '테라버스트',
	Doubles: '더블', 'Choice Item user': '구애 도구', Offensive: '공격형', Support: '서포터',
};

const emptyStats = (v: number): Record<StatID, number> => ({ hp: v, atk: v, def: v, spa: v, spd: v, spe: v });

/** 이름 없는 공통 세트 형태로 정리 */
export function normalize(set: any): PokemonSet {
	return {
		name: '',
		species: set.species,
		item: set.item ?? '',
		ability: set.ability ?? '',
		nature: set.nature || 'Serious',
		evs: { ...emptyStats(0), ...(set.evs ?? {}) },
		ivs: emptyStats(31),
		moves: [...(set.moves ?? [])].map((m: string) => dex.moves.get(m).name || m),
		level: FORMAT.level,
		gender: set.gender ?? '',
	};
}

/** 역할과 기술에 맞춰 SP(66)와 성격을 배분한다 */
export function optimizeSpread(set: PokemonSet, role = ''): PokemonSet {
	const sp = dex.species.get(set.species);
	const bs = sp.baseStats;
	const moves = set.moves.map(m => dex.moves.get(m));
	const phys = moves.filter(m => m.category === 'Physical' && m.id !== 'bodypress' && m.id !== 'foulplay').length;
	const spec = moves.filter(m => m.category === 'Special').length;
	const bodyPress = moves.some(m => m.id === 'bodypress');
	const trickRoom = moves.some(m => m.id === 'trickroom' || m.id === 'gyroball');
	const attacks = phys + spec + (bodyPress ? 1 : 0);
	const main: StatID = phys >= spec ? 'atk' : 'spa';
	const other: StatID = main === 'atk' ? 'spa' : 'atk';
	const bulky = /Bulky|Pivot/.test(role) || (/Support/.test(role) && !/Fast/.test(role)) || attacks <= 1;
	const evs = emptyStats(0);
	let nature = 'Serious';
	const NAT: Record<string, string> = {
		'atk+spa-': 'Adamant', 'spa+atk-': 'Modest', 'spe+spa-': 'Jolly', 'spe+atk-': 'Timid', 'atk+spe-': 'Brave', 'spa+spe-': 'Quiet',
		'def+atk-': 'Bold', 'spd+atk-': 'Calm', 'def+spa-': 'Impish', 'spd+spa-': 'Careful', 'atk+def-': 'Lonely', 'spa+def-': 'Mild',
		'spe+def-': 'Hasty', 'def+spe-': 'Relaxed', 'spd+spe-': 'Sassy',
	};
	const nat = (plus: StatID, minus: StatID) => NAT[`${plus}+${minus}-`] ?? 'Serious';
	if (trickRoom) {
		evs.hp = 32; evs[main] = 32; evs.def = 2;
		nature = nat(main, 'spe');
	} else if (bulky && attacks <= 2) {
		const defStat: StatID = bodyPress || bs.def <= bs.spd ? 'def' : 'spd';
		evs.hp = 32; evs[defStat] = 32; evs.spe = 2;
		const minus: StatID = phys && !spec ? 'spa' : spec && !phys ? 'atk' : 'atk';
		nature = bodyPress ? 'Bold' : nat(defStat, minus === other ? minus : 'atk');
	} else if (bulky) {
		evs.hp = 32; evs[main] = 32; evs.spe = 2;
		nature = phys && spec ? nat(main, 'def') : nat(main, other);
	} else {
		evs[main] = 32; evs.spe = 32; evs.hp = 2;
		const fast = bs.spe >= 80;
		if (phys && spec) nature = fast ? 'Hasty' : nat(main, 'def');
		else nature = fast ? nat('spe', other) : nat(main, other);
	}
	return { ...set, evs, nature };
}

export const SPARE_ITEMS = ['Sitrus Berry', 'Leftovers', 'Focus Sash', 'Lum Berry', 'Choice Scarf', 'Life Orb', 'Choice Specs', 'Choice Band', 'Assault Vest',
		'Rocky Helmet', 'Shell Bell', 'Quick Claw', 'Kings Rock', 'Bright Powder', 'White Herb', 'Mental Herb', 'Expert Belt', 'Black Sludge']
		.filter(i => dex.items.get(i).exists && !dex.items.get(i).isNonstandard);
function fixItemClause(team: PokemonSet[]): boolean {
	const seen = new Set<string>();
	const spare = SPARE_ITEMS;
	for (const s of team) {
		const id = toID(s.item);
		if (!id) continue;
		if (!seen.has(id)) { seen.add(id); continue; }
		const alt = spare.find(i => !seen.has(toID(i)));
		if (!alt) return false;
		s.item = alt; seen.add(toID(alt));
	}
	return true;
}

/** 상대 파티 생성 (랜덤 배틀 데이터 기반) */
export const RandomTeamSource = {
	id: 'champions-random',
	label: 'Champions 랜덤 세트',
	generate(format: Format = FORMAT): PokemonSet[] {
		for (let tries = 0; tries < 30; tries++) {
			const raw = generator().randomTeam();
			const team = raw.slice(0, format.teamSize).map((s: any) => optimizeSpread(normalize(s), s.role));
			if (!fixItemClause(team)) continue;
			if (!validateTeam(team)) return team;
		}
		throw new Error('유효한 파티를 만들지 못했다');
	},
};

/** 종 하나의 샘플 세트들 (역할별) */
export function sampleSets(speciesName: string, max = 4): { role: string; set: PokemonSet }[] {
	const g = generator();
	const species = dex.species.get(speciesName);
	const keys = [species.id, ...(species.otherFormes ?? []).map((f: string) => toID(f)).filter((id: string) => /mega/.test(id))];
	const out: { role: string; set: PokemonSet }[] = [];
	const seen = new Set<string>();
	for (const key of keys) {
		if (!g.randomSets[key]) continue;
		const target = dex.species.get(key);
		for (let i = 0; i < 16 && out.length < max; i++) {
			let raw: any;
			try { raw = g.randomSet(target, {}, false, false); } catch { continue; }
			const role = raw.role ?? '';
			const set = optimizeSpread(normalize(raw), role);
			const sig = role + '|' + [...set.moves].sort().join(',') + '|' + set.item;
			if (seen.has(sig)) continue;
			seen.add(sig);
			if (validateSet(set)) continue;
			out.push({ role: (target.isMega ? '메가 · ' : '') + (ROLE_KO[role] ?? role), set });
		}
	}
	return out;
}

/** 빈 세트 (종만 정한 상태) */
export function blankSet(speciesName: string): PokemonSet {
	const s = dex.species.get(speciesName);
	return {
		name: '', species: s.name, item: '', ability: s.abilities['0'], nature: 'Serious',
		evs: emptyStats(0), ivs: emptyStats(31), moves: [], level: FORMAT.level, gender: '',
	};
}

const MSG: [RegExp, (m: RegExpMatchArray) => string][] = [
	[/You are limited to 1 of each item by Item Clause/, () => '같은 도구는 한 개만 들 수 있다 (도구 클로즈)'],
	[/^\(?You have more than 1 (.+?)\)?$/, m => `${koItem(m[1])} 중복`],
	[/You are limited to one of each Pokémon by Species Clause/, () => '같은 포켓몬은 한 마리만 넣을 수 있다'],
	[/^\(?You have more than one (.+?)\)?$/, m => `${koSpecies(m[1])} 중복`],
	[/^(.+?) can't learn (.+?)\.?$/, m => `${koSpecies(m[1])}은(는) ${koMove(m[2])}을(를) 배울 수 없다`],
	[/^(.+?) has no moves/, m => `${koSpecies(m[1])}: 기술이 없다`],
	[/^(.+?) is banned/, m => `${koSpecies(m[1])}은(는) 이 룰에서 쓸 수 없다`],
	[/^(.+?) is not available in/, m => `${koSpecies(m[1])}은(는) 이 룰에서 쓸 수 없다`],
	[/You must bring at least (\d+) Pokémon/, m => `포켓몬을 최소 ${m[1]}마리 넣어야 한다`],
	[/^(.+?)'s item (.+?) is/, m => `${koSpecies(m[1])}의 도구 ${koItem(m[2])}은(는) 쓸 수 없다`],
	[/^(.+?) can't have (.+)/, m => `${koSpecies(m[1])}은(는) ${m[2]}을(를) 가질 수 없다`],
	[/has (\d+) total Stat Points, which is more than this format's limit of (\d+)/, m => `SP 합계 ${m[1]} (최대 ${m[2]})`],
	[/Stat Points? .* (\d+)/, m => `SP 초과 (한 능력치 최대 ${m[1]})`],
];
export function koProblem(p: string): string {
	for (const [re, fn] of MSG) { const m = p.match(re); if (m) return fn(m); }
	return p;
}

export function validateTeam(team: PokemonSet[]): string[] | null {
	const copy = team.map(s => ({ ...s, evs: { ...s.evs }, ivs: { ...s.ivs }, moves: [...s.moves] }));
	return getValidator().validateTeam(copy);
}
export function validateSet(set: PokemonSet): string[] | null {
	const copy = { ...set, evs: { ...set.evs }, ivs: { ...set.ivs }, moves: [...set.moves] };
	return getValidator().validateSet(copy, {});
}

export function exportTeam(team: PokemonSet[]): string { return Teams.export(team); }
export function importTeam(text: string): PokemonSet[] | null {
	const t = Teams.import(text);
	if (!t?.length) return null;
	return t.map((s: any) => ({ ...normalize(s), nature: s.nature || 'Serious', evs: { ...emptyStats(0), ...(s.evs ?? {}) } }));
}

export const statTotal = (set: PokemonSet) => STATS.reduce((a, s) => a + (set.evs[s] || 0), 0);
