// 한국어 이름·설명 조회 (src/data/ko.json 은 scripts/gen-data.mjs 로 생성)
import { MANIFEST } from '../config/manifest';
const KO = MANIFEST.data.ko;
import { toID } from '../sim';

type Table = Record<string, string>;
const K = KO as unknown as {
	species: Table; moves: Table; items: Table; abilities: Table; types: Table; natures: Table;
	moveDesc: Table; abilityDesc: Table; itemDesc: Table;
};

export const koSpecies = (s: string) => K.species[toID(s)] ?? s;
export const koMove = (s: string): string => {
	const id = toID(s);
	return K.moves[id] ?? s;
};
export const koAbility = (s: string) => K.abilities[toID(s)] ?? s;
export const koItem = (s: string) => (s ? K.items[toID(s)] ?? s : '');
export const koType = (s: string) => K.types[toID(s)] ?? s;
export const koNature = (s: string) => K.natures[toID(s)] ?? s;
export const koMoveDesc = (s: string) => K.moveDesc[toID(s)] ?? '';
export const koAbilityDesc = (s: string) => K.abilityDesc[toID(s)] ?? '';
export const koItemDesc = (s: string) => K.itemDesc[toID(s)] ?? '';

export const STAT_KO: Record<string, string> = {
	hp: 'HP', atk: '공격', def: '방어', spa: '특수공격', spd: '특수방어', spe: '스피드', accuracy: '명중률', evasion: '회피율',
};
export const STAT_SHORT: Record<string, string> = { hp: 'HP', atk: '공격', def: '방어', spa: '특공', spd: '특방', spe: '스피드' };
export const STATUS_KO: Record<string, string> = { brn: '화상', par: '마비', slp: '잠듦', frz: '얼음', psn: '독', tox: '맹독' };
export const CATEGORY_KO: Record<string, string> = { Physical: '물리', Special: '특수', Status: '변화' };

/** 받침에 따라 조사를 붙인다 */
export function josa(word: string, withFinal: string, withoutFinal: string): string {
	const w = word.replace(/[\s)\]」』]+$/, '');
	const code = w.charCodeAt(w.length - 1);
	if (code >= 0xac00 && code <= 0xd7a3) {
		const jong = (code - 0xac00) % 28;
		if (withFinal === '으로' && jong === 8) return word + withoutFinal; // ㄹ 받침 + 로
		return word + (jong ? withFinal : withoutFinal);
	}
	return /[013678LMNR]$/i.test(w) ? word + withFinal : word + withoutFinal;
}
export const eun = (w: string) => josa(w, '은', '는');
export const iga = (w: string) => josa(w, '이', '가');
export const eul = (w: string) => josa(w, '을', '를');
export const euro = (w: string) => josa(w, '으로', '로');

const EFFECT_KO: Table = {
	confusion: '혼란', substitute: '대타출동', sandstorm: '모래바람', hail: '싸라기눈', snowscape: '설경', snow: '설경',
	raindance: '비', sunnyday: '쾌청', desolateland: '끝의대지', primordialsea: '시작의바다', deltastream: '델타스트림',
	brn: '화상', psn: '독', tox: '맹독', par: '마비', slp: '잠듦', frz: '얼음', recoil: '반동', trapped: '도망칠 수 없음',
	perishsong: '멸망의노래', leechseed: '씨뿌리기', curse: '저주', typechange: '타입 변화', stockpile: '비축',
	focusenergy: '기합', mustrecharge: '반동', partiallytrapped: '조이기', lockedmove: '폭주', futuresight: '미래예지',
	saltcure: '소금절이', protosynthesis: '고대활성', quarkdrive: '쿼크차지',
};

/** "move: X" / "ability: X" / "item: X" 같은 효과 이름을 한국어로 */
export function koEffect(e: string): string {
	if (!e) return '';
	const m = e.match(/^(move|ability|item|pokemon):\s*(.*)$/);
	if (m) {
		const [, kind, name] = m;
		return kind === 'move' ? koMove(name) : kind === 'ability' ? koAbility(name) : kind === 'item' ? koItem(name) : koSpecies(name);
	}
	const id = toID(e);
	return EFFECT_KO[id] ?? K.moves[id] ?? K.abilities[id] ?? K.items[id] ?? e;
}

/** 초성 검색 지원: "ㅍㅋㅊ" → 피카츄 */
const CHO = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ';
export function choseong(s: string): string {
	let out = '';
	for (const ch of s) {
		const c = ch.charCodeAt(0);
		out += c >= 0xac00 && c <= 0xd7a3 ? CHO[Math.floor((c - 0xac00) / 588)] : ch;
	}
	return out;
}
export function matchKo(name: string, query: string): boolean {
	const q = query.replace(/\s+/g, '').toLowerCase();
	if (!q) return true;
	const n = name.replace(/\s+/g, '').toLowerCase();
	if (n.includes(q)) return true;
	return /^[ㄱ-ㅎ]+$/.test(q) && choseong(n).includes(q);
}
