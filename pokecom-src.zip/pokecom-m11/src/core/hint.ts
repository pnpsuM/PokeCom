// 기술 버튼의 예상 데미지 (설정 damageHint). 상대 세트는 모르므로 공개 정보 + 세트 추정(첫 후보)으로 계산한다
import { dex, type PokemonSet } from './format';
import { toID } from '../sim';
import { Mech, type MechField, type MechState } from './ai/mech';
import { candidates } from './ai/belief';
import type { BattleView } from './view';

export interface DamageHint { min: number; max: number; text: string }

function field(view: BattleView, mineIdx: 0 | 1): MechField {
	const st = view.state;
	const scr = (id: 'p1' | 'p2') => {
		const c = st.sides[id].conditions.map(x => toID(x)); const o: Record<string, number> = {};
		for (const k of ['reflect', 'lightscreen', 'auroraveil', 'tailwind']) if (c.includes(k)) o[k] = 3;
		return o;
	};
	void mineIdx;
	return { weather: st.weather, terrain: st.terrain.find(t => /terrain/i.test(t)) ?? '', screens: [scr('p1'), scr('p2')] };
}

/** 내 싸우는 포켓몬(req) 의 기술별 예상 데미지. 변화 기술은 null */
export function damageHints(view: BattleView, req: any, myTeam: PokemonSet[], mega: boolean): (DamageHint | null)[] {
	const act = req.active?.[0]; const me = req.side?.pokemon?.find((p: any) => p.active);
	const foe = view.state.sides.p2.active;
	if (!act || !me || !foe || foe.fainted) return [];
	const mySpecies = me.details.split(',')[0];
	const num = dex.species.get(mySpecies).num;
	const base = myTeam.find(s => dex.species.get(s.species).num === num);
	if (!base) return [];
	const mySet: PokemonSet = { ...base, species: mySpecies, item: me.item ? dex.items.get(me.item).name : '', moves: act.moves.map((m: any) => dex.moves.get(m.id).name) };
	const foeSet = candidates(foe)[0];
	if (!foeSet) return [];
	let mech: Mech;
	try { mech = new Mech([[{ key: 'me', set: mySet }], [{ key: 'foe', set: { ...foeSet, species: dex.species.get(foe.species).isMega ? dex.species.get(foe.species).baseSpecies : foeSet.species } }]]); } catch { return []; }
	const [hpNow, hpMax] = String(me.condition).split(' ')[0].split('/').map(Number);
	const p1 = view.state.sides.p1, p2 = view.state.sides.p2;
	const megaSpecies = mega && act.canMegaEvo ? dex.species.get(act.canMegaEvo).name : mySpecies;
	const att: MechState = { key: 'me', species: megaSpecies, hp: hpMax ? (hpNow / hpMax) * 100 : 100, status: p1.active?.status ?? '', boosts: p1.boosts, item: mySet.item, ability: me.ability ?? me.baseAbility, shiftUsed: p1.proteanUsed, types: p1.types ?? undefined };
	const foeHp = foe.maxhp ? (foe.hp / foe.maxhp) * 100 : 100;
	const def: MechState = { key: 'foe', species: foe.species, hp: foeHp, status: foe.status, boosts: p2.boosts, item: foe.item === undefined ? foeSet.item : foe.item, itemGone: foe.item === '', types: p2.types ?? undefined };
	const f = field(view, 0);
	return act.moves.map((m: any) => {
		const mv = dex.moves.get(m.id);
		if (mv.category === 'Status') return null;
		const r = mech.range(att, def, 0, m.id, f);
		if (!r.max) return { min: 0, max: 0, text: '효과 없음' };
		const hitsMin = Math.ceil(foeHp / Math.max(0.1, r.max)), hitsMax = Math.ceil(foeHp / Math.max(0.1, r.min));
		const ko = hitsMin === hitsMax ? `확정 ${hitsMin}타` : `난수 ${hitsMin}타`;
		const fmt = (x: number) => (x >= 10 ? Math.round(x) : Math.round(x * 10) / 10);
		return { min: r.min, max: r.max, text: `${fmt(r.min)}~${fmt(r.max)}% · ${ko}` };
	});
}
