// AI 끼리 한 판 (자가 대전·레이팅 측정용). 화면 없이 돈다.
import { BattleStream, getPlayerStreams, Teams } from '../sim';
import type { Format, PokemonSet } from './format';
import type { Agent } from './session';
import { BattleView } from './view';

export interface ArenaSide { name: string; team: PokemonSet[]; agent: Agent }

export function runArena(format: Format, a: ArenaSide, b: ArenaSide, rng: () => number = Math.random, maxTurns = 300): Promise<{ winner: 'p1' | 'p2' | null; turns: number; errors: number }> {
	return new Promise((resolve) => {
		const streams = getPlayerStreams(new BattleStream());
		let winner: 'p1' | 'p2' | null = null; let turns = 0; let errors = 0; let done = false;
		const finish = () => { if (!done) { done = true; resolve({ winner, turns, errors }); } };
		const drive = async (id: 'p1' | 'p2', side: ArenaSide) => {
			const view = new BattleView(a.name, b.name);
			const log: string[] = [];
			let pending: any = null;
			for await (const chunk of streams[id]) {
				for (const line of (chunk as string).split('\n')) {
					if (line.startsWith('|request|')) { const j = line.slice(9); if (j) pending = JSON.parse(j); continue; }
					if (line.startsWith('|error|')) { errors++; continue; }
					log.push(line); view.add(line);
					if (line.startsWith('|turn|')) { turns = +line.slice(6); if (turns > maxTurns) streams.omniscient.write('>forcetie'); }
					if (line.startsWith('|win|')) { winner = line.slice(5) === a.name ? 'p1' : 'p2'; setTimeout(finish, 0); }
					if (line === '|tie') { winner = null; setTimeout(finish, 0); }
				}
				await new Promise((r) => setTimeout(r, 0));
				if (pending && !pending.wait && !done) {
					const r = pending; pending = null;
					let choice = 'default';
					try { choice = await side.agent.choose(r, { format, log, rng, view, team: side.team }); } catch (e) { errors++; if ((globalThis as any).AI_DEBUG) console.warn(e); }
					streams[id].write(choice);
				} else pending = null;
			}
		};
		drive('p1', a); drive('p2', b);
		(async () => { for await (const _ of streams.omniscient) void _; })();
		streams.omniscient.write(
			`>start ${JSON.stringify({ formatid: format.id })}\n` +
			`>player p1 ${JSON.stringify({ name: a.name, team: Teams.pack(a.team) })}\n` +
			`>player p2 ${JSON.stringify({ name: b.name, team: Teams.pack(b.team) })}`,
		);
	});
}
