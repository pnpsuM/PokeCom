// Showdown 시뮬레이터 번들(vendor/ps-sim.js)을 앱에 노출한다.
// 번들은 scripts/build-sim.mjs 로 만든다 (Champions 모드 포함).
// @ts-ignore - 생성된 JS 번들
import * as PS from '../vendor/ps-sim.js';

export const Dex: any = PS.Dex;
export const toID: (s: unknown) => string = PS.toID;
export const BattleStream: any = PS.BattleStream;
export const getPlayerStreams: any = PS.getPlayerStreams;
export const Teams: any = PS.Teams;
export const TeamValidator: any = PS.TeamValidator;
export const PRNG: any = PS.PRNG;
export const RandomChampionsTeams: any = PS.RandomChampionsTeams;
export const Battle: any = PS.Battle;
export const State: any = PS.State;
