import './style.css';
import { nav } from './ui/nav';
import { renderHome } from './ui/home';
import { renderTeams, renderTeamEditor } from './ui/builder';
import { startBattle } from './ui/battle';
import { askConsent } from './ui/settings';
import { settings } from './core/store';
import { probeNetwork } from './sprites';

nav.home = renderHome;
nav.teams = renderTeams;
nav.editTeam = renderTeamEditor;
nav.battle = startBattle;

renderHome();
if (settings.spriteConsent === 'unknown') askConsent(renderHome);
else if (settings.spriteConsent === 'yes') probeNetwork();

if ('serviceWorker' in navigator && import.meta.env.PROD) {
	addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
}
