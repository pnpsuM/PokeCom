// ─────────────────────────────────────────────────────────────
// 앱 버전 (릴리스할 때 여기와 package.json 을 함께 올린다 — npm run release 가 맞춰 준다)
// ─────────────────────────────────────────────────────────────

export const APP_VERSION = '1.3.0';

/** 최근 변경 (설정 화면 "버전 정보"에 표시) */
export const CHANGELOG: Array<{ version: string; date: string; notes: string[] }> = [
	{ version: '1.3.0', date: '2026-09-26', notes: ['모듈 분리: 레이팅 정책·대전 룰·AI 단계·버전별 데이터를 config/ 로', '빌드를 조각(시뮬레이터·데이터·앱)으로 나눠 바뀐 파일만 올리도록'] },
	{ version: '1.2.0', date: '2026-09-26', notes: ['AI 판단 로직(초급·중급·상급)과 Elo 래더'] },
	{ version: '1.1.0', date: '2026-09-26', notes: ['Champions 룰, 9세대, 파티 짜기'] },
];
