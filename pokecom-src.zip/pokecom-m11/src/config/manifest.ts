// ─────────────────────────────────────────────────────────────
// 이 버전이 불러올 것들의 정의
// - 어떤 대전 룰을 쓰나 (config/rules.ts 의 key)
// - 어떤 시뮬레이터 커밋으로 묶였나 (vendor/PS_COMMIT 와 같아야 한다 — 빌드 때 확인)
// - 어떤 데이터 파일을 쓰나 (한국어, 스프라이트 번호표, AI 레이팅 측정값)
// - 외부 리소스 주소, 기기 저장소 이름
// 데이터 파일을 바꾸려면 아래 import 경로만 바꾼다. 각 파일은 빌드에서 따로 떨어진 조각이 되어,
// 안 바뀐 조각은 파일 이름(해시)도 그대로라 다시 올릴 필요가 없다.
// ─────────────────────────────────────────────────────────────
import { RULESETS, type RuleSet } from './rules';
import koData from '../data/ko.json';
import spriteMap from '../data/sprites.json';
import ratings from '../data/ratings/champions-bss-regmc.json';
import { CURATED_FILES } from '../data/samples';

export interface RatingsFile {
	measuredAt?: string; method?: string;
	pairs?: Record<string, number[]>;
	profiles: Array<{ id: string; rating: number; games?: number }>;
}

/** 사람이 만든 샘플 파티 파일 (src/data/samples/*.json) */
export interface CuratedFile {
	source: string; collectedAt: string; note?: string;
	/** 화면에 붙일 짧은 출처 이름 (예: 구박사, Game8) · 링크 버튼 글자 (영상/출처) */
	short?: string; linkLabel?: string;
	parties: Array<{ id: string; title: string; season: string; rank: string; url: string;
		sets: Array<{ species: string; item: string; ability: string; nature: string; sp: number[]; moves: string[] }> }>;
}

export const MANIFEST = {
	/** 대전 룰 */
	rules: RULESETS['champions-bss-regmc'] as RuleSet,
	/** 시뮬레이터 (Pokémon Showdown master) — 다시 묶기: PS_DIR=… npm run build:sim */
	sim: { commit: 'a5df8274e85b0889bf2a9b3422a08b39732374fc' },
	/** 데이터 */
	data: {
		ko: koData as Record<string, any>,
		spriteMap: spriteMap as Record<string, any>,
		/** AI 프로필 레이팅 (룰마다 따로 측정) */
		ratings: ratings as unknown as RatingsFile,
		/** 샘플 파티 (구박사 영상, Game8·알테마·note 구축 기사에서 옮김 — src/data/samples/). 고치면 data-samples 조각만 바뀜 */
		curated: CURATED_FILES as unknown as CuratedFile[],
		/** 상대 AI 가 샘플 파티를 들고 나올 확률 (나머지는 랜덤 세트 파티) */
		curatedOpponentRate: 0.4,
	},
	/** 외부 리소스 */
	remote: {
		sprites: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon',
	},
	/** 기기 저장소 이름 (바꾸면 기존 기록을 못 읽는다 — 주의) */
	storage: {
		settings: 'pokecom-settings',
		teams: 'pokecom-teams',
		ladderDb: 'pokecom-ladder',
		spriteDb: 'pokecom-sprites',
	},
};
