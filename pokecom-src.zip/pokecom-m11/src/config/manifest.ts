// ─────────────────────────────────────────────────────────────
// 이 버전이 불러올 것들의 정의
// - 어떤 대전 룰을 쓰나 (config/rules.ts 의 key)
// - 어떤 시뮬레이터 커밋으로 묶였나 (vendor/PS_COMMIT 와 같아야 한다 — 빌드 때 확인)
// - 어떤 데이터 파일을 쓰나 (한국어, 스프라이트 번호표, AI 레이팅 측정값)
// - 외부 리소스 주소, 기기 저장소 이름
// 데이터 파일을 바꾸려면 아래 import 경로만 바꾼다. 각 파일은 빌드에서 따로 떨어진 조각이 되어,
// 안 바뀐 조각은 파일 이름(해시)도 그대로라 다시 올릴 필요가 없다.
// ─────────────────────────────────────────────────────────────
import { RULESETS, type RuleSet } from './rules';
import koData from '../data/ko.json';
import spriteMap from '../data/sprites.json';
import ratings from '../data/ratings/champions-bss-regmc.json';

export interface RatingsFile {
	measuredAt?: string; method?: string;
	pairs?: Record<string, number[]>;
	profiles: Array<{ id: string; rating: number; games?: number }>;
}

export const MANIFEST = {
	/** 대전 룰 */
	rules: RULESETS['champions-bss-regmc'] as RuleSet,
	/** 시뮬레이터 (Pokémon Showdown master) — 다시 묶기: PS_DIR=… npm run build:sim */
	sim: { commit: 'a5df8274e85b0889bf2a9b3422a08b39732374fc' },
	/** 데이터 */
	data: {
		ko: koData as Record<string, any>,
		spriteMap: spriteMap as Record<string, any>,
		/** AI 프로필 레이팅 (룰마다 따로 측정) */
		ratings: ratings as unknown as RatingsFile,
	},
	/** 외부 리소스 */
	remote: {
		sprites: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon',
	},
	/** 기기 저장소 이름 (바꾸면 기존 기록을 못 읽는다 — 주의) */
	storage: {
		settings: 'pokecom-settings',
		teams: 'pokecom-teams',
		ladderDb: 'pokecom-ladder',
		spriteDb: 'pokecom-sprites',
	},
};
