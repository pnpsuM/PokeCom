// ── 대전 룰 (시뮬레이터에 구워 넣는 기본 포맷) ──
// 여기를 바꾸면 npm run build:sim 으로 시뮬레이터를 다시 묶어야 한다. 세부 룰 조정은 config/rules.ts 의 customRules 로 (재빌드 불필요)
// 시뮬레이터에 넣는 포맷 목록 (Showdown config/formats.ts 대신 사용)
// Champions BSS Reg M-C: 싱글, 6마리 중 3마리 선출, Lv50, 메가진화만 (테라·Z·다이맥스 없음)
export const Formats = [
	{
		name: '[Gen 9 Champions] BSS Reg M-C',
		mod: 'champions',
		ruleset: ['Flat Rules'],
	},
];
