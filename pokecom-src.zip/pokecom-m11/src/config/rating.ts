// ─────────────────────────────────────────────────────────────
// 레이팅 정책 (Elo 래더)
// 숫자만 바꾸면 된다. 저장된 전적은 그대로 두고 다음 판부터 새 정책이 적용된다
// (등급 경계는 바로 다시 계산된다)
// ─────────────────────────────────────────────────────────────

export const RATING_POLICY = {
	/** 처음 시작 레이팅 */
	start: 1000,
	/** 레이팅 최저값 */
	floor: 100,
	/** K (한 판 최대 변동): 배치 판 수 동안 크게, 이후 작게 */
	kPlacement: 32,
	kNormal: 20,
	placementGames: 20,
	/** 매칭: 내 레이팅 + [min, max] 범위에서 목표를 뽑아 가장 가까운 AI 를 고른다 (조금 센 쪽이 더 자주) */
	matchWindow: { min: -50, max: 100 },
	/** 무승부 점수 (승 1, 패 0) */
	tieScore: 0.5,
	/** 기권은 패배로 기록한다 */
	forfeitIsLoss: true,
};

export interface Grade { name: string; min: number; color: string }
/** 등급: min 이상이면 그 등급. AI 레이팅 범위(측정값)에 맞춰 정한다 */
export const GRADES: Grade[] = [
	{ name: '몬스터볼', min: 0, color: '#e2685f' },
	{ name: '슈퍼볼', min: 950, color: '#5a86e0' },
	{ name: '하이퍼볼', min: 1100, color: '#e8c02e' },
	{ name: '울트라볼', min: 1200, color: '#d9a520' },
	{ name: '마스터볼', min: 1300, color: '#a06ce0' },
];

/** 연습 배틀 상대 (레이팅 없음): config/ai.ts 의 프로필 id */
export const PRACTICE_PROFILE = 'L0';
