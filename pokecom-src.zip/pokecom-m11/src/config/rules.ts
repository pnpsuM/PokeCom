// ─────────────────────────────────────────────────────────────
// 대전 룰
// 여기만 고치면 되는 것: 선출 수, 레벨, SP 제한, 추가 규칙(Showdown 커스텀 룰)
// 새 기본 포맷(simFormat)을 쓰려면 src/config/sim-formats.ts 에도 추가하고 시뮬레이터를 다시 묶어야 한다 (npm run build:sim)
// ─────────────────────────────────────────────────────────────

export interface RuleSet {
	/** 내부 이름 (manifest.ts 에서 고른다, 레이팅 데이터 파일 이름에도 쓰인다) */
	key: string;
	/** 화면 표시 */
	label: string;
	/** 시뮬레이터 기본 포맷 id (src/config/sim-formats.ts 에 있어야 함) */
	simFormat: string;
	/** Showdown 커스텀 룰 (예: '!Species Clause', 'Adjust Level = 50'). 시뮬레이터 재빌드 없이 적용된다 */
	customRules: string[];
	gen: number;
	gameType: 'singles';
	/** 파티 수 */
	teamSize: number;
	/** 선출 수 (팀 프리뷰에서 고르는 수) */
	pickSize: number;
	level: number;
	/** 능력 포인트(SP): 능력치 하나당 최대, 합계 최대 */
	spPerStat: number;
	spTotal: number;
	/** 쓸 수 있는 특수 기믹 (화면 버튼 표시용. 실제 허용 여부는 포맷 룰이 정한다) */
	gimmicks: { mega: boolean };
}

export const RULESETS: Record<string, RuleSet> = {
	/** Pokémon Champions 싱글 (BSS Reg M-C): 6마리 중 3마리, Lv50, 메가진화만 */
	'champions-bss-regmc': {
		key: 'champions-bss-regmc',
		label: 'Champions 싱글 (Reg M-C)',
		simFormat: 'gen9championsbssregmc',
		customRules: [],
		gen: 9,
		gameType: 'singles',
		teamSize: 6,
		pickSize: 3,
		level: 50,
		spPerStat: 32,
		spTotal: 66,
		gimmicks: { mega: true },
	},
};

/** 시뮬레이터에 넘길 포맷 id (커스텀 룰이 있으면 '@@@' 로 붙인다) */
export function simFormatId(r: RuleSet): string {
	return r.customRules.length ? `${r.simFormat}@@@${r.customRules.join(',')}` : r.simFormat;
}
