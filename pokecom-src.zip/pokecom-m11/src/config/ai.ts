// ─────────────────────────────────────────────────────────────
// AI 단계(프로필)와 상황 점수 가중치
// 프로필을 추가·수정하면 레이팅을 다시 측정해야 한다 (npm run ai:calibrate → npm run ai:fit)
// 측정 결과는 manifest.ts 가 가리키는 레이팅 파일에 저장된다
// ─────────────────────────────────────────────────────────────

/** 상황 점수 가중치 (모든 단계가 같은 점수 함수를 쓴다) */
export interface Weights {
	alive: number;       // 살아 있는 포켓몬 1마리
	hp: number;          // HP 100% 당
	status: Record<string, number>;   // 상태이상별 가치 감소 비율
	matchup: number;     // 현재 대면 유불리 (−1~1 정규화)
	boost: number;       // 유효 랭크 1단계
	hazard: number;      // 스텔스록 등으로 앞으로 깎일 HP 1% 당
	screen: number;      // 벽·순풍 남은 1턴 당
	win: number;         // 승패 확정
	switchCost: number;  // 자진 교체 1회 비용 (교체 반복 방지)
}

export const DEFAULT_WEIGHTS: Weights = {
	alive: 1.0, hp: 1.2,
	status: { brn: 0.2, par: 0.2, psn: 0.12, tox: 0.25, slp: 0.35, frz: 0.45 },
	matchup: 0.6, boost: 0.1, hazard: 0.01, screen: 0.04, win: 20, switchCost: 0.15,
};

/** 판단 단계 설정. 단계(level)마다 파이프라인은 같고 이 값들만 다르다 */
export interface Profile {
	id: string; label: string;
	/** 0 랜덤 · 1 초급(근사 1턴) · 2 중급(근사 2턴 + 상대 응수) · 3 상급(실제 시뮬레이터 탐색) */
	level: 0 | 1 | 2 | 3;
	epsilon: number;       // 실수 확률
	worlds: number;        // 가능한 상황 수 N
	lambda: number;        // 상대 응수: 최악(λ)과 평균(1−λ)의 섞음
	timeMs?: number;       // L3 한 수 시간 제한
	maxSims?: number;      // L3 시뮬레이션 상한 (기기 속도와 무관하게 강도를 맞추기 위함)
	depth?: number;        // 앞을 보는 턴 수 (근사 모델)
	replies?: number;      // 고려하는 상대 응수 수
	topK?: number;         // L3: 시뮬레이터로 확인할 행동 수
	simWorlds?: number;    // L3: 시뮬레이터로 굴릴 상황 수
	priorWeight?: number;  // L3: 근사 값 섞는 비율
	weights?: Weights;
}

const L2 = { worlds: 3, lambda: 0.6, depth: 2, replies: 3 };
const L3 = { worlds: 4, lambda: 0.5, timeMs: 5000, maxSims: 400, topK: 4, simWorlds: 4, priorWeight: 0.3 };

export const PROFILES: Profile[] = [
	{ id: 'L0', label: '랜덤', level: 0, epsilon: 0, worlds: 1, lambda: 0 },
	{ id: 'L1e30', label: '초급 · 실수 30%', level: 1, epsilon: 0.3, worlds: 1, lambda: 0 },
	{ id: 'L1', label: '초급', level: 1, epsilon: 0, worlds: 1, lambda: 0 },
	{ id: 'L2e30', label: '중급 · 실수 30%', level: 2, epsilon: 0.3, ...L2 },
	{ id: 'L2e10', label: '중급 · 실수 10%', level: 2, epsilon: 0.1, ...L2 },
	{ id: 'L2', label: '중급', level: 2, epsilon: 0, ...L2 },
	{ id: 'L3e10', label: '상급 · 실수 10%', level: 3, epsilon: 0.1, ...L3 },
	{ id: 'L3', label: '상급', level: 3, epsilon: 0, ...L3 },
];
