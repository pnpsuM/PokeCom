import { h, clear, sheet } from './dom';
import { spriteURL } from '../sprites';
import { koSpecies, koItem, koAbility, koMove, koNature, koAbilityDesc, koItemDesc, koMoveDesc, koType, STAT_SHORT, CATEGORY_KO } from '../core/ko';
import { moveInfo, speciesTypes } from '../core/typecalc';
import { calcStat, dex, STATS, type PokemonSet } from '../core/format';
import { settings } from '../core/store';

export const TYPE_COLOR: Record<string, string> = {
	Normal: '#9a9a7a', Fire: '#e8702c', Water: '#5a86e0', Electric: '#d9b41c', Grass: '#5fae3c', Ice: '#6cc4c4',
	Fighting: '#b8342c', Poison: '#9a44a0', Ground: '#c9a254', Flying: '#8f7fe0', Psychic: '#e8507a', Bug: '#98a81c',
	Rock: '#b09a3a', Ghost: '#6a5494', Dragon: '#6a3cf0', Dark: '#6a5444', Steel: '#9a9ab8', Fairy: '#e088a8', '???': '#6a8a84',
};
export const TYPES = Object.keys(TYPE_COLOR).filter(t => t !== '???');

export function typeTag(t: string) {
	return h('span', { class: 'type', style: `background:${TYPE_COLOR[t] ?? '#666'}` }, koType(t));
}

export interface SpriteOpts { download?: boolean; maxH?: number; slotSize?: number }
/** el 안에 스프라이트를 넣는다. 없으면 슬롯 카드. */
export function spriteInto(el: HTMLElement, species: string, facing: 'front' | 'back', scale: number, opts: SpriteOpts = {}) {
	const token = String(Math.random());
	el.dataset.token = token;
	const slot = () => {
		const size = opts.slotSize ?? (facing === 'back' ? 120 : 84);
		clear(el);
		el.appendChild(h('div', { class: size < 70 ? 'slotcard' : 'slot', style: `width:${size}px;height:${size}px` }, size < 70 ? '' : koSpecies(species)));
	};
	spriteURL(species, facing, opts.download !== false).then(hit => {
		if (el.dataset.token !== token) return;
		if (!hit) { if (opts.slotSize === 0) clear(el); else slot(); return; }
		const img = new Image();
		img.alt = `${koSpecies(species)} ${facing === 'back' ? '뒷모습' : '앞모습'}`;
		img.decoding = 'async';
		img.onload = () => {
			let s = scale;
			// PNG(96px 정지 이미지)는 여백이 있어 조금 더 크게
			if (hit.set === 'png') s *= 1.1;
			if (opts.maxH && img.naturalHeight * s > opts.maxH) s = opts.maxH / img.naturalHeight;
			img.style.width = Math.round(img.naturalWidth * s) + 'px';
			img.style.height = Math.round(img.naturalHeight * s) + 'px';
		};
		img.src = hit.url;
		clear(el);
		el.appendChild(img);
	});
}

// 화면에 보일 때만 스프라이트를 불러온다 (동의했으면 필요한 것만 받는다)
const io = typeof IntersectionObserver !== 'undefined' ? new IntersectionObserver(entries => {
	for (const e of entries) {
		if (!e.isIntersecting) continue;
		io!.unobserve(e.target);
		const el = e.target as HTMLElement;
		const size = +el.dataset.size!;
		spriteInto(el, el.dataset.species!, 'front', 1, { download: settings.spriteConsent === 'yes', maxH: size, slotSize: size - 4 });
	}
}, { rootMargin: '200px' }) : null;

export function thumb(species: string, size = 48) {
	const el = h('div', { class: 'thumb', style: `width:${size}px;height:${size}px` });
	el.dataset.species = species;
	el.dataset.size = String(size);
	el.appendChild(h('div', { class: 'slotcard', style: `width:${size - 4}px;height:${size - 4}px` }));
	if (io) io.observe(el);
	else spriteInto(el, species, 'front', 1, { download: false, maxH: size, slotSize: size - 4 });
	return el;
}

/** 파티 한 줄 (포켓몬·도구·특성·기술) */
export function monRow(set: PokemonSet, right?: Node | null, onClick?: () => void) {
	const sub = [koItem(set.item), koAbility(set.ability)].filter(Boolean).join(' · ');
	const btn = h('button', { class: 'mon' + (onClick ? '' : ' static'), type: 'button', on: onClick ? { click: onClick } : undefined },
		thumb(set.species),
		h('div', null,
			h('div', { class: 'nm' }, koSpecies(set.species), ' ', ...speciesTypes(set.species).map(typeTag)),
			h('div', { class: 'sub' }, sub),
			h('div', { class: 'sub' }, set.moves.map(koMove).join(' / '))),
		right ?? h('span'));
	if (!onClick) btn.tabIndex = -1;
	return btn;
}

export function statLine(set: PokemonSet) {
	const sp = dex.species.get(set.species);
	return h('div', { class: 'statline' }, STATS.map(s => {
		const n = dex.natures.get(set.nature);
		const cls = n.plus === s ? 'plus' : n.minus === s ? 'minus' : '';
		return h('span', { class: cls }, STAT_SHORT[s], h('b', null, String(calcStat(s, sp.baseStats[s], set.evs[s] || 0, set.nature))));
	}));
}

/** 세트 상세: 능력치 표(종족값·SP·실수치), 특성·도구·성격, 기술 */
export function setDetail(set: PokemonSet) {
	const sp = dex.species.get(set.species);
	const n = dex.natures.get(set.nature);
	const total = STATS.reduce((a, s) => a + (set.evs[s] || 0), 0);
	const natDesc = n.plus ? `${STAT_SHORT[n.plus]}↑ ${STAT_SHORT[n.minus]}↓` : '보정 없음';
	const stone = dex.items.get(set.item).megaStone;
	const megaName = stone ? (Object.values(stone)[0] as string) : '';
	return h('div', { style: 'display:flex;flex-direction:column;gap:10px' },
		h('div', { class: 'edit-head' },
			thumb(set.species, 72),
			h('div', { style: 'display:flex;flex-direction:column;gap:4px;min-width:0' },
				h('b', { style: 'font-size:18px' }, koSpecies(set.species)),
				h('div', null, ...speciesTypes(set.species).map(typeTag)),
				megaName ? h('div', { class: 'muted' }, `메가진화 → ${koSpecies(megaName)} `, ...speciesTypes(megaName).map(typeTag)) : null)),
		h('table', { class: 'stat-t' },
			h('thead', null, h('tr', null, h('th', null, ''), STATS.map(s => h('th', { class: n.plus === s ? 'plus' : n.minus === s ? 'minus' : '' }, STAT_SHORT[s])))),
			h('tbody', null,
				h('tr', null, h('th', null, '종족값'), STATS.map(s => h('td', null, String(sp.baseStats[s])))),
				h('tr', null, h('th', null, 'SP'), STATS.map(s => h('td', { class: set.evs[s] ? 'on' : '' }, String(set.evs[s] || 0)))),
				h('tr', { class: 'real' }, h('th', null, '실수치'), STATS.map(s => h('td', { class: n.plus === s ? 'plus' : n.minus === s ? 'minus' : '' }, String(calcStat(s, sp.baseStats[s], set.evs[s] || 0, set.nature))))))),
		h('div', { class: 'muted', style: 'font-size:12px' }, `SP 합계 ${total}/66 · Lv50 · 개체값은 Champions 규칙상 없음(항상 최대로 계산)`),
		h('dl', { class: 'kv' },
			h('dt', null, '특성'), h('dd', null, koAbility(set.ability), h('div', { class: 'muted' }, koAbilityDesc(set.ability))),
			h('dt', null, '도구'), h('dd', null, koItem(set.item) || '없음', set.item ? h('div', { class: 'muted' }, koItemDesc(set.item)) : null),
			h('dt', null, '성격'), h('dd', null, `${koNature(set.nature)} (${natDesc})`)),
		h('h2', null, '기술', h('span', { class: 'muted' }, `${set.moves.length}/4`)),
		h('div', { style: 'display:flex;flex-direction:column;gap:6px' }, set.moves.length ? set.moves.map(m => moveCard(m)) : h('div', { class: 'muted' }, '기술 없음')));
}

/** 상세 시트. onEdit 이 있으면 편집 페이지로 가는 버튼을 단다 */
export function openSetDetail(set: PokemonSet, onEdit?: () => void) {
	sheet(close => [
		h('div', { class: 'row', style: 'justify-content:space-between' },
			h('h2', null, '포켓몬 상세'),
			h('button', { class: 'btn small', type: 'button', on: { click: close } }, '닫기')),
		setDetail(set),
		h('div', { class: 'stickybar' },
			onEdit ? h('button', { class: 'btn primary grow', type: 'button', on: { click: () => { close(); onEdit(); } } }, '이 포켓몬 수정하기 →') : null,
			h('button', { class: 'btn' + (onEdit ? '' : ' grow'), type: 'button', on: { click: close } }, '닫기')),
	], { label: '포켓몬 상세' });
}

export function moveCard(move: string, pp?: string, typeInfo?: { type: string; note?: string }) {
	const i = moveInfo(move);
	if (typeInfo) i.type = typeInfo.type;
	return h('div', { class: 'panel', style: 'padding:10px;gap:4px' },
		h('div', { class: 'row', style: 'justify-content:space-between' },
			h('b', null, koMove(move)),
			h('span', null, typeTag(i.type), ' ', h('span', { class: 'muted' }, CATEGORY_KO[i.category] ?? i.category))),
		typeInfo?.note ? h('div', { class: 'typenote' }, typeInfo.note) : null,
		h('div', { class: 'muted', style: 'font-family:var(--pixel)' },
			`위력 ${i.power || '-'} · 명중 ${i.accuracy ?? '-'}${i.priority ? ` · 우선도 ${i.priority > 0 ? '+' : ''}${i.priority}` : ''}${pp ? ` · PP ${pp}` : ''}${i.contact ? ' · 접촉' : ''}`),
		h('div', { style: 'font-size:13px' }, koMoveDesc(move) || i.desc));
}

export function seg<T extends string>(label: string, options: [T, string][], value: T, onChange: (v: T) => void) {
	const box = h('div', { class: 'seg', role: 'group', 'aria-label': label });
	const draw = (v: T) => {
		clear(box);
		for (const [k, t] of options) box.appendChild(h('button', { type: 'button', 'aria-pressed': String(v === k), on: { click: () => { draw(k); onChange(k); } } }, t));
	};
	draw(value);
	return box;
}
