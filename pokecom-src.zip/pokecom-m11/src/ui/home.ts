import { h, clear } from './dom';
import { app, nav } from './nav';
import { monRow, openSetDetail } from './common';
import { koSpecies } from '../core/ko';
import { FORMAT, type PokemonSet } from '../core/format';
import { RandomTeamSource, validateTeam } from '../core/teams';
import { ladderCard } from './ladder-ui';
import { startLadder } from './battle';
import { settings, saveSettings, getTeam, listTeams, saveTeam, newTeamId } from '../core/store';
import { openSettings } from './settings';

let randomTeam: PokemonSet[] | null = null;

/** 무작위 파티를 저장 파티로 만들고 그 포켓몬 편집으로 */
function saveRandomAndEdit(team: PokemonSet[], i: number) {
	return () => {
		const t = { id: newTeamId(), name: '무작위에서 만든 파티', sets: team.map(s => ({ ...s, evs: { ...s.evs }, ivs: { ...s.ivs }, moves: [...s.moves] })), updated: 0 };
		saveTeam(t); settings.activeTeam = t.id; saveSettings(); randomTeam = null;
		nav.editTeam(t.id, i);
	};
}

export function renderHome() {
	clear(app);
	const saved = settings.activeTeam ? getTeam(settings.activeTeam) : undefined;
	const usable = saved && saved.sets.length === FORMAT.teamSize && !validateTeam(saved.sets);
	let team: PokemonSet[];
	let label: string;
	if (usable) { team = saved!.sets; label = saved!.name; } else { randomTeam ??= RandomTeamSource.generate(); team = randomTeam; label = '무작위 파티'; }

	const count = listTeams().length;
	app.appendChild(h('div', { class: 'page' },
		h('header', { class: 'row', style: 'justify-content:space-between;align-items:flex-end' },
			h('div', null, h('div', { class: 'eyebrow' }, 'POKECOM · v1.2'), h('h1', null, '컴까기')),
			h('button', { class: 'btn small', type: 'button', 'aria-label': '설정', on: { click: () => openSettings(renderHome) } }, '설정')),
		ladderCard(() => startLadder(team)),
		h('section', { class: 'panel' },
			h('h2', null, '내 파티', h('span', { class: 'muted' }, FORMAT.label)),
			h('div', { class: 'muted', style: 'margin-top:-6px' }, usable ? `${label} (파티 짜기에서 고름)` : '무작위 파티 · 파티 짜기에서 내 파티를 만들 수 있다'),
			h('div', { class: 'mons' }, team.map((s, i) => monRow(s, null, () => openSetDetail(s, usable ? () => nav.editTeam(saved!.id, i) : saveRandomAndEdit(team, i))))),
			h('div', { class: 'muted', style: 'font-size:12px' }, '포켓몬을 누르면 능력치·도구·기술·특성을 확인하고 수정 화면으로 갈 수 있다'),
			h('div', { class: 'row' },
				h('button', { class: 'btn primary grow', type: 'button', on: { click: nav.teams } }, count ? `파티 짜기 · 고르기 (${count})` : '파티 짜기'),
				!usable ? h('button', { class: 'btn', type: 'button', on: { click: () => { randomTeam = RandomTeamSource.generate(); renderHome(); } } }, '다시 뽑기') : null)),
		h('section', { class: 'panel' },
			h('h2', null, '상대'),
			h('div', { class: 'muted' }, `파티: ${RandomTeamSource.label} (Showdown Champions 랜덤 배틀 데이터 + 역할별 SP 배분) · AI: 래더는 내 레이팅에 맞는 단계(초급~상급), 연습은 랜덤 AI`),
			h('button', { class: 'btn ghost', type: 'button', on: { click: () => nav.battle(team) } }, '연습 배틀 (랜덤 AI, 레이팅 없음)')),
		h('footer', { class: 'credit' },
			'개인 플레이 전용. 배틀 엔진 Pokémon Showdown (Champions Reg M-C 규칙). 스프라이트 PokeAPI/sprites, 한국어 Showdown·PokeAPI. Pokémon © Nintendo · Creatures · GAME FREAK.'),
	));
}
