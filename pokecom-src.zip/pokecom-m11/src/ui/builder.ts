// 파티 짜기: 파티 목록 → 파티 편집(6칸) → 포켓몬/세트 편집
import { h, clear, sheet, toast, confirmSheet } from './dom';
import { app, nav } from './nav';
import { thumb, typeTag, TYPE_COLOR, TYPES, statLine, monRow, setDetail, seg, openSetDetail } from './common';
import { FORMAT, dex, STATS, calcStat, isPickable, type PokemonSet, type StatID } from '../core/format';
import { koSpecies, koItem, koAbility, koMove, koNature, koType, koAbilityDesc, koItemDesc, koMoveDesc, matchKo, STAT_SHORT, CATEGORY_KO } from '../core/ko';
import { sampleSets, blankSet, SPARE_ITEMS, validateTeam, validateSet, koProblem, exportTeam, importTeam, statTotal, RandomTeamSource } from '../core/teams';
import { moveInfo, speciesTypes } from '../core/typecalc';
import { listTeams, getTeam, saveTeam, deleteTeam, newTeamId, settings, saveSettings, type SavedTeam } from '../core/store';
import { toID } from '../sim';

const clone = (s: PokemonSet): PokemonSet => ({ ...s, evs: { ...s.evs }, ivs: { ...s.ivs }, moves: [...s.moves] });

// ---------------------------------------------------------------- 파티 목록
export function renderTeams() {
	clear(app);
	const list = h('div', { class: 'teams' });
	const draw = () => {
		clear(list);
		const teams = listTeams();
		if (!teams.length) list.appendChild(h('div', { class: 'muted' }, '아직 저장한 파티가 없다. 새 파티를 만들어 보자.'));
		for (const t of teams) {
			const problems = t.sets.length === FORMAT.teamSize ? validateTeam(t.sets) : ['6마리 미만'];
			const active = settings.activeTeam === t.id;
			list.appendChild(h('div', { class: 'teamcard' + (active ? ' active' : '') },
				h('button', { type: 'button', style: 'all:unset;cursor:pointer;display:flex;flex-direction:column;gap:4px;min-width:0', on: { click: () => nav.editTeam(t.id) } },
					h('div', { class: 'nm' }, t.name || '이름 없는 파티', ' ', h('span', { class: 'muted' }, problems ? `· 확인 필요` : '· 사용 가능')),
					h('div', { class: 'muted', style: 'font-size:12px' }, '포켓몬을 누르면 상세 · 이름을 누르면 파티 편집')),
				h('div', { class: 'mini', style: 'grid-column:1/-1' }, t.sets.map((s, i) => h('button', {
					class: 'minibtn', type: 'button', 'aria-label': `${koSpecies(s.species)} 상세`,
					on: { click: () => openSetDetail(s, () => nav.editTeam(t.id, i)) },
				}, thumb(s.species, 44), h('span', null, koSpecies(s.species))))),
				h('div', { class: 'row', style: 'gap:6px' },
					h('button', {
						class: 'btn small' + (active ? ' primary' : ''), type: 'button', disabled: !!problems,
						on: { click: () => { settings.activeTeam = active ? '' : t.id; saveSettings(); draw(); } },
					}, active ? '사용 중' : '사용'),
				)));
		}
	};
	draw();
	app.appendChild(h('div', { class: 'page' },
		h('div', { class: 'topbar' },
			h('button', { class: 'btn small back', type: 'button', 'aria-label': '홈으로', on: { click: nav.home } }, '←'),
			h('h2', null, '내 파티')),
		h('section', { class: 'panel' },
			h('div', { class: 'muted' }, `${FORMAT.label} · 6마리 · 같은 포켓몬·같은 도구 금지 · 메가진화만`),
			list,
			h('div', { class: 'row' },
				h('button', { class: 'btn primary grow', type: 'button', on: { click: () => nav.editTeam(null) } }, '＋ 새 파티'),
				h('button', { class: 'btn', type: 'button', on: { click: () => importDialog(null) } }, '텍스트로 가져오기'))),
	));
}

function importDialog(team: SavedTeam | null, onDone?: (sets: PokemonSet[]) => void) {
	sheet(close => {
		const ta = h('textarea', { class: 'text', placeholder: 'Showdown 팀 텍스트를 붙여넣는다\n\nGarchomp @ Garchompite\nAbility: Rough Skin\nEVs: 32 Atk / 32 Spe / 2 HP\nJolly Nature\n- Earthquake\n…' });
		const msg = h('div', { class: 'muted', role: 'status' });
		return [
			h('h2', null, '텍스트로 가져오기', h('button', { class: 'btn small', type: 'button', on: { click: close } }, '닫기')),
			h('div', { class: 'muted' }, '영어 이름(Showdown 형식)만 읽는다. EVs 칸은 SP로 읽는다.'),
			ta, msg,
			h('button', {
				class: 'btn primary', type: 'button', on: {
					click: () => {
						const sets = importTeam(ta.value);
						if (!sets) { msg.textContent = '읽을 수 있는 포켓몬이 없다'; return; }
						const trimmed = sets.slice(0, FORMAT.teamSize).map(s => ({ ...s, level: FORMAT.level }));
						close();
						if (onDone) { onDone(trimmed); return; }
						const t: SavedTeam = { id: newTeamId(), name: '가져온 파티', sets: trimmed, updated: 0 };
						saveTeam(t);
						nav.editTeam(t.id);
					},
				},
			}, '가져오기'),
		];
	}, { label: '텍스트로 가져오기' });
}

// ---------------------------------------------------------------- 파티 편집
export function renderTeamEditor(id: string | null, openIndex?: number) {
	const existing = id ? getTeam(id) : undefined;
	const team: SavedTeam = existing ? { ...existing, sets: existing.sets.map(clone) } : { id: newTeamId(), name: `파티 ${listTeams().length + 1}`, sets: [], updated: 0 };
	let dirty = !existing;
	clear(app);
	const nameIn = h('input', { class: 'text', value: team.name, maxlength: 20, 'aria-label': '파티 이름', on: { input: () => { team.name = nameIn.value; dirty = true; } } });
	const slots = h('div', { class: 'slots' });
	const status = h('div');
	const draw = () => {
		clear(slots);
		team.sets.forEach((s, i) => {
			slots.appendChild(monRow(s, h('span', { class: 'muted', style: 'font-family:var(--pixel)' }, String(i + 1)), () => editSlot(i)));
		});
		if (team.sets.length < FORMAT.teamSize) {
			slots.appendChild(h('button', {
				class: 'slot-empty', type: 'button', on: {
					click: async () => {
						const sp = await pickSpecies(team.sets.map(s => s.species));
						if (!sp) return;
						const res = await editSet(firstSample(sp, team.sets), team.sets, team.sets.length, true);
						if (res && res !== 'delete') { team.sets.push(res); dirty = true; draw(); }
					},
				},
			}, `＋ 포켓몬 추가 (${team.sets.length}/${FORMAT.teamSize})`));
		}
		clear(status);
		const problems = team.sets.length ? validateTeam(team.sets) : null;
		if (team.sets.length < FORMAT.teamSize) status.appendChild(h('div', { class: 'problems' }, `${FORMAT.teamSize - team.sets.length}마리 더 넣어야 배틀할 수 있다`));
		else if (problems?.length) status.appendChild(h('div', { class: 'problems' }, '확인할 점', h('ul', null, problems.map(p => h('li', null, koProblem(p))))));
		else status.appendChild(h('div', { class: 'problems ok' }, '사용 가능한 파티'));
	};
	async function editSlot(i: number) {
		const res = await editSet(team.sets[i], team.sets, i);
		if (res === 'delete') team.sets.splice(i, 1);
		else if (res) team.sets[i] = res;
		else return;
		dirty = true; draw();
	}
	const save = () => {
		if (!team.name.trim()) team.name = '이름 없는 파티';
		if (!saveTeam(team)) { toast('저장하지 못했다 (저장 공간 확인)'); return false; }
		dirty = false; toast('저장했다'); return true;
	};
	const leave = () => {
		if (!dirty) { nav.teams(); return; }
		sheet(close => [
			h('h2', null, '저장하지 않은 변경이 있다'),
			h('div', { class: 'row' },
				h('button', { class: 'btn primary grow', type: 'button', on: { click: () => { close(); if (save()) nav.teams(); } } }, '저장하고 나가기'),
				h('button', { class: 'btn danger', type: 'button', on: { click: () => { close(); nav.teams(); } } }, '버리기')),
		], { center: true, label: '저장 확인' });
	};
	draw();
	app.appendChild(h('div', { class: 'page' },
		h('div', { class: 'topbar' },
			h('button', { class: 'btn small back', type: 'button', 'aria-label': '파티 목록으로', on: { click: leave } }, '←'),
			h('h2', null, existing ? '파티 편집' : '새 파티'),
			h('button', { class: 'btn small primary', type: 'button', on: { click: save } }, '저장')),
		nameIn,
		h('section', { class: 'panel' }, h('h2', null, '포켓몬', h('span', { class: 'muted' }, '눌러서 편집')), slots, status),
		h('section', { class: 'panel' },
			h('div', { class: 'row' },
				h('button', {
					class: 'btn grow', type: 'button', on: {
						click: () => {
							const problems = team.sets.length === FORMAT.teamSize ? validateTeam(team.sets) : ['부족'];
							if (problems) { toast('사용 가능한 파티가 아니다'); return; }
							if (dirty) save();
							settings.activeTeam = team.id; saveSettings();
							nav.battle(team.sets.map(clone));
						},
					},
				}, '이 파티로 배틀'),
				h('button', { class: 'btn', type: 'button', on: { click: () => exportDialog(team.sets) } }, '텍스트로 내보내기')),
			h('div', { class: 'row' },
				h('button', { class: 'btn small', type: 'button', on: { click: () => importDialog(team, sets => { team.sets = sets; dirty = true; draw(); }) } }, '텍스트로 덮어쓰기'),
				h('button', {
					class: 'btn small', type: 'button', on: {
						click: () => confirmSheet('샘플 세트로 6마리를 무작위로 채울까?', '채우기', () => { team.sets = RandomTeamSource.generate(); dirty = true; draw(); }, false),
					},
				}, '무작위로 채우기'),
				existing ? h('button', {
					class: 'btn small danger', type: 'button', on: {
						click: () => confirmSheet(`'${team.name}' 파티를 지울까?`, '지우기', () => { deleteTeam(team.id); nav.teams(); }),
					},
				}, '파티 지우기') : null)),
	));
	if (openIndex != null && team.sets[openIndex]) editSlot(openIndex);
}

function exportDialog(sets: PokemonSet[]) {
	sheet(close => {
		const ta = h('textarea', { class: 'text', readonly: true }, exportTeam(sets));
		return [
			h('h2', null, '텍스트로 내보내기', h('button', { class: 'btn small', type: 'button', on: { click: close } }, '닫기')),
			h('div', { class: 'muted' }, 'Showdown 형식. EVs 칸이 SP다.'),
			ta,
			h('button', {
				class: 'btn primary', type: 'button', on: {
					click: async () => {
						try { await navigator.clipboard.writeText(ta.value); toast('복사했다'); } catch { ta.select(); toast('길게 눌러 복사'); }
					},
				},
			}, '복사'),
		];
	}, { label: '텍스트로 내보내기' });
}

/** 새로 넣을 때: 다른 포켓몬과 도구가 겹치지 않는 샘플을 고른다 */
function firstSample(species: string, others: PokemonSet[] = []): PokemonSet {
	const used = new Set(others.map(s => toID(s.item)).filter(Boolean));
	const samples = sampleSets(species);
	const ok = samples.find(s => !used.has(toID(s.set.item)));
	if (ok) return clone(ok.set);
	const set = samples[0] ? clone(samples[0].set) : blankSet(species);
	if (used.has(toID(set.item))) set.item = SPARE_ITEMS.find(i => !used.has(toID(i))) ?? '';
	return set;
}

// ---------------------------------------------------------------- 포켓몬 고르기 (5열 표)
const GEN_RANGES = [0, 151, 251, 386, 493, 649, 721, 809, 905, 1025];
const genOf = (num: number) => GEN_RANGES.findIndex((max, i) => i > 0 && num <= max) || 9;
interface DexRow { name: string; ko: string; num: number; gen: number; types: string[]; mega: boolean }
let dexRows: DexRow[] | null = null;
function allPickable(): DexRow[] {
	if (dexRows) return dexRows;
	const stones = dex.items.all().filter((i: any) => !i.isNonstandard && i.megaStone);
	const megaBases = new Set<string>();
	for (const st of stones) for (const b of Object.keys(st.megaStone)) megaBases.add(toID(b));
	dexRows = dex.species.all().filter(isPickable)
		.map((s: any) => ({ name: s.name, ko: koSpecies(s.name), num: s.num, gen: genOf(s.num), types: s.types, mega: megaBases.has(s.id) }))
		.sort((a: DexRow, b: DexRow) => a.num - b.num || a.name.localeCompare(b.name));
	return dexRows!;
}

let lastFilter = { gen: 0, types: [] as string[], mega: false, q: '' };
function pickSpecies(taken: string[], current?: string): Promise<string | null> {
	return new Promise(resolve => {
		let done = false;
		const close = sheet(closeSheet => {
			const f = lastFilter;
			const grid = h('div', { class: 'dexgrid' });
			const count = h('span', { class: 'grid-count' });
			const q = h('input', { class: 'text', type: 'search', placeholder: '이름 검색 (초성 가능: ㄹㅈㅁ)', value: f.q, 'aria-label': '포켓몬 이름 검색' });
			const takenIds = new Set(taken.map(t => dex.species.get(t).baseSpecies).filter(b => b !== (current && dex.species.get(current).baseSpecies)));
			const draw = () => {
				clear(grid);
				const rows = allPickable().filter(r => (!f.gen || r.gen === f.gen) && f.types.every(t => r.types.includes(t)) && (!f.mega || r.mega) && matchKo(r.ko, f.q));
				count.textContent = `${rows.length}마리`;
				for (const r of rows.slice(0, 400)) {
					const blocked = takenIds.has(dex.species.get(r.name).baseSpecies);
					const cell = h('button', {
						class: 'dexcell' + (current === r.name ? ' sel' : ''), type: 'button', disabled: blocked,
						'aria-label': `${r.ko} ${r.types.map(koType).join('/')}${blocked ? ' (이미 파티에 있음)' : ''}`,
						on: { click: () => { done = true; closeSheet(); resolve(r.name); } },
					},
					thumb(r.name, 44),
					h('span', { class: 'nm' }, r.ko),
					h('span', { class: 'tt' }, r.types.map(t => h('i', { style: `background:${TYPE_COLOR[t]}` }))),
					r.mega ? h('span', { class: 'mega' }, 'MEGA') : h('span', { class: 'no' }, `No.${r.num}`));
					grid.appendChild(cell);
				}
			};
			q.addEventListener('input', () => { f.q = q.value; draw(); });
			const genChips = h('div', { class: 'chips', role: 'group', 'aria-label': '세대' });
			const drawGen = () => {
				clear(genChips);
				for (let g = 0; g <= 9; g++) genChips.appendChild(h('button', { class: 'chip', type: 'button', 'aria-pressed': String(f.gen === g), on: { click: () => { f.gen = g; drawGen(); draw(); } } }, g ? `${g}세대` : '전체'));
				genChips.appendChild(h('button', { class: 'chip', type: 'button', 'aria-pressed': String(f.mega), on: { click: () => { f.mega = !f.mega; drawGen(); draw(); } } }, '메가 가능'));
			};
			const typeChips = h('div', { class: 'chips', role: 'group', 'aria-label': '타입' });
			const drawTypes = () => {
				clear(typeChips);
				for (const t of TYPES) typeChips.appendChild(h('button', {
					class: 'chip type', type: 'button', style: `background:${TYPE_COLOR[t]}`, 'aria-pressed': String(f.types.includes(t)),
					on: { click: () => { f.types = f.types.includes(t) ? f.types.filter(x => x !== t) : [...f.types, t].slice(-2); drawTypes(); draw(); } },
				}, koType(t)));
			};
			drawGen(); drawTypes(); draw();
			return [
				h('div', { class: 'topbar' },
					h('button', { class: 'btn small back', type: 'button', on: { click: closeSheet } }, '←'),
					h('h2', null, '포켓몬 고르기'), count),
				q, genChips, typeChips, grid,
			];
		}, { full: true, label: '포켓몬 고르기' });
		// 닫힘 감지 (뒤로 가기 버튼 등)
		const obs = new MutationObserver(() => {
			if (!document.querySelector('.overlay.full[aria-label="포켓몬 고르기"]')) { obs.disconnect(); if (!done) resolve(null); }
		});
		obs.observe(document.body, { childList: true });
		void close;
	});
}

// ---------------------------------------------------------------- 세트 편집
type EditResult = PokemonSet | 'delete' | null;
function editSet(original: PokemonSet, teamSets: PokemonSet[], index: number, isNew = false): Promise<EditResult> {
	return new Promise(resolve => {
		let set = clone(original);
		let result: EditResult = null;
		const label = '세트 편집';
		const body = h('div', { style: 'display:flex;flex-direction:column;gap:14px' });
		const otherSets = teamSets.filter((_, i) => i !== index);

		const draw = () => {
			clear(body);
			const sp = dex.species.get(set.species);
			// 머리
			body.appendChild(h('div', { class: 'edit-head' },
				thumb(set.species, 72),
				h('div', { style: 'display:flex;flex-direction:column;gap:6px;min-width:0' },
					h('div', { class: 'row', style: 'gap:6px' }, h('b', { style: 'font-size:18px' }, koSpecies(set.species)), ...speciesTypes(set.species).map(typeTag)),
					h('button', {
						class: 'btn small', type: 'button', on: {
							click: async () => {
								const ns = await pickSpecies(otherSets.map(s => s.species), set.species);
								if (ns && ns !== set.species) { set = firstSample(ns, otherSets); draw(); }
							},
						},
					}, '포켓몬 바꾸기'))));
			body.appendChild(statLine(set));
			// 샘플
			const samples = sampleSets(set.species);
			if (samples.length) {
				body.appendChild(h('section', { style: 'display:flex;flex-direction:column;gap:6px' },
					h('h2', null, '샘플 세트', h('span', { class: 'muted' }, '눌러서 적용')),
					h('div', { class: 'samples' }, samples.map(s => h('button', {
						class: 'sample', type: 'button', on: { click: () => { set = clone(s.set); draw(); toast(`${s.role} 세트를 적용했다`); } },
					},
					h('b', null, s.role),
					h('span', null, `${koItem(s.set.item) || '도구 없음'} · ${koAbility(s.set.ability)} · ${koNature(s.set.nature)}`),
					h('span', { style: 'color:var(--ink)' }, s.set.moves.map(koMove).join(' / ')))))));
			}
			// 도구
			body.appendChild(h('div', { class: 'field' }, h('span', null, '도구'),
				h('button', { class: 'pick' + (set.item ? '' : ' empty'), type: 'button', on: { click: async () => { const it = await pickItem(set, otherSets); if (it !== null) { set.item = it; draw(); } } } },
					h('div', null, koItem(set.item) || '없음', set.item ? h('div', null, h('small', null, koItemDesc(set.item))) : null), '›')));
			// 특성
			const abil = h('div', { class: 'abil', role: 'group', 'aria-label': '특성' });
			for (const a of [...new Set(Object.values(sp.abilities) as string[])]) {
				abil.appendChild(h('button', { type: 'button', 'aria-pressed': String(toID(a) === toID(set.ability)), on: { click: () => { set.ability = a; draw(); } } },
					h('b', null, koAbility(a)), h('span', null, koAbilityDesc(a))));
			}
			body.appendChild(h('div', { class: 'field', style: 'align-items:start' }, h('span', { style: 'padding-top:10px' }, '특성'), abil));
			// 기술
			const ms = h('div', { class: 'moveslots' });
			for (let i = 0; i < 4; i++) {
				const m = set.moves[i];
				if (m) {
					const info = moveInfo(m);
					ms.appendChild(h('button', {
						class: 'moveslot', type: 'button', style: `background:${TYPE_COLOR[info.type] ?? '#666'}`,
						on: { click: async () => { const nm = await pickMove(set, i); if (nm !== null) { if (nm) set.moves[i] = nm; else set.moves.splice(i, 1); draw(); } } },
					}, koMove(m), h('small', null, `${CATEGORY_KO[info.category]} · ${info.power || '-'} · ${info.accuracy ?? '-'}`)));
				} else {
					ms.appendChild(h('button', {
						class: 'moveslot empty', type: 'button',
						on: { click: async () => { const nm = await pickMove(set, set.moves.length); if (nm) { set.moves.push(nm); draw(); } } },
					}, '＋ 기술'));
					break;
				}
			}
			body.appendChild(h('section', { style: 'display:flex;flex-direction:column;gap:6px' }, h('h2', null, '기술', h('span', { class: 'muted' }, `${set.moves.length}/4`)), ms));
			// 성격
			body.appendChild(h('section', { style: 'display:flex;flex-direction:column;gap:6px' },
				h('h2', null, '성격', h('span', { class: 'muted' }, `${koNature(set.nature)} · 세로 ↑ / 가로 ↓`)),
				natureTable(set.nature, n => { set.nature = n; draw(); })));
			// SP
			body.appendChild(spEditor(set, () => draw()));
			// 문제
			const probs = validateSet(set);
			if (probs?.length) body.appendChild(h('div', { class: 'problems' }, h('ul', null, probs.map(p => h('li', null, koProblem(p))))));
		};

		const closeFn = sheet(close => {
			draw();
			return [
				h('div', { class: 'topbar' },
					h('button', { class: 'btn small back', type: 'button', 'aria-label': '취소', on: { click: close } }, '←'),
					h('h2', null, isNew ? '포켓몬 추가' : '포켓몬 편집'),
					h('button', { class: 'btn small primary', type: 'button', on: { click: () => { result = set; close(); } } }, '완료')),
				body,
				h('div', { class: 'stickybar' },
					h('button', { class: 'btn primary grow', type: 'button', on: { click: () => { result = set; close(); } } }, '완료'),
					!isNew ? h('button', { class: 'btn danger', type: 'button', on: { click: () => { result = 'delete'; close(); } } }, '파티에서 빼기') : null),
			];
		}, { full: true, label });
		const obs = new MutationObserver(() => {
			if (!document.querySelector(`.overlay.full[aria-label="${label}"]`)) { obs.disconnect(); resolve(result); }
		});
		obs.observe(document.body, { childList: true });
		void closeFn;
	});
}

// 성격 5×5 표: 행 = 올라가는 능력, 열 = 내려가는 능력
const NAT_STATS: StatID[] = ['atk', 'def', 'spa', 'spd', 'spe'];
function natureTable(current: string, onPick: (n: string) => void) {
	const natures = dex.natures.all();
	const find = (plus: StatID, minus: StatID) => natures.find((n: any) => (plus === minus ? !n.plus && n.name === NEUTRAL[plus] : n.plus === plus && n.minus === minus));
	const NEUTRAL: Record<string, string> = { atk: 'Hardy', def: 'Docile', spa: 'Serious', spd: 'Bashful', spe: 'Quirky' };
	return h('table', { class: 'nature' },
		h('thead', null, h('tr', null, h('th', null, ''), NAT_STATS.map(s => h('th', { class: 'minus' }, `${STAT_SHORT[s]}↓`)))),
		h('tbody', null, NAT_STATS.map(plus => h('tr', null,
			h('th', { class: 'plus' }, `${STAT_SHORT[plus]}↑`),
			NAT_STATS.map(minus => {
				const n = find(plus, minus);
				if (!n) return h('td');
				const sel = toID(current) === n.id;
				return h('td', null, h('button', { type: 'button', class: plus === minus ? 'neutral' : '', 'aria-pressed': String(sel), on: { click: () => onPick(n.name) } }, koNature(n.name)));
			})))));
}

// SP 편집: 능력치마다 0~32, 합계 66
function spEditor(set: PokemonSet, redraw: () => void) {
	const sp = dex.species.get(set.species);
	const box = h('section', { class: 'sp' });
	const left = h('span', { class: 'sp-left' });
	const rows: Record<string, { range: HTMLInputElement; v: HTMLElement; tot: HTMLElement }> = {};
	const update = () => {
		const total = statTotal(set);
		left.textContent = `남은 SP ${FORMAT.spTotal - total} / ${FORMAT.spTotal}`;
		left.classList.toggle('over', total > FORMAT.spTotal);
		for (const s of STATS) {
			rows[s].range.value = String(set.evs[s]);
			rows[s].v.textContent = String(set.evs[s]);
			rows[s].tot.textContent = String(calcStat(s, sp.baseStats[s], set.evs[s], set.nature));
		}
	};
	const setSP = (s: StatID, v: number) => {
		const others = statTotal(set) - set.evs[s];
		set.evs[s] = Math.max(0, Math.min(FORMAT.spPerStat, v, FORMAT.spTotal - others));
		update();
	};
	const n = dex.natures.get(set.nature);
	box.appendChild(h('h2', null, '능력 포인트 (SP)', left));
	for (const s of STATS) {
		const range = h('input', { type: 'range', min: 0, max: FORMAT.spPerStat, step: 1, 'aria-label': `${STAT_SHORT[s]} SP`, on: { input: () => setSP(s, +range.value) } }) as HTMLInputElement;
		const v = h('span', { class: 'v' });
		const tot = h('span', { class: 'tot' });
		rows[s] = { range, v, tot };
		box.appendChild(h('div', { class: 'sprow' },
			h('span', { class: 'nm' + (n.plus === s ? ' plus' : n.minus === s ? ' minus' : '') }, STAT_SHORT[s]),
			h('span', { class: 'base', title: '종족값' }, String(sp.baseStats[s])),
			range,
			h('button', { type: 'button', 'aria-label': `${STAT_SHORT[s]} 최대`, on: { click: () => setSP(s, set.evs[s] >= FORMAT.spPerStat ? 0 : FORMAT.spPerStat) } }, 'M'),
			v, tot));
	}
	box.appendChild(h('div', { class: 'row' },
		h('span', { class: 'muted grow' }, '가운데 숫자 = 종족값 · 오른쪽 = Lv50 실수치'),
		h('button', { class: 'btn small', type: 'button', on: { click: () => { for (const s of STATS) set.evs[s] = 0; update(); } } }, '초기화')));
	update();
	void redraw;
	return box;
}

// 기술 고르기: 5열 표 (이름·타입·분류·위력·명중)
let moveFilter = { type: '', cat: 'all', q: '', sort: 'power' };
function pickMove(set: PokemonSet, slot: number): Promise<string | '' | null> {
	return new Promise(resolve => {
		let result: string | '' | null = null;
		const label = '기술 고르기';
		sheet(close => {
			const f = moveFilter;
			const pool = [...dex.species.getMovePool(dex.species.get(set.species).id)].map(id => dex.moves.get(id)).filter((m: any) => m.exists && !m.isNonstandard);
			const current = set.moves[slot];
			const others = new Set(set.moves.filter((_, i) => i !== slot).map(toID));
			const tbody = h('tbody');
			const count = h('span', { class: 'grid-count' });
			const q = h('input', { class: 'text', type: 'search', placeholder: '기술 이름 검색', value: f.q, 'aria-label': '기술 검색' });
			const draw = () => {
				clear(tbody);
				let rows = pool.filter((m: any) => (!f.type || m.type === f.type) && (f.cat === 'all' || m.category === f.cat) && matchKo(koMove(m.name), f.q));
				rows = rows.sort((a: any, b: any) => f.sort === 'name' ? koMove(a.name).localeCompare(koMove(b.name), 'ko') : f.sort === 'type' ? a.type.localeCompare(b.type) || b.basePower - a.basePower : b.basePower - a.basePower || koMove(a.name).localeCompare(koMove(b.name), 'ko'));
				count.textContent = `${rows.length}개`;
				for (const m of rows) {
					const dup = others.has(m.id);
					tbody.appendChild(h('tr', {
						class: (toID(current) === m.id ? 'sel' : '') + (dup ? ' dim' : ''), tabindex: 0,
						on: {
							click: () => { if (dup) { toast('이미 넣은 기술'); return; } result = m.name; close(); },
							keydown: (e: KeyboardEvent) => { if (e.key === 'Enter' && !dup) { result = m.name; close(); } },
						},
					},
					h('td', null, koMove(m.name), h('div', { class: 'movedesc' }, (koMoveDesc(m.name) || '').slice(0, 42))),
					h('td', null, typeTag(m.type)),
					h('td', null, CATEGORY_KO[m.category]),
					h('td', { class: 'num' }, m.basePower || '-'),
					h('td', { class: 'num' }, m.accuracy === true ? '-' : m.accuracy)));
				}
			};
			q.addEventListener('input', () => { f.q = q.value; draw(); });
			const typeChips = h('div', { class: 'chips' });
			const drawTypes = () => {
				clear(typeChips);
				const present = new Set(pool.map((m: any) => m.type));
				for (const t of TYPES.filter(t => present.has(t))) typeChips.appendChild(h('button', {
					class: 'chip type', type: 'button', style: `background:${TYPE_COLOR[t]}`, 'aria-pressed': String(f.type === t),
					on: { click: () => { f.type = f.type === t ? '' : t; drawTypes(); draw(); } },
				}, koType(t)));
			};
			drawTypes(); draw();
			return [
				h('div', { class: 'topbar' },
					h('button', { class: 'btn small back', type: 'button', on: { click: close } }, '←'),
					h('h2', null, `기술 ${slot + 1}`), count,
					current ? h('button', { class: 'btn small danger', type: 'button', on: { click: () => { result = ''; close(); } } }, '비우기') : null),
				q,
				seg('분류', [['all', '전체'], ['Physical', '물리'], ['Special', '특수'], ['Status', '변화']], f.cat as any, v => { f.cat = v; draw(); }),
				typeChips,
				seg('정렬', [['power', '위력순'], ['type', '타입순'], ['name', '이름순']], f.sort as any, v => { f.sort = v; draw(); }),
				h('table', { class: 'moves-t' },
					h('thead', null, h('tr', null, h('th', null, '기술'), h('th', null, '타입'), h('th', null, '분류'), h('th', { style: 'text-align:right' }, '위력'), h('th', { style: 'text-align:right;padding-right:8px' }, '명중'))),
					tbody),
			];
		}, { full: true, label });
		const obs = new MutationObserver(() => { if (!document.querySelector(`.overlay.full[aria-label="${label}"]`)) { obs.disconnect(); resolve(result); } });
		obs.observe(document.body, { childList: true });
	});
}

// 도구 고르기: 분류 탭 + 3열 표
const POPULAR = ['Focus Sash', 'Sitrus Berry', 'Leftovers', 'Choice Scarf', 'Choice Specs', 'Choice Band', 'Life Orb', 'Assault Vest', 'Rocky Helmet',
	'Lum Berry', 'Mental Herb', 'White Herb', 'Quick Claw', 'Kings Rock', 'Expert Belt', 'Black Sludge', 'Shell Bell', 'Bright Powder', 'Scope Lens'];
let itemTab = 'popular';
function pickItem(set: PokemonSet, otherSets: PokemonSet[]): Promise<string | null> {
	return new Promise(resolve => {
		let result: string | null = null;
		const label = '도구 고르기';
		sheet(close => {
			const all = dex.items.all().filter((i: any) => !i.isNonstandard);
			const used = new Set(otherSets.map(s => toID(s.item)).filter(Boolean));
			const species = dex.species.get(set.species);
			const grid = h('div', { class: 'itemgrid' });
			const q = h('input', { class: 'text', type: 'search', placeholder: '도구 이름 검색', 'aria-label': '도구 검색' });
			const draw = () => {
				clear(grid);
				let rows: any[];
				const query = q.value;
				if (query) rows = all.filter((i: any) => matchKo(koItem(i.name), query));
				else if (itemTab === 'mega') rows = all.filter((i: any) => i.megaStone && Object.keys(i.megaStone).some(b => toID(b) === species.id));
				else if (itemTab === 'berry') rows = all.filter((i: any) => i.isBerry);
				else if (itemTab === 'popular') rows = POPULAR.map(n => all.find((i: any) => i.name.replace(/'/g, '') === n.replace(/'/g, ''))).filter(Boolean);
				else rows = all.filter((i: any) => !i.megaStone).sort((a: any, b: any) => koItem(a.name).localeCompare(koItem(b.name), 'ko'));
				if (itemTab === 'mega' && !query && !rows.length) grid.appendChild(h('div', { class: 'muted', style: 'grid-column:1/-1' }, '이 포켓몬은 메가진화하지 않는다'));
				for (const i of rows) {
					const dup = used.has(i.id);
					const wrongMega = i.megaStone && !Object.keys(i.megaStone).some((b: string) => toID(b) === species.id);
					grid.appendChild(h('button', {
						class: 'itemcell' + (toID(set.item) === i.id ? ' sel' : '') + (i.megaStone ? ' mega' : ''), type: 'button',
						disabled: dup || wrongMega, style: dup || wrongMega ? 'opacity:.35' : '',
						title: koItemDesc(i.name),
						on: { click: () => { result = i.name; close(); } },
					}, koItem(i.name)));
				}
			};
			q.addEventListener('input', draw);
			draw();
			return [
				h('div', { class: 'topbar' },
					h('button', { class: 'btn small back', type: 'button', on: { click: close } }, '←'),
					h('h2', null, '도구'),
					set.item ? h('button', { class: 'btn small danger', type: 'button', on: { click: () => { result = ''; close(); } } }, '빼기') : null),
				q,
				seg('분류', [['popular', '자주 씀'], ['mega', '메가스톤'], ['berry', '나무열매'], ['all', '전체']], itemTab as any, v => { itemTab = v; q.value = ''; draw(); }),
				h('div', { class: 'muted' }, '흐린 칸: 다른 포켓몬이 이미 든 도구'),
				grid,
			];
		}, { full: true, label });
		const obs = new MutationObserver(() => { if (!document.querySelector(`.overlay.full[aria-label="${label}"]`)) { obs.disconnect(); resolve(result); } });
		obs.observe(document.body, { childList: true });
	});
}

export { setDetail };
