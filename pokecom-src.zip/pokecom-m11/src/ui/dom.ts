// 아주 작은 DOM 헬퍼 (M1과 동일한 방식)
type Child = Node | string | number | null | undefined | false | Child[];
type Attrs = Record<string, any> & { on?: Record<string, (e: any) => void> };

export function h<K extends keyof HTMLElementTagNameMap>(tag: K, attrs?: Attrs | null, ...children: Child[]): HTMLElementTagNameMap[K] {
	const el = document.createElement(tag);
	if (attrs) {
		for (const [k, v] of Object.entries(attrs)) {
			if (k === 'on' && v) for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn as EventListener);
			else if (k === 'class') el.className = String(v);
			else if (k === 'style' && typeof v === 'string') el.setAttribute('style', v);
			else if (k === 'html') el.innerHTML = String(v);
			else if (v === true) el.setAttribute(k, '');
			else if (v !== false && v != null) {
				if (k in el && typeof v !== 'string') (el as any)[k] = v;
				else el.setAttribute(k, String(v));
			}
		}
	}
	append(el, children);
	return el;
}
export function append(el: Node, children: Child[]) {
	for (const c of children) {
		if (c == null || c === false) continue;
		if (Array.isArray(c)) append(el, c);
		else el.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c)));
	}
}
export function clear(el: Node) { while (el.firstChild) el.removeChild(el.firstChild); }

export function toast(text: string, ms = 2400) {
	const t = h('div', { class: 'toast', role: 'status' }, text);
	document.body.appendChild(t);
	setTimeout(() => t.remove(), ms);
}

export interface SheetOpts { center?: boolean; label?: string; dismissable?: boolean; full?: boolean }
/** 아래에서 올라오는 시트(또는 가운데 대화상자). build(close) 가 내용을 만든다. */
export function sheet(build: (close: () => void) => Child, opts: SheetOpts = {}): () => void {
	const overlay = h('div', { class: 'overlay' + (opts.center ? ' center' : '') + (opts.full ? ' full' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': opts.label ?? '' });
	const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape' && opts.dismissable !== false) close(); };
	const close = () => { overlay.remove(); document.removeEventListener('keydown', onKey); };
	const box = h('div', { class: 'sheet' }, build(close));
	overlay.appendChild(box);
	if (opts.dismissable !== false) overlay.addEventListener('click', e => { if (e.target === overlay) close(); });
	document.addEventListener('keydown', onKey);
	document.body.appendChild(overlay);
	(box.querySelector('button, [tabindex], input') as HTMLElement | null)?.focus({ preventScroll: true });
	return close;
}

export function confirmSheet(title: string, okLabel: string, onOk: () => void, danger = true) {
	sheet(close => [
		h('h2', null, title),
		h('div', { class: 'row' },
			h('button', { class: `btn ${danger ? 'danger' : 'primary'} grow`, type: 'button', on: { click: () => { close(); onOk(); } } }, okLabel),
			h('button', { class: 'btn', type: 'button', on: { click: close } }, '취소')),
	], { center: true, label: title });
}

/**
 * 한 줄에 다 안 들어가는 글: 잘라내지 않고 좌우로 밀어서 끝까지 볼 수 있게 한다.
 * 넘칠 때만 오른쪽 끝을 흐리게(ovf), 끝까지 밀면 흐림을 없앤다(end).
 */
let hsObserver: ResizeObserver | null = null;
function hsCheck(el: HTMLElement) {
	const over = el.scrollWidth > el.clientWidth + 1;
	el.classList.toggle('ovf', over);
	el.classList.toggle('end', !over || el.scrollLeft + el.clientWidth >= el.scrollWidth - 2);
}
export function hscroll<T extends HTMLElement>(el: T): T {
	el.classList.add('hs');
	el.addEventListener('scroll', () => hsCheck(el), { passive: true });
	if (typeof ResizeObserver === 'function') {
		hsObserver ??= new ResizeObserver(entries => { for (const e of entries) hsCheck(e.target as HTMLElement); });
		hsObserver.observe(el);
	}
	return el;
}

/** 줄여 보이는 설명: 누르면 전체를 펼치고, 다시 누르면 접는다 (부모 버튼의 선택 동작은 막는다) */
export function expandable<T extends HTMLElement>(el: T, label = '설명 펼치기'): T {
	el.classList.add('xp');
	el.setAttribute('role', 'button');
	el.setAttribute('tabindex', '0');
	el.setAttribute('aria-expanded', 'false');
	el.setAttribute('aria-label', label);
	const toggle = (e: Event) => { e.stopPropagation(); e.preventDefault(); const open = !el.classList.contains('open'); el.classList.toggle('open', open); el.setAttribute('aria-expanded', String(open)); };
	el.addEventListener('click', toggle);
	el.addEventListener('keydown', (e: KeyboardEvent) => { if (e.key === 'Enter' || e.key === ' ') toggle(e); });
	return el;
}
