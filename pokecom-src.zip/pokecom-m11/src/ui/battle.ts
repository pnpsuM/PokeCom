// 배틀 화면 (M1 BattleController 복원, Z기술 제거·메가진화만)
import { h, clear, sheet, toast, confirmSheet } from './dom';
import { app, nav } from './nav';
import { typeTag, spriteInto, monRow, moveCard, TYPE_COLOR, thumb } from './common';
import { BattleSession } from '../core/session';
import { BattleView, WEATHER_KO, type LogEntry } from '../core/view';
import { makeAgent } from '../core/ai/agent';
import { PRACTICE_PROFILE } from '../config/rating';
import { loadState, recordGame, matchmake, gradeOf, kFactor, preview as eloPreview, RATED, type RatedProfile, type LadderState } from '../core/ladder';
import { gradeBadge } from './ladder-ui';
import { OpponentSource, curatedLabel, type CuratedParty } from '../core/teams';
import { FORMAT, dex, type PokemonSet } from '../core/format';
import { toID } from '../sim';
import { koSpecies, koMove, koType, koAbility, koItem, koAbilityDesc, koItemDesc, STAT_KO, STATUS_KO, eun, euro, koEffect } from '../core/ko';
import { badgeFor, effectiveness, moveType, speciesTypes } from '../core/typecalc';
import { settings } from '../core/store';
import { prefetch } from '../sprites';
import { BattleFx } from './fx';

/** 타입이 바뀐 이유 문구: '스카이스킨으로 노말 → 비행' */
function typeNote(t: { type: string; baseType: string; cause: string; abilityId?: string; id: string }) {
	const why = t.cause === 'ability' && t.abilityId ? koAbility(t.abilityId) : `${koMove(t.id)} 효과`;
	return `${euro(why)} ${koType(t.baseType)} → ${koType(t.type)}`;
}
/** 변환자재·리베로 문구: '변환자재: 쓰면 물 타입이 된다 (자속 보정 1.5배)' */
function shiftNote(b: { abilityId: string; type: string; stab: boolean }) {
	return `${koAbility(b.abilityId)}: 쓰면 ${koType(b.type)} 타입이 된다${b.stab ? ' (자속 보정 1.5배)' : ''}`;
}

export interface BattleOpts { opp?: PokemonSet[]; oppParty?: CuratedParty | null; profile?: RatedProfile; ranked?: boolean }
const PRACTICE: RatedProfile = { ...(RATED.find(p => p.id === PRACTICE_PROFILE) ?? RATED[0]), label: `${RATED.find(p => p.id === PRACTICE_PROFILE)?.label ?? '랜덤'} (연습)` };

/** 연습 배틀 (랜덤 AI, 레이팅 없음) 또는 opts 로 지정한 상대 */
export function startBattle(team: PokemonSet[], opts: BattleOpts | PokemonSet[] = {}) {
	const o: BattleOpts = Array.isArray(opts) ? { opp: opts } : opts;
	const gen = o.opp ? { team: o.opp, party: o.oppParty ?? null } : OpponentSource.generate();
	const c = new BattleController(team, gen.team, o.profile ?? PRACTICE, !!o.ranked);
	c.oppParty = gen.party;
	c.start();
}
/** 래더 배틀: 내 레이팅 근처 AI 와 매칭 */
export async function startLadder(team: PokemonSet[]) {
	const st = await loadState();
	startBattle(team, { profile: matchmake(st.rating), ranked: true });
}

class BattleController {
	view: BattleView;
	session!: BattleSession;
	queue: string[] = [];
	live = false;
	pumping = false;
	skip = false;
	pendingReq: any = null;
	ended = false;
	megaOn = false;
	logEl!: HTMLElement; cmdEl!: HTMLElement; innerEl!: HTMLElement; fieldEl!: HTMLElement; oppPartyEl!: HTMLElement;
	fx!: BattleFx;
	sprEl: Record<string, HTMLElement> = {};
	infoEl: Record<string, HTMLElement> = {};
	shown: Record<string, string> = { p1: '', p2: '' };

	picks: string[] = [];
	recorded = false;
	ladder: LadderState | null = null;
	/** 상대가 샘플 파티를 들고 나왔으면 그 정보 (끝난 뒤 공개) */
	oppParty: CuratedParty | null = null;
	constructor(public team: PokemonSet[], public oppTeam: PokemonSet[], public profile: RatedProfile, public ranked: boolean) {
		this.view = new BattleView(settings.playerName, '컴퓨터');
		if (ranked) loadState().then(s => (this.ladder = s));
	}

	start() {
		this.session = new BattleSession({
			format: FORMAT,
			p1: { name: settings.playerName, team: this.team },
			p2: { name: '컴퓨터', team: this.oppTeam, agent: makeAgent(this.profile) },
		}, {
			onLine: line => { if (this.live) { this.queue.push(line); this.pump(); } else this.view.add(line); },
			onRequest: req => {
				if (req.teamPreview) { this.view.setOwnTeam(req.side.pokemon); this.renderPreview(req); return; }
				this.pendingReq = req; this.pump();
			},
			onEnd: () => { this.ended = true; this.pump(); },
			onError: msg => { if (!msg.includes('Unavailable choice')) toast('선택 오류: ' + msg); },
		});
	}

	setFor(details: string, i: number) {
		const sp = details.split(',')[0];
		return this.team.find(s => koSpecies(s.species) === koSpecies(sp)) ?? this.team[i];
	}

	renderPreview(req: any) {
		clear(app);
		const order: number[] = [];
		const btn = h('button', { class: 'btn primary', type: 'button', disabled: true, style: 'min-height:54px;font-size:17px' }, `선출 확정 (0/${FORMAT.pickSize})`);
		const rows: HTMLElement[] = [];
		const refresh = () => {
			rows.forEach((el, i) => {
				const k = order.indexOf(i + 1);
				el.classList.toggle('picked', k >= 0);
				(el.querySelector('.order') as HTMLElement).textContent = k >= 0 ? String(k + 1) : '';
				el.setAttribute('aria-pressed', String(k >= 0));
			});
			btn.disabled = order.length !== FORMAT.pickSize;
			btn.textContent = `선출 확정 (${order.length}/${FORMAT.pickSize})`;
		};
		req.side.pokemon.forEach((p: any, i: number) => {
			const set = this.setFor(p.details, i);
			rows.push(monRow(set, h('span', { class: 'order', 'aria-hidden': 'true' }), () => {
				const k = order.indexOf(i + 1);
				if (k >= 0) order.splice(k, 1); else if (order.length < FORMAT.pickSize) order.push(i + 1);
				refresh();
			}));
		});
		const oppGrid = h('div', { class: 'opp-grid' }, this.view.state.sides.p2.team.map(m => {
			const t = h('div', { class: 'thumb' });
			spriteInto(t, m.species, 'front', 1, { download: false, maxH: 64, slotSize: 56 });
			return h('div', { class: 'cell' }, t, koSpecies(m.species), h('div', null, ...speciesTypes(m.species).map(typeTag)));
		}));
		const status = h('div', { class: 'muted', role: 'status' });
		btn.addEventListener('click', async () => {
			btn.disabled = true;
			if (settings.spriteConsent === 'yes') {
				status.textContent = '스프라이트 준비 중…';
				const names = [...this.team.map(s => s.species), ...this.view.state.sides.p2.team.map(m => m.species)];
				for (const s of [...this.team, ...this.oppTeam]) {
					const stone = dex.items.get(s.item).megaStone;
					if (stone) names.push(...Object.values(stone) as string[]);
				}
				await Promise.race([
					prefetch(names, (d, t) => (status.textContent = `스프라이트 받는 중 ${d}/${t}`)),
					new Promise(r => setTimeout(r, 12000)),
				]);
			}
			this.picks = order.map(i => req.side.pokemon[i - 1].details.split(',')[0]);
			this.mountBattle();
			this.session.choose(`team ${order.join('')}`);
		});
		app.appendChild(h('div', { class: 'page' },
			h('div', { class: 'eyebrow' }, this.ranked ? 'LADDER · TEAM PREVIEW' : 'PRACTICE · TEAM PREVIEW'),
			h('section', { class: 'panel' },
				h('h2', null, '상대 파티', h('span', { class: 'muted' }, `${this.profile.label}${this.ranked ? ` · R${this.profile.rating}` : ''}`)),
				this.ranked && this.ladder ? (() => { const pv = eloPreview(this.ladder!, this.profile.rating); return h('div', { class: 'muted' }, `이기면 ${pv.win >= 0 ? '+' : ''}${pv.win} · 지면 ${pv.lose} · 예상 승률 ${Math.round(pv.winProb * 100)}% (K=${kFactor(this.ladder!.games)})`); })() : null,
				oppGrid),
			h('section', { class: 'panel' }, h('h2', null, `선출할 ${FORMAT.pickSize}마리`, h('span', { class: 'muted' }, '누른 순서 = 나오는 순서')), h('div', { class: 'mons' }, rows)),
			btn, status,
			h('button', { class: 'btn ghost', type: 'button', on: { click: nav.home } }, '그만두기')));
		(rows[0] as HTMLElement | undefined)?.focus();
	}

	mountBattle() {
		clear(app);
		this.live = true;
		for (const s of ['p1', 'p2']) { this.sprEl[s] = h('div', { class: 'spr' }); this.infoEl[s] = h('div', { class: 'info' }); }
		this.sprEl.p2.style.cssText = 'left:262px;top:122px';
		this.sprEl.p1.style.cssText = 'left:96px;top:252px';
		this.infoEl.p2.style.cssText = 'left:8px;top:8px;border-radius:4px 14px 4px 4px';
		this.infoEl.p1.style.cssText = 'left:180px;bottom:8px;border-radius:14px 4px 4px 4px';
		this.fieldEl = h('div', { class: 'fieldbar', role: 'status', 'aria-label': '필드 상태' });
		this.oppPartyEl = h('div', { class: 'oppparty', role: 'status' });
		this.innerEl = h('div', { class: 'inner' },
			h('div', { class: 'ground' }), h('div', { class: 'stripe', style: 'top:120px' }), h('div', { class: 'stripe', style: 'top:150px' }),
			h('div', { class: 'plat', style: 'left:192px;top:100px;width:140px;height:40px' }),
			h('div', { class: 'plat', style: 'left:-24px;top:226px;width:220px;height:60px' }),
			this.sprEl.p2, this.sprEl.p1, this.infoEl.p2, this.infoEl.p1, this.oppPartyEl);
		this.fx = new BattleFx(this.innerEl, this.sprEl);
		const skip = () => { this.skip = true; this.fx.finishAll(); };
		const screen = h('div', { class: 'screen', on: { click: skip } }, this.innerEl);
		this.logEl = h('div', { class: 'log', role: 'log', 'aria-live': 'polite', on: { click: skip } });
		this.cmdEl = h('div', { class: 'cmd' });
		app.appendChild(h('div', { class: 'battle' }, screen, this.fieldEl, this.logEl, this.cmdEl));
		const fit = () => { this.innerEl.style.transform = `scale(${screen.clientWidth / 360})`; };
		new ResizeObserver(fit).observe(screen); fit();
		for (const e of this.view.state.log) this.appendLog([e]);
		this.renderScene();
		this.cmdWaiting('배틀 준비 중…');
	}

	delayFor(entries: LogEntry[]) {
		if (this.skip || settings.speed === 'instant') return 0;
		const base = { slow: 900, normal: 520, fast: 260, instant: 0 }[settings.speed];
		let d = 0;
		for (const e of entries) d = Math.max(d, e.kind === 'hp' ? base * 0.6 : e.kind === 'turn' ? base * 0.3 : base);
		return d;
	}

	async pump() {
		if (this.pumping || !this.live) return;
		this.pumping = true;
		if (this.queue.length) this.cmdWaiting('▶ 화면을 누르면 빨리 넘긴다', true);
		while (this.queue.length) {
			const line = this.queue.shift()!;
			const before = this.view.state.log.length;
			if (!this.skip) this.fx.play(line);
			this.view.add(line);
			const added = this.view.state.log.slice(before);
			if (added.length) {
				this.renderScene(); this.appendLog(added);
				const d = this.delayFor(added);
				if (d) await new Promise(r => setTimeout(r, d));
			}
		}
		this.pumping = false; this.skip = false;
		this.renderScene();
		if (this.ended) { this.showEnd(); return; }
		if (this.pendingReq) { const r = this.pendingReq; this.pendingReq = null; this.showCommands(r); }
	}

	appendLog(entries: LogEntry[]) {
		for (const e of entries) this.logEl.appendChild(h('p', { class: e.kind + (e.side === 'p2' && e.kind !== 'hp' ? ' p2' : '') }, e.text));
		this.logEl.scrollTop = this.logEl.scrollHeight;
	}

	renderScene() {
		const st = this.view.state;
		for (const sid of ['p1', 'p2'] as const) {
			const m = st.sides[sid].active;
			const info = this.infoEl[sid], spr = this.sprEl[sid];
			if (!m) { info.hidden = true; spr.hidden = true; continue; }
			info.hidden = false; spr.hidden = false;
			const p = m.maxhp ? Math.max(0, Math.round((m.hp / m.maxhp) * 100)) : 0;
			const bar = h('i', { class: p <= 20 ? 'low' : p <= 50 ? 'mid' : '', style: `width:${p}%` });
			const prev = info.querySelector('.hpbar i') as HTMLElement | null;
			clear(info);
			info.append(
				h('div', { class: 'nm' }, h('b', null, koSpecies(m.species)), h('span', null, `${m.gender === 'M' ? '♂' : m.gender === 'F' ? '♀' : ''} Lv${m.level}`)),
				h('div', { class: 'hpbar' }, h('em', null, 'HP'), h('div', null, bar)),
				h('div', { class: 'meta' }, m.status ? h('span', { class: `st ${m.status}` }, STATUS_KO[m.status] ?? m.status) : h('span'), h('span', null, sid === 'p1' ? `${m.hp}/${m.maxhp}` : `${p}%`)));
			this.fx.syncSubstitute(sid, !m.fainted && st.sides[sid].volatiles.includes('substitute'));
			if (prev) { bar.style.width = prev.style.width; requestAnimationFrame(() => requestAnimationFrame(() => (bar.style.width = `${p}%`))); }
			const key = m.nick + '|' + m.species;
			if (this.shown[sid] !== key) {
				this.shown[sid] = key;
				spr.classList.remove('faint');
				spriteInto(spr, m.species, sid === 'p1' ? 'back' : 'front', sid === 'p1' ? 2 : 1.5, { maxH: sid === 'p1' ? 170 : 120 });
			}
			spr.classList.toggle('faint', m.fainted);
		}
		this.renderFieldBar();
		this.renderOppParty();
	}

	/** 상대 선출: 남은 수 + 이미 본 포켓몬 (못 본 칸은 ?) */
	renderOppParty() {
		const side = this.view.state.sides.p2;
		const seen = side.team.filter(m => m.revealed);
		const total = Math.max(FORMAT.pickSize, seen.length);
		const left = total - seen.filter(m => m.fainted).length;
		clear(this.oppPartyEl);
		const cells: HTMLElement[] = seen.map(m => {
			const name = koSpecies(m.species);
			const hp = m.fainted ? '기절' : m.maxhp ? `${Math.round((m.hp / m.maxhp) * 100)}%` : '';
			return h('span', { class: 'pm' + (m.fainted ? ' fnt' : '') + (m === side.active ? ' now' : ''), title: `${name} ${hp}` }, name);
		});
		for (let i = seen.length; i < total; i++) cells.push(h('span', { class: 'pm unk' }, '?'));
		this.oppPartyEl.append(h('b', { class: 'cnt' }, `${left}/${total}`), ...cells);
		this.oppPartyEl.setAttribute('aria-label', `상대 남은 포켓몬 ${left}/${total}. 본 포켓몬: ${seen.map(m => koSpecies(m.species) + (m.fainted ? '(기절)' : '')).join(', ') || '없음'}`);
	}

	/** 필드 상태 막대 (상시 표시): 날씨·필드·트릭룸 / 우리 편 / 상대 편, 시작 후 몇 턴째인지 */
	renderFieldBar() {
		const st = this.view.state;
		const age = (key: string) => { const t0 = st.since[key]; if (t0 === undefined) return ''; const n = st.turn - t0; return n > 0 ? `${n}턴 지남` : '방금'; };
		const chip = (cls: string, name: string, key: string) => {
			const layers = st.layers[key] > 1 ? ` ×${st.layers[key]}` : '';
			return h('span', { class: `fchip ${cls}` }, h('b', null, name + layers), age(key) ? h('i', null, age(key)) : null);
		};
		const all: HTMLElement[] = [];
		if (st.weather) all.push(chip('weather', WEATHER_KO[st.weather] ?? koEffect(st.weather), 'weather'));
		for (const t of st.terrain) all.push(chip(/terrain/i.test(t) ? 'terrain' : 'room', koMove(t), 'field:' + t));
		const mine = st.sides.p1.conditions.map(c => chip('mine', koMove(c), 'p1:' + c));
		const theirs = st.sides.p2.conditions.map(c => chip('theirs', koMove(c), 'p2:' + c));
		clear(this.fieldEl);
		if (!all.length && !mine.length && !theirs.length) { this.fieldEl.appendChild(h('span', { class: 'fnone' }, '필드 효과 없음')); return; }
		if (all.length) this.fieldEl.appendChild(h('div', { class: 'fgroup' }, h('span', { class: 'flabel' }, '전체'), ...all));
		if (mine.length) this.fieldEl.appendChild(h('div', { class: 'fgroup' }, h('span', { class: 'flabel' }, '우리'), ...mine));
		if (theirs.length) this.fieldEl.appendChild(h('div', { class: 'fgroup' }, h('span', { class: 'flabel' }, '상대'), ...theirs));
	}

	cmdWaiting(text: string, clickable = false) {
		clear(this.cmdEl);
		this.cmdEl.appendChild(h('div', { class: 'prompt muted', on: clickable ? { click: () => (this.skip = true) } : undefined }, text));
	}

	showCommands(req: any) {
		this.view.setOwnTeam(req.side.pokemon);
		this.renderScene();
		if (req.forceSwitch) { this.showSwitch(req, true); return; }
		const act = req.active?.[0];
		if (!act) { this.session.choose('default'); return; }
		const me = req.side.pokemon.find((p: any) => p.active);
		const foe = this.view.state.sides.p2.active?.species;
		if (!act.canMegaEvo) this.megaOn = false;
		clear(this.cmdEl);
		const name = koSpecies(me.details.split(',')[0]);
		const preview = this.session.previewMoveTypes(this.megaOn) ?? [];
		const moves = h('div', { class: 'moves' }, act.moves.map((m: any, i: number) => {
			const ti = preview.find(x => x.id === toID(m.id)) ?? preview[i];
			const type = ti?.type ?? moveType(m.id);
			const note = [ti && ti.type !== ti.baseType ? typeNote(ti) : '', ti?.becomes ? shiftNote(ti.becomes) : ''].filter(Boolean).join(' · ');
			const eff = foe ? effectiveness(m.id, foe, type, this.view.state.sides.p2.types) : null;
			const stabTag = ti?.becomes?.stab ? h('span', { class: 'eff stab' }, '자속↑') : null;
			const noPP = m.pp <= 0 && m.maxpp > 0;
			const choice = `move ${i + 1}${this.megaOn ? ' mega' : ''}`;
			const b = h('button', {
				class: 'mv', type: 'button', disabled: !!m.disabled || noPP, style: `background:${TYPE_COLOR[type] ?? '#666'}`,
				'aria-label': `${koMove(m.move)}, ${koType(type)} 타입${note ? ` (${note})` : ''}, PP ${m.pp}/${m.maxpp}${eff == null ? '' : ', ' + badgeFor(eff).label}`,
				on: { click: () => this.send(choice) },
			},
			h('b', null, koMove(m.move)),
			h('small', null, `${koType(type)}${note ? '*' : ''} · ${m.maxpp ? `${m.pp}/${m.maxpp}` : '-'}`, eff == null ? null : h('span', { class: `eff ${badgeFor(eff).cls}` }, badgeFor(eff).label), stabTag));
			b.style.flex = '1';
			return h('div', { style: 'position:relative;display:flex' }, b,
				h('button', {
					class: 'ib', type: 'button', 'aria-label': `${koMove(m.move)} 설명`,
					on: { click: (e: Event) => { e.stopPropagation(); sheet(close => [moveCard(m.move, `${m.pp}/${m.maxpp}`, { type, note }), h('button', { class: 'btn', type: 'button', on: { click: close } }, '닫기')], { label: '기술 정보' }); } },
				}, 'i'));
		}));
		const toggles = h('div', { class: 'toggles' },
			act.canMegaEvo ? h('button', {
				class: 'toggle' + (this.megaOn ? ' on' : ''), type: 'button', 'aria-pressed': String(this.megaOn),
				on: { click: () => { this.megaOn = !this.megaOn; this.showCommands(req); } },
			}, '메가진화') : null,
			h('button', { class: 'toggle', type: 'button', disabled: !!act.trapped, on: { click: () => this.showSwitch(req, false) } }, act.trapped ? '교체 불가' : '교체'),
			h('button', { class: 'toggle', type: 'button', on: { click: () => this.openInfo(req) } }, '정보'));
		this.cmdEl.append(h('div', { class: 'prompt' }, `${eun(name)} 무엇을 할까?`), moves, toggles);
	}

	showSwitch(req: any, forced: boolean) {
		clear(this.cmdEl);
		const reviving = forced && req.side.pokemon.some((p: any) => p.reviving);
		const list = h('div', { class: 'sw-list' }, req.side.pokemon.map((p: any, i: number) => {
			const sp = p.details.split(',')[0];
			const [hp, status] = p.condition.split(' ');
			const fnt = status === 'fnt' || hp === '0';
			const [cur, max] = hp.split('/').map(Number);
			const set = this.team.find(s => koSpecies(s.species) === koSpecies(sp));
			const off = p.active || (reviving ? !fnt : fnt);
			return h('button', {
				class: 'mon', type: 'button', disabled: off, style: off ? 'opacity:.5' : '',
				on: { click: () => this.send(`switch ${i + 1}`) },
			},
			thumb(sp),
			h('div', null,
				h('div', { class: 'nm' }, koSpecies(sp), ' ', status && status !== 'fnt' ? h('span', { class: `st ${status}` }, STATUS_KO[status] ?? status) : null),
				h('div', { class: 'sub' }, fnt ? '기절' : `HP ${cur}/${max}${p.active ? ' · 싸우는 중' : ''}`),
				set ? h('div', { class: 'sub' }, set.moves.map(koMove).join(' / ')) : null),
			h('span'));
		}));
		this.cmdEl.append(h('div', { class: 'prompt' }, reviving ? '되살릴 포켓몬을 고른다' : forced ? '다음 포켓몬을 고른다' : '교체할 포켓몬'), list);
		if (!forced) this.cmdEl.append(h('button', { class: 'btn small', type: 'button', on: { click: () => this.showCommands(req) } }, '돌아가기'));
	}

	send(choice: string) {
		this.megaOn = false;
		this.cmdWaiting(this.profile.level === 3 ? '상대가 생각하는 중… (최대 5초)' : '상대를 기다리는 중…');
		this.session.choose(choice);
	}

	openInfo(req: any) {
		const st = this.view.state;
		const me = req.side.pokemon.find((p: any) => p.active);
		const foe = st.sides.p2.active;
		let tab = 'moves';
		sheet(close => {
			const body = h('div', { style: 'display:flex;flex-direction:column;gap:10px' });
			const tabs = h('div', { class: 'tabs', role: 'tablist' });
			const draw = () => {
				clear(tabs); clear(body);
				for (const [k, t] of [['moves', '기술'], ['ability', '특성·도구'], ['boosts', '능력 변화']]) {
					tabs.appendChild(h('button', { type: 'button', role: 'tab', 'aria-selected': String(tab === k), on: { click: () => { tab = k; draw(); } } }, t));
				}
				const foeName = foe ? koSpecies(foe.species) : '-';
				const myName = me ? koSpecies(me.details.split(',')[0]) : '-';
				if (tab === 'moves') {
					body.append(h('h2', null, `내 ${myName}`));
					req.active?.[0]?.moves.forEach((m: any) => body.appendChild(moveCard(m.move, `${m.pp}/${m.maxpp}`)));
					body.append(h('h2', null, `상대 ${foeName}`, h('span', { class: 'muted' }, '지금까지 쓴 기술')));
					if (foe?.moves.length) foe.moves.forEach(m => body.appendChild(moveCard(m)));
					else body.append(h('div', { class: 'muted' }, '아직 공개된 기술이 없다'));
				} else if (tab === 'ability') {
					if (me) body.append(h('h2', null, `내 ${myName}`), h('dl', { class: 'kv' },
						h('dt', null, '특성'), h('dd', null, koAbility(me.ability ?? me.baseAbility), h('div', { class: 'muted' }, koAbilityDesc(me.ability ?? me.baseAbility))),
						h('dt', null, '도구'), h('dd', null, me.item ? koItem(me.item) : '없음', h('div', { class: 'muted' }, me.item ? koItemDesc(me.item) : ''))));
					if (foe) {
						const sp = dex.species.get(foe.species);
						const possible = [...new Set(Object.values(sp.abilities) as string[])].map(koAbility).join(' / ');
						body.append(h('h2', null, `상대 ${foeName}`), h('dl', { class: 'kv' },
							h('dt', null, '타입'), h('dd', null, ...(st.sides.p2.types ?? speciesTypes(foe.species)).map(typeTag), st.sides.p2.types ? h('div', { class: 'muted' }, `바뀐 타입 (원래 ${speciesTypes(foe.species).map(koType).join('·')})`) : null),
							h('dt', null, '특성'), h('dd', null, foe.ability ? koAbility(foe.ability) : `미공개 (가능: ${possible})`, foe.ability ? h('div', { class: 'muted' }, koAbilityDesc(foe.ability)) : null),
							h('dt', null, '도구'), h('dd', null, foe.item === undefined ? '미공개' : foe.item ? koItem(foe.item) : '없음')));
					}
				} else {
					for (const sid of ['p1', 'p2'] as const) {
						const side = st.sides[sid];
						const a = side.active;
						body.append(h('h2', null, `${sid === 'p1' ? '내' : '상대'} ${a ? koSpecies(a.species) : '-'}`, a?.status ? h('span', { class: `st ${a.status}` }, STATUS_KO[a.status]) : null));
						body.append(h('div', { class: 'boosts' }, ['atk', 'def', 'spa', 'spd', 'spe', 'accuracy', 'evasion'].map(s => {
							const v = side.boosts[s] ?? 0;
							return h('div', { class: v > 0 ? 'up' : v < 0 ? 'down' : '' }, STAT_KO[s], h('b', null, v > 0 ? `+${v}` : String(v)));
						})));
						const vols = [...side.volatiles.map(v => koMove(v)), ...side.conditions.map(c => koMove(c))];
						if (vols.length) body.append(h('div', { class: 'muted' }, '상태: ' + vols.join(', ')));
					}
					body.append(h('button', { class: 'btn small danger', type: 'button', on: { click: () => { close(); confirmSheet('기권할까?', '기권', () => this.session.forfeit()); } } }, '기권'));
				}
			};
			draw();
			return [h('div', { class: 'row', style: 'justify-content:space-between' }, h('h2', null, '배틀 정보'), h('button', { class: 'btn small', type: 'button', on: { click: close } }, '닫기')), tabs, body];
		}, { label: '배틀 정보' });
	}

	async showEnd() {
		const winner = this.view.state.winner;
		const result: 'W' | 'L' | 'T' = winner === settings.playerName ? 'W' : winner ? 'L' : 'T';
		clear(this.cmdEl);
		const rateEl = h('div', { class: 'rate-change', role: 'status' });
		this.cmdEl.append(
			h('div', { class: 'result', style: `color:${result === 'W' ? 'var(--accent)' : result === 'L' ? 'var(--bad)' : 'var(--muted)'}` }, result === 'W' ? '승리!' : result === 'L' ? '패배…' : '무승부'),
			rateEl);
		if (this.ranked && !this.recorded) {
			this.recorded = true;
			const { rec } = await recordGame({
				result, opp: { id: this.profile.id, label: this.profile.label, rating: this.profile.rating },
				myPicks: this.picks, oppTeam: this.view.state.sides.p2.team.map(m => m.species), turns: this.view.state.turn,
			});
			const before = gradeOf(rec.before), after = gradeOf(rec.after);
			rateEl.append(h('b', { class: rec.delta >= 0 ? 'up' : 'down' }, `${rec.delta >= 0 ? '+' : ''}${rec.delta}`), h('span', null, ' ', h('span', { class: 'rating-num' }, String(rec.before)), ' → ', h('span', { class: 'rating-num' }, String(rec.after))), ' ', gradeBadge(rec.after));
			if (before.name !== after.name) rateEl.append(h('div', { class: 'muted' }, rec.after > rec.before ? `${after.name}로 승급!` : `${after.name}로 강등`));
		} else if (!this.ranked) rateEl.append(h('span', { class: 'muted' }, '연습 배틀이라 레이팅이 바뀌지 않는다'));
		if (this.oppParty) this.cmdEl.append(h('div', { class: 'muted', style: 'font-size:12px' }, `상대 파티: ${this.oppParty.short} 샘플 · ${curatedLabel(this.oppParty)}`));
		this.cmdEl.append(
			h('div', { class: 'row' },
				h('button', { class: 'btn primary grow', type: 'button', on: { click: () => (this.ranked ? startLadder(this.team) : startBattle(this.team)) } }, this.ranked ? '다음 래더 배틀' : '새 상대'),
				h('button', { class: 'btn grow', type: 'button', on: { click: () => startBattle(this.team, { opp: this.oppTeam, oppParty: this.oppParty, profile: this.profile, ranked: this.ranked }) } }, '같은 상대로 다시')),
			h('button', { class: 'btn ghost', type: 'button', on: { click: nav.home } }, '홈으로'));
	}
}
