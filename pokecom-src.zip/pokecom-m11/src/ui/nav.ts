// 화면 전환 (순환 import 를 피하려고 main.ts 가 채운다)
import type { PokemonSet } from '../core/format';

export const app = document.getElementById('app')!;
export const nav = {
	home: () => {},
	teams: () => {},
	editTeam: (_id: string | null, _index?: number) => {},
	battle: (_team: PokemonSet[], _opp?: PokemonSet[]) => {},
};
