// 배틀 연출 (v1.5.0). 원칙: 짧게(0.6초 이하), 화면을 누르면 즉시 끝, 메시지 속도 '즉시'·연출 끔·OS 동작 줄이기 존중,
// 그림 파일 없이 도형·색만으로 (게임 원본 연출을 흉내 내지 않는다).
// 프로토콜 한 줄을 받아 해당 연출을 틀고, 계속 남는 표시(대타출동 인형)는 syncSubstitute 로 맞춘다.
import { h } from './dom';
import { TYPE_COLOR } from './common';
import { settings } from '../core/store';
import { dex } from '../core/format';

type Side = 'p1' | 'p2';
const STATUS_COLOR: Record<string, string> = { brn: '#ff7a2e', par: '#f2cf1d', psn: '#b05ad0', tox: '#8a2fb0', slp: '#9aa3b5', frz: '#7fe0f0' };
const WEATHER_COLOR: Record<string, string> = {
	sunnyday: '#ffb13b', desolateland: '#ff7a1a', raindance: '#3f7fe0', primordialsea: '#2a5fc0',
	sandstorm: '#c9a254', snowscape: '#e8f4ff', snow: '#e8f4ff', hail: '#e8f4ff', deltastream: '#9ad0e0',
};
const TERRAIN_COLOR: Record<string, string> = { electricterrain: '#f2cf1d', grassyterrain: '#5fae3c', mistyterrain: '#f0a8d0', psychicterrain: '#c070e0' };
const toID = (s: string) => (s ?? '').toLowerCase().replace(/[^a-z0-9]/g, '');
const sideOf = (ident: string): Side | null => (/^p1/.test(ident) ? 'p1' : /^p2/.test(ident) ? 'p2' : null);

export class BattleFx {
	private anims = new Set<Animation>();
	private temps = new Set<HTMLElement>();
	private pending: Partial<Record<Side, { crit?: boolean; eff?: number }>> = {};
	/** 사라지는 중인 대타 인형 (연출이 끝날 때까지 숨기지 않는다) */
	private leaving: Partial<Record<Side, boolean>> = {};
	private subEl: Record<Side, HTMLElement>;
	private motionQuery = typeof matchMedia === 'function' ? matchMedia('(prefers-reduced-motion: reduce)') : null;

	constructor(private inner: HTMLElement, private spr: Record<string, HTMLElement>) {
		this.subEl = { p1: this.doll('p1'), p2: this.doll('p2') };
	}

	/** 연출을 틀지 (끔·즉시 속도면 안 튼다) */
	get on() { return settings.effects !== 'off' && settings.speed !== 'instant'; }
	/** 움직임 줄이기: 이동·흔들림 없이 색만 */
	get reduced() { return settings.effects === 'reduced' || !!this.motionQuery?.matches; }
	/** 속도 설정에 맞춘 시간 배율 */
	private get k() { return ({ slow: 1.15, normal: 1, fast: 0.6, instant: 0 } as Record<string, number>)[settings.speed] ?? 1; }

	/** 진행 중인 연출을 모두 끝낸다 (화면 누름 = 건너뛰기) */
	finishAll() {
		for (const a of this.anims) { try { a.finish(); } catch { /* 이미 끝남 */ } }
		this.anims.clear();
		for (const el of this.temps) el.remove();
		this.temps.clear();
	}

	/** 프로토콜 한 줄 → 연출. view.add 전에 부른다 */
	play(line: string) {
		if (!line.startsWith('|')) return;
		const parts = line.slice(1).split('|');
		const cmd = parts[0];
		const args = parts.slice(1).filter(p => !p.startsWith('['));
		const kw = new Set(parts.slice(1).filter(p => p.startsWith('[')).map(p => p.replace(/\].*$/, ']')));
		const from = parts.find(p => p.startsWith('[from]'));
		const s = sideOf(args[0] ?? '');
		// 흔들림 세기 판단용 표시는 연출을 꺼도 기억만 해 둔다
		if (s && (cmd === '-crit' || cmd === '-supereffective' || cmd === '-resisted')) {
			const p = (this.pending[s] ??= {});
			if (cmd === '-crit') p.crit = true; else p.eff = cmd === '-supereffective' ? 2 : 0.5;
			return;
		}
		if (!this.on) { if (cmd === '-damage' && s) delete this.pending[s]; return; }
		switch (cmd) {
			case 'move': {
				const t = sideOf(args[2] ?? '');
				if (!s || kw.has('[still]')) return;
				this.moveUse(s, t && t !== s ? t : null, args[1]);
				break;
			}
			case '-damage': {
				if (!s) return;
				const p = this.pending[s]; delete this.pending[s];
				if (from) return; // 날씨·독 등 턴 끝 데미지는 흔들지 않는다
				this.hit(s, p?.eff ?? 1, !!p?.crit);
				break;
			}
			case '-boost': case '-unboost': {
				if (!s) return;
				const n = Math.max(0, Math.min(3, parseInt(args[2] ?? '1', 10) || 0));
				if (n) this.stat(s, cmd === '-boost', n);
				break;
			}
			case '-status': if (s) this.tint(s, STATUS_COLOR[args[1]] ?? '#fff'); break;
			case '-heal': if (s && !kw.has('[silent]')) this.sparkle(s, '#6fe08a'); break;
			case '-mega': if (s) this.mega(s); break;
			case '-activate': case '-singleturn': {
				const eff = toID((args[1] ?? '').replace(/^move:\s*/, ''));
				if (s && ['protect', 'detect', 'kingsshield', 'spikyshield', 'banefulbunker', 'silktrap', 'burningbulwark', 'obstruct', 'endure'].includes(eff)) this.shield(s);
				break;
			}
			case '-weather': {
				const w = toID(args[0]);
				if (w && w !== 'none' && !kw.has('[upkeep]')) this.screenTint(WEATHER_COLOR[w] ?? '#ffffff');
				break;
			}
			case '-fieldstart': {
				const f = toID((args[0] ?? '').replace(/^move:\s*/, ''));
				this.screenTint(TERRAIN_COLOR[f] ?? '#b08aff', true);
				break;
			}
			case 'switch': case 'drag': case 'replace':
				if (s) this.enter(s);
				break;
			case '-start': {
				if (s && toID((args[1] ?? '').replace(/^move:\s*/, '')) === 'substitute') this.dollIn(s);
				break;
			}
			case '-end': {
				if (s && toID((args[1] ?? '').replace(/^move:\s*/, '')) === 'substitute') this.dollOut(s);
				break;
			}
		}
	}

	// ---------------------------------------------------------------- 계속 남는 표시: 대타출동 인형
	/** 대타 상태를 화면에 맞춘다 (renderScene 에서 매번) */
	syncSubstitute(side: Side, on: boolean) {
		const d = this.subEl[side], sp = this.spr[side];
		if (!on && this.leaving[side]) return;
		d.hidden = !on;
		sp.classList.toggle('behind-sub', on);
		if (on) this.placeDoll(side);
	}
	private doll(side: Side) {
		// 천 인형(바느질 자국·단추 눈·이름표) — 특정 캐릭터가 아닌 일반 인형
		const svg = `<svg viewBox="0 0 64 72" width="100%" height="100%" aria-hidden="true">
			<ellipse cx="32" cy="68" rx="20" ry="3.5" fill="#0003"/>
			<path d="M14 64 Q10 40 18 26 Q22 12 32 10 Q42 12 46 26 Q54 40 50 64 Z" fill="#f2e3c4" stroke="#8a6a3a" stroke-width="2.5"/>
			<path d="M32 12 L32 64" stroke="#8a6a3a" stroke-width="1.5" stroke-dasharray="3 3" fill="none"/>
			<path d="M18 30 Q12 36 11 44" stroke="#8a6a3a" stroke-width="2.5" fill="none" stroke-linecap="round"/>
			<path d="M46 30 Q52 36 53 44" stroke="#8a6a3a" stroke-width="2.5" fill="none" stroke-linecap="round"/>
			<circle cx="25" cy="26" r="3.2" fill="#3a3a48"/><circle cx="39" cy="26" r="3.2" fill="#3a3a48"/>
			<circle cx="24" cy="25" r="1" fill="#fff"/><circle cx="38" cy="25" r="1" fill="#fff"/>
			<path d="M27 34 Q32 37 37 34" stroke="#8a6a3a" stroke-width="2" fill="none" stroke-linecap="round"/>
			<rect x="20" y="44" width="24" height="11" rx="3" fill="#e05a4a" stroke="#8a3a2a" stroke-width="1.5"/>
			<rect x="38" y="54" width="9" height="7" rx="1.5" fill="#c9b48a" stroke="#8a6a3a" stroke-width="1" transform="rotate(-12 42 57)"/>
		</svg>`;
		const el = h('div', { class: 'subdoll', 'aria-label': '대타출동 인형', role: 'img' }, h('b', null, '대타'));
		el.insertAdjacentHTML('afterbegin', svg);
		el.hidden = true;
		el.dataset.side = side;
		this.inner.appendChild(el);
		return el;
	}
	private placeDoll(side: Side) {
		const sp = this.spr[side], d = this.subEl[side];
		const size = side === 'p1' ? 80 : 60;
		// 내 쪽은 화면 아래 끝에 걸리지 않게 조금 올린다
		const top = (parseFloat(sp.style.top) || 0) - (side === 'p1' ? 12 : 2);
		d.style.cssText = `left:${sp.style.left};top:${top}px;width:${size}px;height:${size * 1.1}px`;
	}
	private dollIn(side: Side) {
		this.placeDoll(side);
		const d = this.subEl[side];
		d.hidden = false;
		if (!this.reduced) this.run(d, [{ translate: '0 -24px', opacity: 0 }, { translate: '0 3px', opacity: 1, offset: 0.7 }, { translate: '0 0', opacity: 1 }], 320);
	}
	private dollOut(side: Side) {
		const d = this.subEl[side];
		if (d.hidden) return;
		const a = this.run(d, [{ scale: '1', opacity: 1 }, { scale: this.reduced ? '1' : '1.25', opacity: 0 }], 260);
		if (!a) return;
		this.leaving[side] = true;
		const done = () => { this.leaving[side] = false; d.hidden = true; this.spr[side].classList.remove('behind-sub'); };
		a.finished.then(done).catch(done);
	}

	// ---------------------------------------------------------------- 연출 조각
	private run(el: Element, frames: Keyframe[], ms: number, easing = 'ease-out'): Animation | null {
		const d = Math.round(Math.min(600, ms) * this.k);
		if (!d || typeof (el as HTMLElement).animate !== 'function') return null;
		const a = (el as HTMLElement).animate(frames, { duration: d, easing });
		this.anims.add(a);
		a.finished.then(() => this.anims.delete(a)).catch(() => this.anims.delete(a));
		return a;
	}
	private temp(cls: string, style: string, parent: HTMLElement = this.inner) {
		const el = h('div', { class: `fx ${cls}`, style, 'aria-hidden': 'true' });
		parent.appendChild(el);
		this.temps.add(el);
		return el;
	}
	private drop(el: HTMLElement, a: Animation | null) {
		if (!a) { el.remove(); this.temps.delete(el); return; }
		a.finished.then(() => { el.remove(); this.temps.delete(el); }).catch(() => { el.remove(); this.temps.delete(el); });
	}
	/** 포켓몬 몸 가운데 (inner 좌표) */
	private center(side: Side) {
		const sp = this.spr[side];
		const x = parseFloat(sp.style.left) || (side === 'p1' ? 96 : 262);
		const bottom = parseFloat(sp.style.top) || (side === 'p1' ? 252 : 122);
		const hgt = sp.offsetHeight || (side === 'p1' ? 120 : 84);
		return { x, y: bottom - hgt / 2, h: hgt };
	}

	private moveUse(user: Side, target: Side | null, moveName: string) {
		const mv = dex.moves.get(moveName);
		const color = TYPE_COLOR[mv.type] ?? '#fff';
		const u = this.center(user);
		if (mv.category === 'Status' || !target) {
			// 변화 기술: 쓰는 쪽(또는 대상)에 타입 색 고리
			const at = target && mv.category === 'Status' && mv.target !== 'self' ? this.center(target) : u;
			const r = this.temp('ring', `left:${at.x}px;top:${at.y}px;border-color:${color}`);
			this.drop(r, this.run(r, [{ scale: '0.3', opacity: 0.9 }, { scale: '1.6', opacity: 0 }], 420));
			return;
		}
		const t = this.center(target);
		if (mv.category === 'Physical' && !this.reduced) {
			// 물리: 상대 쪽으로 짧게 돌진
			const dx = (t.x - u.x) * 0.16, dy = (t.y - u.y) * 0.16;
			this.run(this.spr[user], [{ translate: '0 0' }, { translate: `${dx}px ${dy}px`, offset: 0.4 }, { translate: '0 0' }], 280, 'ease-in-out');
		} else if (mv.category === 'Special') {
			// 특수: 타입 색 구슬이 날아간다
			const b = this.temp('orb', `left:${u.x}px;top:${u.y}px;background:${color};box-shadow:0 0 10px ${color}`);
			const frames = this.reduced
				? [{ opacity: 0 }, { opacity: 1, offset: 0.3 }, { opacity: 0 }]
				: [{ translate: '0 0', scale: '0.6' }, { translate: `${t.x - u.x}px ${t.y - u.y}px`, scale: '1.2' }];
			this.drop(b, this.run(b, frames, 300, 'ease-in'));
		}
	}

	private hit(side: Side, eff: number, crit: boolean) {
		const sp = this.spr[side];
		const amp = eff >= 2 ? 9 : eff < 1 ? 3 : 6;
		if (!this.reduced) this.run(sp, [0, amp, -amp, amp * 0.6, -amp * 0.4, 0].map(x => ({ translate: `${x}px 0` })), eff >= 2 ? 360 : 260, 'linear');
		this.run(sp, [{ filter: 'brightness(1)' }, { filter: `brightness(${eff >= 2 ? 2.2 : 1.7})` }, { filter: 'brightness(1)' }], 220);
		if (crit) {
			const f = this.temp('flash', 'inset:0;background:#fff');
			this.drop(f, this.run(f, [{ opacity: 0.75 }, { opacity: 0 }], 180));
		}
	}

	private stat(side: Side, up: boolean, n: number) {
		const c = this.center(side);
		const color = up ? '#4aa8ff' : '#ff5a4a';
		for (let wave = 0; wave < n; wave++) {
			for (let i = 0; i < 5; i++) {
				const x = c.x + (i - 2) * 12 + (wave % 2 ? 6 : 0);
				const y0 = up ? c.y + c.h * 0.3 : c.y - c.h * 0.35;
				const p = this.temp(up ? 'pt up' : 'pt down', `left:${x}px;top:${y0}px;background:${color}`);
				const dy = up ? -c.h * 0.55 : c.h * 0.55;
				const a = this.reduced
					? this.run(p, [{ opacity: 0 }, { opacity: 0.9 }, { opacity: 0 }], 360)
					: p.animate([{ translate: '0 0', opacity: 0 }, { opacity: 1, offset: 0.25 }, { translate: `0 ${dy}px`, opacity: 0 }],
						{ duration: Math.round(360 * this.k), delay: Math.round((wave * 110 + i * 25) * this.k), easing: 'ease-out', fill: 'backwards' });
				if (a && !this.anims.has(a)) { this.anims.add(a); a.finished.then(() => this.anims.delete(a)).catch(() => this.anims.delete(a)); }
				this.drop(p, a);
			}
		}
		// 몸에도 옅게 색을 입힌다
		this.run(this.spr[side], [{ filter: 'none' }, { filter: `drop-shadow(0 0 6px ${color})` }, { filter: 'none' }], 420);
	}

	private tint(side: Side, color: string) {
		this.run(this.spr[side], [{ filter: 'none' }, { filter: `drop-shadow(0 0 8px ${color}) saturate(1.4)` }, { filter: 'none' }], 450);
	}

	private sparkle(side: Side, color: string) {
		const c = this.center(side);
		for (let i = 0; i < 6; i++) {
			const p = this.temp('pt spark', `left:${c.x + (i - 2.5) * 11}px;top:${c.y + c.h * 0.25}px;background:${color}`);
			const a = this.reduced
				? this.run(p, [{ opacity: 0 }, { opacity: 1 }, { opacity: 0 }], 380)
				: p.animate([{ translate: '0 0', opacity: 0, scale: '0.5' }, { opacity: 1, offset: 0.3 }, { translate: `0 ${-c.h * 0.5}px`, opacity: 0, scale: '1' }],
					{ duration: Math.round(420 * this.k), delay: Math.round(i * 30 * this.k), easing: 'ease-out', fill: 'backwards' });
			if (a && !this.anims.has(a)) { this.anims.add(a); a.finished.then(() => this.anims.delete(a)).catch(() => this.anims.delete(a)); }
			this.drop(p, a);
		}
	}

	private mega(side: Side) {
		const c = this.center(side);
		const r = this.temp('ring mega', `left:${c.x}px;top:${c.y}px`);
		this.drop(r, this.run(r, [{ scale: '0.2', opacity: 1 }, { scale: '2.2', opacity: 0 }], 520));
		this.run(this.spr[side], [{ filter: 'brightness(1)' }, { filter: 'brightness(2.6) saturate(0.4)', offset: 0.45 }, { filter: 'brightness(1)' }], 520);
	}

	private shield(side: Side) {
		const c = this.center(side);
		const r = this.temp('shield', `left:${c.x}px;top:${c.y}px;width:${c.h * 1.15}px;height:${c.h * 1.15}px`);
		this.drop(r, this.run(r, [{ opacity: 0, scale: '0.85' }, { opacity: 1, scale: '1', offset: 0.35 }, { opacity: 0, scale: '1.05' }], 500));
	}

	private screenTint(color: string, ground = false) {
		const f = this.temp('flash', ground ? `left:0;right:0;top:96px;bottom:0;background:${color}` : `inset:0;background:${color}`);
		this.drop(f, this.run(f, [{ opacity: 0 }, { opacity: 0.45, offset: 0.35 }, { opacity: 0 }], 520));
	}

	private enter(side: Side) {
		if (this.reduced) { this.run(this.spr[side], [{ opacity: 0 }, { opacity: 1 }], 220); return; }
		this.run(this.spr[side], [{ scale: '0.5', opacity: 0, filter: 'brightness(3)' }, { scale: '1', opacity: 1, filter: 'brightness(1)' }], 280);
	}
}
