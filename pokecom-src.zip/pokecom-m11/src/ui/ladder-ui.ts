// 래더 화면 조각: 등급 배지, 홈 레이팅 카드, 전적 시트
import { h, clear, sheet } from './dom';
import { koSpecies } from '../core/ko';
import { loadState, loadGames, gradeOf, nextGrade, type GameRecord, type LadderState } from '../core/ladder';
import { ratingChart } from './chart';

export function gradeBadge(r: number) {
	const g = gradeOf(r);
	return h('span', { class: 'grade', style: `--g:${g.color}` }, h('i', { 'aria-hidden': 'true' }), g.name);
}

/** 홈 레이팅 카드. onLadder: 래더 배틀 시작 */
export function ladderCard(onLadder: () => void) {
	const box = h('section', { class: 'panel ladder' }, h('div', { class: 'muted' }, '레이팅 불러오는 중…'));
	const fill = (st: LadderState) => {
		clear(box);
		const nx = nextGrade(st.rating);
		const streak = st.streak > 1 ? `${st.streak}연승 중` : st.streak < -1 ? `${-st.streak}연패 중` : '';
		box.append(
			h('div', { class: 'row', style: 'justify-content:space-between;align-items:flex-end' },
				h('div', null, h('div', { class: 'eyebrow' }, '래더 레이팅'), h('div', { class: 'rating' }, String(st.rating))),
				gradeBadge(st.rating)),
			h('div', { class: 'muted' },
				`${st.wins}승 ${st.losses}패${st.ties ? ` ${st.ties}무` : ''} · 최고 ${st.peak}` + (streak ? ` · ${streak}` : '') +
				(nx ? ` · ${nx.name}까지 ${nx.min - st.rating}` : '') + (st.games < 20 ? ` · 배치 ${st.games}/20판 (변동 큼)` : '')),
			h('div', { class: 'row' },
				h('button', { class: 'btn primary grow', type: 'button', style: 'min-height:54px;font-size:17px', on: { click: onLadder } }, '래더 배틀'),
				h('button', { class: 'btn', type: 'button', style: 'min-height:54px', on: { click: openRecords } }, '전적')));
	};
	loadState().then(fill);
	return box;
}

export function openRecords() {
	sheet(close => {
		const body = h('div', { style: 'display:flex;flex-direction:column;gap:12px' }, h('div', { class: 'muted' }, '불러오는 중…'));
		Promise.all([loadState(), loadGames()]).then(([st, games]) => {
			clear(body);
			const rate = st.games ? Math.round((st.wins / st.games) * 100) : 0;
			body.append(
				h('div', { class: 'stats' },
					h('div', null, h('b', null, String(st.rating)), h('span', null, '현재')),
					h('div', null, h('b', null, String(st.peak)), h('span', null, '최고')),
					h('div', null, h('b', null, `${rate}%`), h('span', null, `${st.wins}승 ${st.losses}패`)),
					h('div', null, h('b', null, String(st.bestStreak)), h('span', null, '최다 연승'))),
				h('section', { class: 'panel', style: 'padding:10px' }, h('h2', null, '레이팅 추이', h('span', { class: 'muted' }, `${st.games}판`)), ratingChart(games)),
				h('h2', null, '최근 전적'),
				games.length ? h('ol', { class: 'games' }, [...games].reverse().slice(0, 30).map(gameRow)) : h('div', { class: 'muted' }, '아직 래더 전적이 없다'));
		});
		return [h('div', { class: 'row', style: 'justify-content:space-between' }, h('h2', null, '전적'), h('button', { class: 'btn small', type: 'button', on: { click: close } }, '닫기')), body];
	}, { label: '전적' });
}

function gameRow(g: GameRecord) {
	const d = new Date(g.at);
	const when = `${d.getMonth() + 1}/${d.getDate()} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
	return h('li', { class: `g ${g.result}` },
		h('span', { class: 'res' }, g.result === 'W' ? '승' : g.result === 'L' ? '패' : '무'),
		h('div', null,
			h('div', null, `${g.opp.label} `, h('span', { class: 'muted' }, `R${g.opp.rating}`)),
			h('div', { class: 'muted' }, `${g.myPicks.map(koSpecies).join('·')} vs ${g.oppTeam.map(koSpecies).join('·')}`)),
		h('div', { class: 'delta' }, h('b', { class: g.delta >= 0 ? 'up' : 'down' }, `${g.delta >= 0 ? '+' : ''}${g.delta}`), h('span', { class: 'muted' }, `${g.after} · ${when}`)));
}
