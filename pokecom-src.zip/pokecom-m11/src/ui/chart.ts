// 레이팅 추이 (단일 계열 선 그래프, SVG). 누르거나 올리면 해당 판 정보.
import type { GameRecord } from '../core/ladder';
import { START_RATING, GRADES } from '../core/ladder';

const NS = 'http://www.w3.org/2000/svg';
function el(tag: string, attrs: Record<string, string | number>) {
	const e = document.createElementNS(NS, tag);
	for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v));
	return e;
}

export function ratingChart(games: GameRecord[]): HTMLElement {
	const wrap = document.createElement('div');
	wrap.className = 'chart';
	if (!games.length) { wrap.innerHTML = '<div class="muted" style="padding:24px 0;text-align:center">래더를 한 판 두면 여기에 추이가 그려진다</div>'; return wrap; }
	const pts = [START_RATING, ...games.map(g => g.after)];
	const W = 340, H = 170, L = 38, R = 10, T = 10, B = 22;
	let lo = Math.min(...pts), hi = Math.max(...pts);
	const pad = Math.max(20, (hi - lo) * 0.15);
	lo = Math.floor((lo - pad) / 50) * 50; hi = Math.ceil((hi + pad) / 50) * 50;
	const x = (i: number) => L + (pts.length === 1 ? 0 : (i / (pts.length - 1)) * (W - L - R));
	const y = (v: number) => T + (1 - (v - lo) / (hi - lo)) * (H - T - B);
	const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%', role: 'img', 'aria-label': `레이팅 추이: 시작 ${START_RATING}, 현재 ${pts[pts.length - 1]}, ${games.length}판` });
	const step = hi - lo > 400 ? 100 : 50;
	for (let v = lo; v <= hi; v += step) {
		svg.append(el('line', { x1: L, x2: W - R, y1: y(v), y2: y(v), class: 'grid' }));
		const t = el('text', { x: L - 6, y: y(v) + 4, 'text-anchor': 'end', class: 'tick' }); t.textContent = String(v); svg.append(t);
	}
	for (const g of GRADES) if (g.min > lo && g.min < hi) {
		svg.append(el('line', { x1: L, x2: W - R, y1: y(g.min), y2: y(g.min), class: 'gradeline' }));
		const t = el('text', { x: W - R, y: y(g.min) - 3, 'text-anchor': 'end', class: 'gradelabel' }); t.textContent = g.name; svg.append(t);
	}
	const t0 = el('text', { x: L, y: H - 6, class: 'tick' }); t0.textContent = '0'; svg.append(t0);
	const t1 = el('text', { x: W - R, y: H - 6, 'text-anchor': 'end', class: 'tick' }); t1.textContent = `${games.length}판`; svg.append(t1);
	const d = pts.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
	svg.append(el('path', { d: `${d} L${x(pts.length - 1)},${H - B} L${x(0)},${H - B} Z`, class: 'area' }));
	svg.append(el('path', { d, class: 'line' }));
	svg.append(el('circle', { cx: x(pts.length - 1), cy: y(pts[pts.length - 1]), r: 4.5, class: 'end' }));
	const cross = el('line', { y1: T, y2: H - B, class: 'cross', visibility: 'hidden' });
	const dot = el('circle', { r: 4, class: 'hoverdot', visibility: 'hidden' });
	svg.append(cross, dot);
	const tip = document.createElement('div'); tip.className = 'tip'; tip.hidden = true;
	const hit = el('rect', { x: L, y: 0, width: W - L - R, height: H, fill: 'transparent' });
	const show = (clientX: number) => {
		const r = svg.getBoundingClientRect();
		const sx = ((clientX - r.left) / r.width) * W;
		const i = Math.max(0, Math.min(pts.length - 1, Math.round(((sx - L) / (W - L - R)) * (pts.length - 1))));
		cross.setAttribute('x1', String(x(i))); cross.setAttribute('x2', String(x(i))); cross.setAttribute('visibility', 'visible');
		dot.setAttribute('cx', String(x(i))); dot.setAttribute('cy', String(y(pts[i]))); dot.setAttribute('visibility', 'visible');
		const g = games[i - 1];
		tip.textContent = g ? `${i}판째 · ${g.result === 'W' ? '승' : g.result === 'L' ? '패' : '무'} ${g.delta >= 0 ? '+' : ''}${g.delta} → ${g.after} · ${g.opp.label}` : `시작 ${START_RATING}`;
		tip.hidden = false;
	};
	hit.addEventListener('pointermove', e => show((e as PointerEvent).clientX));
	hit.addEventListener('pointerdown', e => show((e as PointerEvent).clientX));
	hit.addEventListener('pointerleave', () => { cross.setAttribute('visibility', 'hidden'); dot.setAttribute('visibility', 'hidden'); tip.hidden = true; });
	svg.append(hit);
	wrap.append(tip, svg);
	return wrap;
}
