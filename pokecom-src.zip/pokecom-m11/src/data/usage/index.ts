// 사용률 통계 파일 모음 (data-usage 조각). scripts/gen-usage.mjs 가 만든 json 을 여기 추가한다
import u0 from './gen9championsbssregmb-2026-08-1630.json';
export const USAGE_FILES: unknown[] = [u0];
