// 사람이 만든 샘플 파티 파일 모음 (data-samples 조각). 새 출처 = json 파일 추가 + 여기 한 줄
import gubaksa from './gubaksa.json';
import game8 from './game8.json';
import altema from './altema.json';
import note from './note.json';
export const CURATED_FILES = [gubaksa, game8, altema, note];
