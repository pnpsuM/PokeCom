# PokeCom 모듈 구조와 업데이트 방법

바꾸고 싶은 것 → 고칠 곳 → 다시 해야 할 일 → 다시 올릴 파일 순서로 정리했다.

## 1. 설정 층 `src/config/` — 정책과 정의만 (로직 없음)

| 파일 | 담는 것 | 고친 뒤 할 일 |
|---|---|---|
| `version.ts` | 앱 버전, 변경 기록(설정 화면 "버전 정보") | `npm run release` |
| `manifest.ts` | 이 버전이 불러올 것: 대전 룰 key, 시뮬레이터 커밋, 데이터 파일(한국어·스프라이트 번호표·AI 레이팅), 외부 주소, 저장소 이름 | 데이터 파일을 바꿨으면 해당 조각만 새로 올라간다 |
| `rules.ts` | 대전 룰: 선출 수, 레벨, SP 제한, Showdown 커스텀 룰(`customRules`) | AI 레이팅이 룰에 따라 달라지므로 `ai:calibrate` 권장 |
| `sim-formats.ts` | 시뮬레이터에 구워 넣는 **기본** 포맷 | `npm run build:sim` (시뮬레이터 3.7MB 다시 올림) |
| `rating.ts` | 레이팅 정책: 시작값, 최저값, K(배치/일반), 매칭 범위, 무승부 점수, 등급 경계, 연습 상대 | 없음. 다음 판부터 적용 |
| `ai.ts` | AI 단계(프로필)와 상황 점수 가중치 | `npm run ai:calibrate` → `npm run ai:fit` (레이팅 재측정) |

세부 룰은 `rules.ts` 의 `customRules` 로 조정하면 시뮬레이터를 다시 묶지 않아도 된다 (예: `'Sleep Clause Mod'`, `'!Species Clause'`).

## 2. 엔진 층 `src/core/` — 규칙을 실행하는 코드

- `format.ts` — manifest 의 룰로 실행용 `FORMAT` 을 만든다
- `session.ts`, `view.ts`, `arena.ts` — 배틀 진행, 화면 상태·한국어 로그, AI 끼리 대전
- `teams.ts` — 파티 생성·샘플 세트·합법성 검사
- `ladder.ts` — Elo 계산·매칭·기록 저장 (숫자는 `config/rating.ts`)
- `ai/` — AI 판단 파이프라인: `belief`(가능한 상황) → `world`(근사 진행) / `simsearch`(시뮬레이터 탐색) → `evaluate`(점수) → `agent`(선택). 규칙 계산은 `mech`(시뮬레이터에 직접 물음)

## 3. 화면 층 `src/ui/` — 홈, 파티 짜기, 배틀, 래더, 설정

## 4. 데이터 `src/data/` — 스크립트가 만드는 파일

- `ko.json`, `sprites.json` — `npm run gen:data`
- `ratings/<룰 key>.json` — `npm run ai:fit -- --out src/data/ratings/<룰 key>.json …`
- `vendor/ps-sim.js` — `PS_DIR=<pokemon-showdown 소스> npm run build:sim` (커밋은 `vendor/PS_COMMIT`, manifest 와 같아야 함)

## 5. 빌드 조각 — 바뀐 조각만 새 이름이 된다

| 조각 파일 | 내용 | 바뀌는 때 |
|---|---|---|
| `sim-*.js` (3.7MB) | 시뮬레이터 | `build:sim` 했을 때만 |
| `data-ko-*.js` (140KB) | 한국어 | `gen:data` |
| `data-sprites-*.js` | 스프라이트 번호표 | `gen:data` |
| `data-ratings-*.js` | AI 레이팅 | `ai:fit` |
| `config-*.js` | 정책·룰·버전 | `src/config/*` 수정 |
| `ai-*.js` | AI 판단 | `src/core/ai/*` 수정 (또는 config 수정) |
| `index-*.js`, `index.html`, `sw.js` | 앱 화면·로직, 진입점 | 거의 매번 |

정책 숫자만 바꾸면 올릴 파일은 `config`·`ai`·`index`·`index.html`·`sw.js` (합계 약 200KB) 뿐이다.

## 6. 릴리스 순서

1. `src/config/version.ts` 의 `APP_VERSION` 과 `CHANGELOG` 수정
2. `npm run release` → `releases/v<버전>/`
   - `full/` 전체본, `upload/` **지난 배포와 달라진 파일만**, `CHANGES.md` 목록, 소스 zip
   - 비교 기준은 `releases/DEPLOYED` 에 적힌 버전 (`--base <폴더>` 로 직접 지정, `--full` 로 전체)
3. `upload/` 안의 파일을 GitHub 저장소 루트에 업로드
4. `npm run mark-deployed` → 다음 릴리스의 비교 기준이 됨

PC 보관: `다운로드\pokecom-pages\v<버전>\`(전체본), `다운로드\pokecom-pages\v<버전>-upload\`(올릴 파일), `다운로드\pokecom-src\v<버전>\`(소스).
새 세션에서 이어 할 때 지난 전체본을 `releases/v<버전>/full` 에 넣으면 차이 비교가 된다.

## 7. 빌드 주의
- `vite.config.ts` 의 `minify: false` 유지 — 다시 압축하면 클래스 이름이 사라져 L3 탐색(State)이 깨진다
- `scripts/build-sim.mjs` 의 `keepNames: true` 유지 (같은 이유)
