import { defineConfig, type Plugin } from 'vite';
import fs from 'node:fs';
import path from 'node:path';

// 빌드 결과물 목록으로 sw.js 를 만든다 (오프라인 프리캐시)
function serviceWorker(): Plugin {
	return {
		name: 'pokecom-sw',
		apply: 'build',
		writeBundle(opts, bundle) {
			const out = opts.dir!;
			const files = ['./', 'index.html', 'manifest.webmanifest', 'icon.svg', 'icon-192.png', 'icon-180.png',
				...Object.keys(bundle).filter(f => !f.endsWith('.map'))];
			// 캐시 버전 = 파일 목록(해시 포함)에서 만든 값: 아무것도 안 바뀌면 sw.js 도 그대로
			const version = hash(JSON.stringify([...new Set(files)].sort()));
			const tpl = fs.readFileSync(path.resolve('scripts/sw.template.js'), 'utf8');
			fs.writeFileSync(path.join(out, 'sw.js'), tpl.replace('__VERSION__', version).replace('__FILES__', JSON.stringify([...new Set(files)])));
		},
	};
}
function hash(s: string) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); }

// 조각 나누기: 자주 안 바뀌는 큰 덩어리를 따로 떼어, 앱 코드만 고쳐도 그 파일들은 이름(해시)이 그대로 남게 한다
//  sim      — vendor/ps-sim.js (시뮬레이터, 3MB)     : build:sim 할 때만 바뀜
//  data-ko  — 한국어 데이터                            : gen:data 할 때만
//  data-*   — 스프라이트 번호표, AI 레이팅, 샘플 파티      : 해당 파일 바꿀 때만
//  config   — src/config/* (정책·룰·버전)               : 정책 숫자 바꿀 때
//  ai       — src/core/ai/* (AI 판단)
//  index    — 나머지 앱 코드·화면
const CHUNKS = [
	{ name: 'sim', test: /[\\/]vendor[\\/]ps-sim/, priority: 60 },
	{ name: 'data-ko', test: /[\\/]data[\\/]ko\.json/, priority: 50 },
	{ name: 'data-sprites', test: /[\\/]data[\\/]sprites\.json/, priority: 50 },
	{ name: 'data-ratings', test: /[\\/]data[\\/]ratings[\\/]/, priority: 50 },
	{ name: 'data-samples', test: /[\\/]data[\\/]samples[\\/]/, priority: 50 },
	{ name: 'config', test: /[\\/]src[\\/]config[\\/]/, priority: 40 },
	{ name: 'ai', test: /[\\/]src[\\/]core[\\/]ai[\\/]/, priority: 30 },
];

export default defineConfig({
	base: './',
	build: {
		target: 'es2022', chunkSizeWarningLimit: 6000, assetsInlineLimit: 0, assetsDir: '',
		// 압축 끔: 시뮬레이터 번들은 이미 압축돼 있고, 다시 압축하면 클래스 이름이 사라져 State(L3 탐색)가 깨진다
		minify: false,
		rolldownOptions: { output: { advancedChunks: { groups: CHUNKS } } },
	},
	plugins: [serviceWorker()],
});
