// 승패 행렬들 → Bradley-Terry → Elo (L0=800). 사용: tsx fit.ts a.json b.json …
import fs from 'node:fs';
const res: Record<string, [number, number]> = {};
const args = process.argv.slice(2);
const oi = args.indexOf('--out');
const OUT = oi >= 0 ? args.splice(oi, 2)[1] : 'src/data/ratings/champions-bss-regmc.json';
for (const f of args) Object.assign(res, JSON.parse(fs.readFileSync(f, 'utf8')));
const ids = [...new Set(Object.keys(res).flatMap((k) => k.split('|')))];
const W: Record<string, Record<string, number>> = {}; for (const a of ids) { W[a] = {}; for (const b of ids) W[a][b] = 0; }
for (const [k, [wa, wb]] of Object.entries(res)) { const [a, b] = k.split('|'); W[a][b] += wa; W[b][a] += wb; }
let g: Record<string, number> = Object.fromEntries(ids.map((i) => [i, 1]));
for (let it = 0; it < 5000; it++) {
  const ng: Record<string, number> = {};
  for (const i of ids) {
    const wins = ids.reduce((s, j) => s + W[i][j], 0) + 0.5; // 약한 사전분포 (완승 발산 방지)
    let den = 1 / (g[i] + 1);
    for (const j of ids) if (j !== i) { const n = W[i][j] + W[j][i]; if (n) den += n / (g[i] + g[j]); }
    ng[i] = wins / den;
  }
  const s = ng.L0 ?? 1; g = Object.fromEntries(ids.map((i) => [i, ng[i] / s]));
}
const profiles = ids.map((id) => ({ id, rating: Math.round(800 + 400 * Math.log10(g[id])), games: ids.reduce((s, j) => s + W[id][j] + W[j][id], 0) })).sort((a, b) => a.rating - b.rating);
console.table(profiles);
console.log('→', OUT);
fs.writeFileSync(OUT, JSON.stringify({ measuredAt: new Date().toISOString().slice(0, 10), method: 'AI 자가 대전, Bradley-Terry, L0=800', pairs: res, profiles }, null, 1));
