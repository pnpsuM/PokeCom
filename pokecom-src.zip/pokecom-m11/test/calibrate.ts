// AI 프로필끼리 대전 → 승패 저장. node .tmp/calibrate.mjs <out.json> <쌍 수> <all:id,id,… | A:B,A:B>
import fs from 'node:fs';
import { runArena } from '../src/core/arena';
import { FORMAT } from '../src/core/format';
import { RandomTeamSource } from '../src/core/teams';
import { makeAgent, PROFILES } from '../src/core/ai/agent';
const [out, nStr, spec] = process.argv.slice(2);
const N = +nStr;
let pairs: string[][] = [];
if (spec.startsWith('all:')) { const ids = spec.slice(4).split(','); for (let i = 0; i < ids.length; i++) for (let j = i + 1; j < ids.length; j++) pairs.push([ids[i], ids[j]]); }
else pairs = spec.split(',').map(x => x.split(':'));
const mk = (id: string) => makeAgent(PROFILES.find(p => p.id === id)!);
const res: Record<string, [number, number]> = {};
const t0 = Date.now();
for (const [a, b] of pairs) {
	const A = mk(a), B = mk(b); let wa = 0, wb = 0;
	for (let k = 0; k < N; k++) {
		const ta = RandomTeamSource.generate(), tb = RandomTeamSource.generate();
		for (const swap of [false, true]) {
			const r = swap ? await runArena(FORMAT, { name: 'B', team: ta, agent: B }, { name: 'A', team: tb, agent: A })
				: await runArena(FORMAT, { name: 'A', team: ta, agent: A }, { name: 'B', team: tb, agent: B });
			if (!r.winner) { wa += 0.5; wb += 0.5; continue; }
			if ((swap ? r.winner === 'p2' : r.winner === 'p1')) wa++; else wb++;
		}
	}
	res[`${a}|${b}`] = [wa, wb];
	fs.writeFileSync(out, JSON.stringify(res));
	console.log(`${a} vs ${b}: ${wa}-${wb} (${((Date.now() - t0) / 1000).toFixed(0)}s)`);
}
