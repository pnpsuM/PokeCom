// 특성·기술 효과로 바뀌는 기술 타입 확인
import { Battle, Teams } from '../src/sim';
import { FORMAT, dex } from '../src/core/format';
import { resolveMoveType } from '../src/core/movetype';
import { Mech } from '../src/core/ai/mech';
const mk = (species: string, ability: string, moves: string[], item = '') => ({ name: '', species, item, ability, nature: 'Modest', evs: { hp: 32, atk: 0, def: 0, spa: 32, spd: 0, spe: 2 }, ivs: { hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31 }, moves, level: 50, gender: '' });
const cands = [
	mk('Sylveon', 'Pixilate', ['Hyper Voice', 'Quick Attack', 'Protect', 'Weather Ball']),
	mk('Altaria', 'Natural Cure', ['Hyper Voice', 'Double-Edge', 'Roost', 'Dragon Pulse'], 'Altarianite'),
	mk('Primarina', 'Liquid Voice', ['Hyper Voice', 'Moonblast', 'Surf', 'Protect']),
].filter(s => dex.species.get(s.species).exists && !dex.species.get(s.species).isNonstandard);
console.log('로스터에 있는 테스트 종:', cands.map(s => s.species).join(', '));
const foe = mk('Garchomp', 'Rough Skin', ['Earthquake']);
for (const me of cands) {
	const b: any = new Battle({ formatid: FORMAT.id });
	b.setPlayer('p1', { name: 'A', team: Teams.pack([me, me, me].map((s, i) => ({ ...s, species: i ? 'Pikachu' : s.species, item: i ? '' : s.item }))) });
	b.setPlayer('p2', { name: 'B', team: Teams.pack([foe, foe, foe].map((s, i) => ({ ...s, species: i ? 'Pikachu' : s.species }))) });
	b.choose('p1', 'team 123'); b.choose('p2', 'team 123');
	const p = b.p1.active[0];
	const mega = p.canMegaEvo ? dex.species.get(p.canMegaEvo).abilities['0'] : undefined;
	for (const s of p.moveSlots) {
		const r = resolveMoveType(b, p, b.p2.active[0], s.id);
		const rm = mega ? resolveMoveType(b, p, b.p2.active[0], s.id, mega) : null;
		console.log(me.species, s.move, `${r.baseType} → ${r.type}`, r.cause, r.abilityId ?? '', rm ? `| 메가(${mega}) → ${rm.type}` : '');
	}
	console.log('로그 오염 없음:', !b.log.some((l: string) => /ModifyType/.test(l)));
}
// AI 데미지 계산에도 반영되는지
const m = new Mech([[{ key: 'm0', set: cands[0] as any }], [{ key: 'o0', set: foe as any }]]);
const st = (key: string, species: string) => ({ key, species, hp: 100, status: '', boosts: {} });
const f = { weather: '', terrain: '', screens: [{}, {}] as any };
console.log('님피아 하이퍼보이스 → 한카리아스 (페어리스킨, 효과 굉장):', m.damage(st('m0', 'Sylveon'), st('o0', 'Garchomp'), 0, 'Hyper Voice', f));
