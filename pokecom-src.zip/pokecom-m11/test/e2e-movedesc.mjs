// v1.5.0: 기술 고르기 설명 펼치기, 파티 편집 한 줄 밀어 보기, 샘플 세트(구박사)
import { chromium, devices } from '/home/claude/pokecom/node_modules/playwright/index.mjs';
const SHOT = process.env.SHOT || '/tmp/claude-shots';
const browser = await chromium.launch();
const ctx = await browser.newContext({ ...devices['iPhone SE'] });
await ctx.route(/raw\.githubusercontent\.com|fonts\./, (r) => r.abort());
await ctx.addInitScript(() => localStorage.setItem('pokecom-settings', JSON.stringify({ spriteConsent: 'no', speed: 'fast' })));
const page = await ctx.newPage();
const errors = []; page.on('pageerror', (e) => errors.push(e.message));
await page.goto(process.env.URL);
await page.getByRole('button', { name: /파티 짜기/ }).click();
await page.getByRole('button', { name: /새 파티/ }).click();
await page.getByRole('button', { name: '구박사 파티 불러오기' }).click();
await page.getByRole('button', { name: '이 파티 쓰기' }).nth(4).click();
await page.getByRole('button', { name: '바꾸기' }).click();
await page.waitForTimeout(300);
const rows = await page.locator('.mon .sub.hs').evaluateAll(els => els.map(e => [e.textContent, e.scrollWidth > e.clientWidth, e.classList.contains('ovf')]));
console.log('파티 줄:', JSON.stringify(rows.filter(r => r[1]).slice(0, 3)));
// 첫 칸 스크롤해 보기
const first = page.locator('.mon .sub.hs.ovf').first();
if (await first.count()) { await first.evaluate(e => (e.scrollLeft = 999)); await page.waitForTimeout(100); console.log('끝까지 밀면 end:', await first.evaluate(e => e.classList.contains('end'))); }
await page.locator('.mon').first().click();
await page.waitForTimeout(300);
const samples = await page.locator('.sample b').allTextContents();
console.log('샘플 세트 라벨:', samples.slice(0, 3));
await page.locator('.moveslot').first().click();
await page.waitForTimeout(400);
const d = page.locator('.movedesc.xp').first();
const before = await d.evaluate(e => e.getBoundingClientRect().height);
await d.click();
const after = await d.evaluate(e => e.getBoundingClientRect().height);
console.log('설명 높이 접힘→펼침:', before, after, '시트 열림 유지:', await page.locator('.overlay.full').count());
await page.screenshot({ path: `${SHOT}/movedesc.png` });
console.log('errors', errors);
await browser.close();
