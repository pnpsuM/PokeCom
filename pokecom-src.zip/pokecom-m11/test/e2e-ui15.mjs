// v1.5.0 화면 점검: 구박사 파티 불러오기, 포켓몬·기술·도구 고르기 화면의 긴 글자
import { chromium, devices } from '/home/claude/pokecom/node_modules/playwright/index.mjs';
const SHOT = process.env.SHOT || '/tmp/claude-shots';
const browser = await chromium.launch();
const ctx = await browser.newContext({ ...devices['iPhone SE'] });
await ctx.route(/raw\.githubusercontent\.com|fonts\./, (r) => r.abort());
await ctx.addInitScript(() => localStorage.setItem('pokecom-settings', JSON.stringify({ spriteConsent: 'no', speed: 'fast' })));
const page = await ctx.newPage();
const errors = []; page.on('pageerror', (e) => errors.push(e.message));
await page.goto(process.env.URL);
await page.getByRole('button', { name: /파티 짜기/ }).click();
await page.getByRole('button', { name: /새 파티/ }).click();
await page.getByRole('button', { name: '구박사 파티 불러오기' }).click();
await page.waitForTimeout(400);
await page.screenshot({ path: `${SHOT}/curated.png` });
await page.getByRole('button', { name: '이 파티 쓰기' }).nth(3).click();
await page.getByRole('button', { name: '바꾸기' }).click();
await page.waitForTimeout(300);
await page.screenshot({ path: `${SHOT}/team-curated.png`, fullPage: true });
// 첫 포켓몬 편집 → 샘플, 기술 고르기
await page.locator('.slots button, .slot-btn, .teamslot').first().click().catch(() => {});
await page.waitForTimeout(400);
await page.screenshot({ path: `${SHOT}/edit.png`, fullPage: true });
if (process.env.MORE) {
  await page.locator('.moveslot, .mvslot, button:has-text("기술 1")').first().click().catch(() => {});
}
console.log('errors', errors);
await browser.close();
