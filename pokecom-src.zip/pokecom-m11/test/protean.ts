// 변환자재·리베로: 기술 타입 미리 보기, 실제 시뮬레이터와 일치, 화면 상태, AI 데미지 반영
import { Battle, Teams } from '../src/sim';
import { FORMAT, dex } from '../src/core/format';
import { resolveMoveType } from '../src/core/movetype';
import { Mech } from '../src/core/ai/mech';
import { BattleView } from '../src/core/view';
const mk = (species: string, ability: string, moves: string[], item = '') => ({ name: '', species, item, ability, nature: 'Timid', evs: { hp: 2, atk: 0, def: 0, spa: 32, spd: 0, spe: 32 }, ivs: { hp: 31, atk: 31, def: 31, spa: 31, spd: 31, spe: 31 }, moves, level: 50, gender: '' });
const gren = mk('Greninja', 'Protean', ['Dark Pulse', 'Ice Beam', 'Protect', 'Surf']);
const grenM = mk('Greninja', 'Torrent', ['Dark Pulse', 'Ice Beam', 'Protect', 'Surf'], 'Greninjite');
const foe = mk('Garchomp', 'Rough Skin', ['Earthquake', 'Protect', 'Swords Dance', 'Scale Shot']);
let fail = 0; const ok = (c: boolean, msg: string) => { console.log(c ? '✓' : '✗', msg); if (!c) fail++; };
for (const me of [gren, grenM]) {
	if (!dex.items.get(me.item || 'x').exists && me.item) { console.log('도구 없음', me.item); continue; }
	const b: any = new Battle({ formatid: FORMAT.id });
	const view = new BattleView('나', '상대');
	b.setPlayer('p1', { name: 'A', team: Teams.pack([me, mk('Pikachu', 'Static', ['Thunderbolt']), mk('Pikachu', 'Static', ['Thunderbolt'])]) });
	b.setPlayer('p2', { name: 'B', team: Teams.pack([foe, mk('Pikachu', 'Static', ['Thunderbolt']), mk('Pikachu', 'Static', ['Thunderbolt'])]) });
	b.choose('p1', 'team 123'); b.choose('p2', 'team 123');
	const p = b.p1.active[0];
	const mega = p.canMegaEvo ? dex.species.get(p.canMegaEvo).abilities['0'] : undefined;
	const pre = p.moveSlots.map((s: any) => resolveMoveType(b, p, b.p2.active[0], s.id, mega));
	console.log(me.item || '특성 변환자재', pre.map((x: any) => `${x.id}:${x.becomes ? x.becomes.type + (x.becomes.stab ? '+자속' : '') : '-'}`).join(' '));
	ok(pre[0].becomes?.type === 'Dark' && !pre[0].becomes.stab, '악의파동 → 악 단일 타입 (자속은 원래 있음)');
	ok(pre[1].becomes?.type === 'Ice' && pre[1].becomes.stab, '냉동빔 → 얼음 타입, 자속 새로 받음');
	ok(pre[2].becomes?.type === 'Normal' && !pre[2].becomes.stab, '방어 → 노말 타입 (변화 기술)');
	ok(pre[3].becomes?.type === 'Water' && !pre[3].becomes.stab, '파도타기 → 물 단일 타입');
	b.choose('p1', `move 1${mega ? ' mega' : ''}`); b.choose('p2', 'move 3');
	for (const l of b.log) for (const line of l.split('\n')) view.add(line);
	ok(p.getTypes().join() === 'Dark', `실제 시뮬레이터 타입 = ${p.getTypes().join()}`);
	ok(view.state.sides.p1.types?.join() === 'Dark' && view.state.sides.p1.proteanUsed, '화면 상태: 악 타입, 변환자재 사용함');
	const after = p.moveSlots.map((s: any) => resolveMoveType(b, p, b.p2.active[0], s.id));
	ok(after.every((x: any) => !x.becomes), '한 번 쓴 뒤에는 미리 보기 없음');
	console.log(view.state.log.filter(e => /타입이 되었다/.test(e.text)).map(e => e.text).join(' / '));
}
// AI 데미지: 변환자재 미사용이면 자속 보정
const m = new Mech([[{ key: 'm0', set: gren as any }], [{ key: 'o0', set: foe as any }]]);
const f = { weather: '', terrain: '', screens: [{}, {}] as any };
const base = { key: 'm0', species: 'Greninja', hp: 100, status: '', boosts: {}, ability: 'protean' };
const d0 = m.damage({ ...base, shiftUsed: false }, { key: 'o0', species: 'Garchomp', hp: 100, status: '', boosts: {} }, 0, 'icebeam', f);
const d1 = m.damage({ ...base, shiftUsed: true }, { key: 'o0', species: 'Garchomp', hp: 100, status: '', boosts: {} }, 0, 'icebeam', f);
const d2 = m.damage({ ...base, shiftUsed: true, types: ['Ice'] }, { key: 'o0', species: 'Garchomp', hp: 100, status: '', boosts: {} }, 0, 'icebeam', f);
console.log('냉동빔 → 한카리아스 %:', d0.avg.toFixed(1), d1.avg.toFixed(1), d2.avg.toFixed(1));
ok(Math.abs(d0.avg / d1.avg - 1.5) < 0.08, '미사용 변환자재 = 자속 1.5배');
ok(Math.abs(d2.avg - d0.avg) < 1, '이미 얼음 타입이면 같은 데미지');
// 상대 타입이 바뀌면 방어 상성도 바뀜
const d3 = m.damage({ key: 'o0', species: 'Garchomp', hp: 100, status: '', boosts: {} }, { ...base, shiftUsed: true, types: ['Fire'] }, 1, 'earthquake', f);
const d4 = m.damage({ key: 'o0', species: 'Garchomp', hp: 100, status: '', boosts: {} }, { ...base, shiftUsed: true }, 1, 'earthquake', f);
console.log('지진 → 개굴닌자(불꽃으로 바뀜) / (물·악) %:', d3.avg.toFixed(1), d4.avg.toFixed(1));
ok(d3.avg > d4.avg, '방어 쪽 바뀐 타입도 반영');
console.log(fail ? `실패 ${fail}` : '모두 통과'); process.exit(fail ? 1 : 0);
