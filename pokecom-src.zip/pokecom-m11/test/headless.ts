import { RandomTeamSource, sampleSets, validateTeam, optimizeSpread } from '../src/core/teams';
import { BattleSession } from '../src/core/session';
import { RandomAgent } from '../src/core/agents';
import { BattleView } from '../src/core/view';
import { FORMAT, dex, isPickable } from '../src/core/format';
import { koSpecies } from '../src/core/ko';

const N = +(process.env.N || 30);
const t0 = Date.now();
const team = RandomTeamSource.generate();
console.log(team.map(s => `${koSpecies(s.species)} @ ${s.item} ${s.nature} ${JSON.stringify(s.evs)} ${s.moves.join('/')}`).join('\n'));
console.log('pickable', dex.species.all().filter(isPickable).length);
for (const sp of ['Garchomp', 'Charizard', 'Baxcalibur', 'Kingambit', 'Incineroar']) {
  const ss = sampleSets(sp);
  console.log(sp, ss.map(x => `${x.role}: ${x.set.species}@${x.set.item} ${x.set.moves.join('/')}`));
}
let errors = 0, done = 0, turns = 0, unknown = new Map<string, number>();
async function one(i: number) {
  return new Promise<void>((resolve) => {
    const view = new BattleView('나', '컴퓨터');
    const p1 = { ...RandomAgent };
    const s = new BattleSession({ format: FORMAT, p1: { name: '나', team: RandomTeamSource.generate() }, p2: { name: '컴퓨터', team: RandomTeamSource.generate(), agent: RandomAgent } }, {
      onLine: (l) => { view.add(l); },
      onRequest: async (req) => { s.choose(await p1.choose(req, { format: FORMAT, log: [], rng: Math.random })); },
      onEnd: () => { done++; turns += view.state.turn; for (const e of view.state.log) if (e.kind === 'info' && e.text.startsWith('(')) { const k = e.text.split(' ')[0]; unknown.set(k, (unknown.get(k) || 0) + 1); } resolve(); },
      onError: (m) => { errors++; console.log('ERR', m); },
    });
    setTimeout(() => { if (!s.ended) { console.log('timeout', i); resolve(); } }, 20000);
  });
}
for (let i = 0; i < N; i++) await one(i);
console.log({ done, errors, avgTurns: (turns / done).toFixed(1), ms: Date.now() - t0 });
console.log('unhandled protocol:', [...unknown].slice(0, 30));
