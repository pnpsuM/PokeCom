import { chromium, devices } from '/home/claude/pokecom/node_modules/playwright/index.mjs';
const browser = await chromium.launch();
const ctx = await browser.newContext({ ...devices['iPhone 13'] });
await ctx.route(/raw\.githubusercontent\.com|fonts\./, (r) => r.abort());
await ctx.addInitScript(() => localStorage.setItem('pokecom-settings', JSON.stringify({ spriteConsent: 'no', speed: 'instant' })));
const page = await ctx.newPage();
const errors = []; page.on('pageerror', (e) => errors.push(e.message));
await page.goto(process.env.URL);
await page.waitForTimeout(500);
await page.screenshot({ path: '/tmp/claude-shots/f-home.png', clip: { x: 0, y: 0, width: 390, height: 330 } });
let shot = false;
for (let g = 0; g < 8 && !shot; g++) {
  await page.getByRole('button', { name: g ? '새 상대' : /연습 배틀/ }).click();
  await page.getByText(/선출할/).waitFor();
  const mons = page.locator('.mons .mon'); await mons.nth(0).click(); await mons.nth(1).click(); await mons.nth(2).click();
  await page.getByRole('button', { name: /선출 확정/ }).click();
  for (let i = 0; i < 300; i++) {
    if (await page.locator('.result').count()) break;
    if (!shot && await page.locator('.fchip').count() >= 1 && await page.locator('.moves .mv').count()) { await page.screenshot({ path: '/tmp/claude-shots/f-field.png' }); shot = true; console.log('chips:', await page.locator('.fieldbar').textContent(), 'game', g, 'log:', (await page.locator('.log').textContent()).slice(-300)); }
    const mv = page.locator('.moves .mv:not([disabled])'); const sw = page.locator('.sw-list .mon:not([disabled])');
    if (await mv.count()) await mv.nth(Math.floor(Math.random() * await mv.count())).click(); else if (await sw.count()) await sw.first().click(); else await page.waitForTimeout(100);
  }
}
console.log('errors', errors);
await browser.close();
