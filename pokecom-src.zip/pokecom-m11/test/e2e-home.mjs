import { chromium, devices } from '/home/claude/pokecom/node_modules/playwright/index.mjs';
const browser = await chromium.launch();
const ctx = await browser.newContext({ ...devices['iPhone 13'] });
await ctx.route(/raw\.githubusercontent\.com|fonts\./, (r) => r.abort());
const page = await ctx.newPage();
const errors = []; page.on('pageerror', (e) => errors.push(e.message));
await page.goto(process.env.URL);
await page.getByRole('button', { name: '받지 않기' }).click();
await page.waitForTimeout(800);
await page.screenshot({ path: '/tmp/claude-shots/m-home.png' });
await page.getByRole('button', { name: '전적' }).click();
await page.waitForTimeout(600);
await page.screenshot({ path: '/tmp/claude-shots/m-records.png' });
await page.getByRole('button', { name: '닫기' }).click();
// 연습 배틀 한 판
await page.getByRole('button', { name: /연습 배틀/ }).click();
await page.getByText(/선출할/).waitFor();
const mons = page.locator('.mons .mon'); await mons.nth(0).click(); await mons.nth(1).click(); await mons.nth(2).click();
await page.getByRole('button', { name: /선출 확정/ }).click();
for (let i = 0; i < 300; i++) {
  if (await page.locator('.result').count()) break;
  const mv = page.locator('.moves .mv:not([disabled])'); const sw = page.locator('.sw-list .mon:not([disabled])');
  if (await mv.count()) await mv.first().click(); else if (await sw.count()) await sw.first().click(); else await page.waitForTimeout(200);
}
await page.waitForTimeout(800);
console.log('practice:', await page.locator('.result').textContent(), '|', await page.locator('.rate-change').textContent());
console.log('errors', errors);
await browser.close();
