import { chromium, devices } from '/home/claude/pokecom/node_modules/playwright/index.mjs';
import { execFileSync } from 'node:child_process';
const browser = await chromium.launch();
const ctx = await browser.newContext({ ...devices['iPhone 13'] });
await ctx.route(/raw\.githubusercontent\.com/, async (route) => {
  try { const body = execFileSync('curl', ['-sSf', route.request().url()], { maxBuffer: 1 << 24 }); await route.fulfill({ status: 200, body, headers: { 'content-type': 'image/gif', 'access-control-allow-origin': '*' } }); }
  catch { await route.fulfill({ status: 404, body: '', headers: { 'access-control-allow-origin': '*' } }); }
});
await ctx.route(/fonts\.(googleapis|gstatic)/, (r) => r.abort());
const page = await ctx.newPage();
const errors = []; page.on('pageerror', (e) => errors.push(e.message));
await page.goto(process.env.URL);
await page.getByRole('button', { name: '받기', exact: true }).click();
await page.evaluate(() => new Promise((res) => { const r = indexedDB.open('pokecom-ladder', 1); r.onupgradeneeded = () => { r.result.createObjectStore('games', { keyPath: 'id', autoIncrement: true }); r.result.createObjectStore('meta'); }; r.onsuccess = () => { const t = r.result.transaction('meta', 'readwrite'); t.objectStore('meta').put({ rating: 1250, games: 30, wins: 20, losses: 10, ties: 0, streak: 2, bestStreak: 5, peak: 1330 }, 'state'); t.oncomplete = res; }; }));
await page.reload();
await page.getByRole('button', { name: '래더 배틀' }).click();
await page.getByText('선출할 3마리').waitFor();
console.log('opp:', await page.locator('section.panel h2').first().textContent());
const mons = page.locator('.mons .mon');
await mons.nth(0).click(); await mons.nth(1).click(); await mons.nth(2).click();
await page.getByRole('button', { name: /선출 확정/ }).click();
let maxWait = 0, n = 0;
for (let i = 0; i < 300; i++) {
  if (await page.locator('.result').count()) break;
  const mv = page.locator('.moves .mv:not([disabled])'); const sw = page.locator('.sw-list .mon:not([disabled])');
  if (await mv.count()) {
    const t0 = Date.now(); await mv.first().click();
    // 상대 생각 중 표시 확인 + UI 응답성: 생각 중에 정보 버튼 대신 로그 영역 클릭이 되는지
    if (n === 0) { await page.waitForTimeout(300); console.log('prompt:', await page.locator('.cmd .prompt').textContent()); }
    await page.locator('.moves .mv, .sw-list .mon, .result').first().waitFor({ timeout: 60000 });
    maxWait = Math.max(maxWait, Date.now() - t0); n++;
  } else if (await sw.count()) await sw.first().click();
  else await page.waitForTimeout(200);
}
await page.waitForTimeout(1000);
await page.screenshot({ path: '/tmp/claude-shots/l3-end.png' });
console.log('choices', n, 'max turn wait ms', maxWait, 'result', await page.locator('.rate-change').textContent());
console.log('errors', errors);
await browser.close();
