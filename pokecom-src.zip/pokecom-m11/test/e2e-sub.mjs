// v1.5.0: 대타출동 인형, 능력 변화 표시, 연출, 기술 설명 펼치기, 한 줄 밀어 보기
import { chromium, devices } from '/home/claude/pokecom/node_modules/playwright/index.mjs';
import fs from 'node:fs';
const SHOT = process.env.SHOT || '/tmp/claude-shots';
const data = JSON.parse(fs.readFileSync('src/data/samples/gubaksa.json', 'utf8'));
const ST = ['hp', 'atk', 'def', 'spa', 'spd', 'spe'];
const toSet = (s) => ({ name: '', species: s.species, item: s.item, ability: s.ability, nature: s.nature, evs: Object.fromEntries(ST.map((k, i) => [k, s.sp[i]])), ivs: Object.fromEntries(ST.map(k => [k, 31])), moves: s.moves, level: 50, gender: '' });
const p = data.parties[0];
// 망나뇽(대타출동) 선봉, 갑주무사(칼춤)
const sets = [p.sets[2], p.sets[3], p.sets[0], p.sets[1], p.sets[4], p.sets[5]].map(toSet);
const browser = await chromium.launch();
const ctx = await browser.newContext({ ...devices['iPhone 13'] });
await ctx.route(/raw\.githubusercontent\.com|fonts\./, (r) => r.abort());
await ctx.addInitScript((t) => {
  localStorage.setItem('pokecom-teams', JSON.stringify([{ id: 'tsub', name: '대타 테스트', sets: t, updated: 1 }]));
  localStorage.setItem('pokecom-settings', JSON.stringify({ spriteConsent: 'no', activeTeam: 'tsub', speed: 'slow', effects: 'on' }));
}, sets);
const page = await ctx.newPage();
const errors = []; page.on('pageerror', (e) => errors.push(e.message));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
await page.goto(process.env.URL);
await page.getByRole('button', { name: /연습 배틀/ }).click();
await page.getByText(/선출할/).waitFor();
const mons = page.locator('.mons .mon'); await mons.nth(0).click(); await mons.nth(1).click(); await mons.nth(2).click();
// 선출 화면 한 줄 밀어 보기 확인
const hs = await page.locator('.mons .mon .sub.hs').evaluateAll(els => els.map(e => ({ sw: e.scrollWidth, cw: e.clientWidth, ovf: e.classList.contains('ovf') })));
console.log('선출 화면 한 줄:', JSON.stringify(hs.slice(0, 6)));
await page.getByRole('button', { name: /선출 확정/ }).click();
await page.locator('.moves .mv').first().waitFor();
await page.locator('.moves .mv').nth(2).click(); // 대타출동
// 연출 중 화면
const fxSeen = new Set();
for (let i = 0; i < 40; i++) {
  const n = await page.evaluate(() => [...document.querySelectorAll('.fx')].map(e => e.className));
  n.forEach(c => fxSeen.add(c));
  const anims = await page.evaluate(() => document.getAnimations().length);
  if (anims) fxSeen.add('animations:' + anims);
  if (i === 6) await page.screenshot({ path: `${SHOT}/fx-mid.png` });
  if (await page.locator('.moves .mv').first().isVisible().catch(() => false) && i > 5) break;
  await page.waitForTimeout(150);
}
console.log('보인 연출:', [...fxSeen].slice(0, 12).join(' | '));
await page.locator('.moves .mv').first().waitFor({ timeout: 30000 });
const doll = await page.locator('.subdoll').evaluateAll(els => els.map(e => ({ side: e.dataset.side, hidden: e.hidden })));
console.log('대타 인형:', JSON.stringify(doll));
await page.screenshot({ path: `${SHOT}/sub.png` });
// 교체 → 갑주무사 칼춤(랭크 표시)
console.log('errors', errors);
await browser.close();
