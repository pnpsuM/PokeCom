// AI 대 AI 대전: node .tmp/duel.mjs <A> <B> <판 쌍 수> [A 설정 덮어쓰기 JSON]
import { runArena } from '../src/core/arena';
import { FORMAT } from '../src/core/format';
import { RandomTeamSource } from '../src/core/teams';
import { makeAgent, PROFILES } from '../src/core/ai/agent';
const [pa, pb, nStr, over] = process.argv.slice(2);
const n = +(nStr ?? 10);
if (process.env.AI_DEBUG) (globalThis as any).AI_DEBUG = true;
const mk = (id: string, o = {}) => makeAgent({ ...PROFILES.find(p => p.id === id)!, ...o });
const A = mk(pa, JSON.parse(over ?? '{}')), B = mk(pb);
let w = 0, l = 0, t = 0, err = 0, turns = 0; const t0 = Date.now();
for (let i = 0; i < n; i++) {
	const ta = RandomTeamSource.generate(), tb = RandomTeamSource.generate();
	for (const swap of [false, true]) {
		const r = swap ? await runArena(FORMAT, { name: 'B', team: ta, agent: B }, { name: 'A', team: tb, agent: A })
			: await runArena(FORMAT, { name: 'A', team: ta, agent: A }, { name: 'B', team: tb, agent: B });
		const aWon = swap ? r.winner === 'p2' : r.winner === 'p1';
		if (r.winner === null) t++; else if (aWon) w++; else l++;
		err += r.errors; turns += r.turns;
	}
}
console.log(`${pa} vs ${pb}: ${w}승 ${l}패 ${t}무 (${(w / Math.max(1, w + l) * 100).toFixed(0)}%), 오류 ${err}, 평균 ${(turns / (2 * n)).toFixed(1)}턴, ${((Date.now() - t0) / (2 * n)).toFixed(0)}ms/판`);
