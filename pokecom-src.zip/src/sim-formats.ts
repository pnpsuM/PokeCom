// 시뮬레이터에 넣는 포맷 목록 (Showdown config/formats.ts 대신 사용)
// Champions BSS Reg M-C: 싱글, 6마리 중 3마리 선출, Lv50, 메가진화만 (테라·Z·다이맥스 없음)
export const Formats = [
	{
		name: '[Gen 9 Champions] BSS Reg M-C',
		mod: 'champions',
		ruleset: ['Flat Rules'],
	},
];
