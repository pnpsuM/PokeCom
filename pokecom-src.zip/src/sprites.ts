// 스프라이트: PokeAPI/sprites 에서 받아 IndexedDB 에 저장
// 우선순위: BW 공식 애니(5세대까지) → Showdown 애니 → 정지 이미지(PNG, 9세대·신규 메가 포함)
import MAP_JSON from './data/sprites.json';
import { toID } from './sim';
import { settings, saveSettings } from './core/store';

interface Entry { n: number; p: number; bw: string[]; sd: number; png: number }
const MAP = MAP_JSON as Record<string, Entry>;
type Facing = 'front' | 'back';
type SetId = 'bw' | 'sd' | 'png';

const RAW = 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon';
const urlOf = (set: SetId, facing: Facing, name: string) =>
	set === 'bw' ? `${RAW}/versions/generation-v/black-white/animated/${facing === 'back' ? 'back/' : ''}${name}.gif`
		: set === 'sd' ? `${RAW}/other/showdown/${facing === 'back' ? 'back/' : ''}${name}.gif`
			: `${RAW}/${facing === 'back' ? 'back/' : ''}${name}.png`;

const DB_NAME = 'pokecom-sprites';
let dbp: Promise<IDBDatabase | null> | null = null;
function db() {
	return (dbp ??= new Promise(resolve => {
		try {
			const req = indexedDB.open(DB_NAME, 2);
			req.onupgradeneeded = () => {
				const d = req.result;
				if (!d.objectStoreNames.contains('sprites')) d.createObjectStore('sprites');
				if (!d.objectStoreNames.contains('miss')) d.createObjectStore('miss');
			};
			req.onsuccess = () => resolve(req.result);
			req.onerror = () => resolve(null);
		} catch { resolve(null); }
	}));
}
function tx<T>(store: string, mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T> | void): Promise<T | undefined> {
	return db().then(d => new Promise(resolve => {
		if (!d) return resolve(undefined);
		try {
			const t = d.transaction(store, mode);
			const r = fn(t.objectStore(store));
			t.oncomplete = () => resolve(r ? r.result : undefined);
			t.onerror = () => resolve(undefined);
			t.onabort = () => resolve(undefined);
		} catch { resolve(undefined); }
	}));
}

let index: Set<string> | null = null;
let missIndex: Set<string> | null = null;
async function loadIndex() {
	if (index && missIndex) return;
	const keys = (await tx('sprites', 'readonly', s => s.getAllKeys())) ?? [];
	const miss = (await tx('miss', 'readonly', s => s.getAllKeys())) ?? [];
	index = new Set(keys.map(String));
	missIndex = new Set(miss.map(String));
}
export async function storedCount() { await loadIndex(); return index!.size; }
async function putSprites(items: { key: string; blob: Blob }[]) {
	await loadIndex();
	await tx('sprites', 'readwrite', s => { for (const it of items) s.put(it.blob, it.key); });
	for (const it of items) { index!.add(it.key); missIndex!.delete(it.key); urlCache.delete(it.key); }
}
export async function clearSprites() {
	await tx('sprites', 'readwrite', s => s.clear());
	await tx('miss', 'readwrite', s => s.clear());
	index = new Set(); missIndex = new Set();
	urlCache.forEach(u => URL.revokeObjectURL(u)); urlCache.clear();
}

function entryFor(id: string): Entry | undefined {
	let e = MAP[id];
	if (!e) {
		const k = Object.keys(MAP).filter(k => id.startsWith(k)).sort((a, b) => b.length - a.length)[0];
		e = k ? MAP[k] : undefined;
	}
	return e;
}
function candidates(id: string, facing: Facing) {
	const e = entryFor(id);
	if (!e) return [];
	const out: { set: SetId; key: string; url: string }[] = [];
	for (const b of e.bw) out.push({ set: 'bw', key: `bw/${facing}/${b}`, url: urlOf('bw', facing, b) });
	if (e.p && e.sd) out.push({ set: 'sd', key: `sd/${facing}/${e.p}`, url: urlOf('sd', facing, String(e.p)) });
	if (e.p && e.png) out.push({ set: 'png', key: `png/${facing}/${e.p}`, url: urlOf('png', facing, String(e.p)) });
	return out;
}

const urlCache = new Map<string, string>();
const inflight = new Map<string, Promise<boolean>>();
let netBlocked = false;
export const networkBlocked = () => netBlocked;

async function download(c: { key: string; url: string }): Promise<boolean> {
	if (inflight.has(c.key)) return inflight.get(c.key)!;
	const p = (async () => {
		try {
			const res = await fetch(c.url, { mode: 'cors' });
			if (res.status === 404) { await tx('miss', 'readwrite', s => s.put(1, c.key)); missIndex!.add(c.key); return false; }
			if (!res.ok) return false;
			await putSprites([{ key: c.key, blob: await res.blob() }]);
			return true;
		} catch { netBlocked = true; return false; } finally { inflight.delete(c.key); }
	})();
	inflight.set(c.key, p);
	return p;
}
const canDownload = () => settings.spriteConsent === 'yes' && !netBlocked;

async function ensure(species: string, facing: Facing, allowDownload = true) {
	await loadIndex();
	const cs = candidates(toID(species), facing);
	for (const c of cs) if (index!.has(c.key)) return { key: c.key, set: c.set };
	if (!allowDownload || !canDownload()) return null;
	for (const c of cs) {
		if (missIndex!.has(c.key)) continue;
		if (await download(c)) return { key: c.key, set: c.set };
		if (netBlocked) return null;
	}
	return null;
}

export async function spriteURL(species: string, facing: Facing, allowDownload = true) {
	const hit = await ensure(species, facing, allowDownload);
	if (!hit) return null;
	if (urlCache.has(hit.key)) return { url: urlCache.get(hit.key)!, set: hit.set };
	const blob = await tx<Blob>('sprites', 'readonly', s => s.get(hit.key) as IDBRequest<Blob>);
	if (!blob) return null;
	const url = URL.createObjectURL(blob);
	urlCache.set(hit.key, url);
	return { url, set: hit.set };
}

export async function prefetch(species: string[], progress?: (done: number, total: number) => void) {
	const jobs: [string, Facing][] = [];
	for (const s of species) jobs.push([s, 'front'], [s, 'back']);
	let done = 0;
	await runPool(jobs, 4, async ([s, f]) => { await ensure(s, f); progress?.(++done, jobs.length); });
}

export async function downloadAll(progress: (done: number, total: number, got: number) => void, ctl: { cancel: boolean }) {
	const jobs: [string, Facing][] = [];
	for (const id of Object.keys(MAP)) jobs.push([id, 'front'], [id, 'back']);
	let done = 0, got = 0;
	await runPool(jobs, 6, async ([id, f]) => {
		if (ctl.cancel) return;
		if (await ensure(id, f)) got++;
		progress(++done, jobs.length, got);
	});
	if (!ctl.cancel && !netBlocked) { settings.spriteAllDone = true; saveSettings(); }
}
export const spriteTotal = () => Object.keys(MAP).length * 2;

async function runPool<T>(items: T[], n: number, fn: (x: T) => Promise<void>) {
	let i = 0;
	await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => { while (i < items.length) await fn(items[i++]); }));
}

export async function probeNetwork() {
	try {
		const res = await fetch(urlOf('bw', 'front', '25'), { mode: 'cors', cache: 'no-store' });
		netBlocked = !res.ok;
		return res.ok;
	} catch { netBlocked = true; return false; }
}

/** ZIP·폴더 불러오기용: 파일 경로 → 저장 키 */
function keyForPath(p: string): string | null {
	const s = p.replace(/\\/g, '/').toLowerCase();
	const m = s.match(/([^/]+)\.(gif|png)$/);
	if (!m || /(^|\/)(shiny|female)\//.test(s)) return null;
	const facing = /(^|\/)back\//.test(s) ? 'back' : 'front';
	if (s.includes('showdown')) return `sd/${facing}/${m[1]}`;
	if (s.includes('black-white') || /(^|\/)animated\//.test(s)) return `bw/${facing}/${m[1]}`;
	if (m[2] === 'png' && /(^|\/)pokemon\/(back\/)?[0-9]+\.png$/.test(s)) return `png/${facing}/${m[1]}`;
	return null;
}
export async function importFiles(files: File[], status: (s: string) => void) {
	let saved = 0;
	const loose: { key: string; blob: Blob }[] = [];
	for (const f of files) {
		if (/\.zip$/i.test(f.name)) {
			status(`ZIP 여는 중… (${Math.round(f.size / 1048576)}MB)`);
			const { default: JSZip } = await import('jszip');
			const zip = await JSZip.loadAsync(f);
			const entries: { key: string; e: any; png: boolean }[] = [];
			zip.forEach((path: string, e: any) => { const k = !e.dir && keyForPath(path); if (k) entries.push({ key: k, e, png: /\.png$/i.test(path) }); });
			for (let i = 0; i < entries.length; i += 200) {
				const batch = await Promise.all(entries.slice(i, i + 200).map(async x => ({
					key: x.key, blob: new Blob([await x.e.async('arraybuffer')], { type: x.png ? 'image/png' : 'image/gif' }),
				})));
				await putSprites(batch);
				saved += batch.length;
				status(`${saved} / ${entries.length}개 저장 중`);
			}
		} else {
			const k = keyForPath((f as any).webkitRelativePath || f.name);
			if (k) loose.push({ key: k, blob: f });
		}
	}
	for (let i = 0; i < loose.length; i += 200) {
		await putSprites(loose.slice(i, i + 200));
		saved += Math.min(200, loose.length - i);
		status(`${saved}개 저장 중`);
	}
	return saved;
}
