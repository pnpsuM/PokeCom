// 배틀 화면 (M1 BattleController 복원, Z기술 제거·메가진화만)
import { h, clear, sheet, toast, confirmSheet } from './dom';
import { app, nav } from './nav';
import { typeTag, spriteInto, monRow, moveCard, TYPE_COLOR, thumb } from './common';
import { BattleSession } from '../core/session';
import { BattleView, WEATHER_KO, type LogEntry } from '../core/view';
import { RandomAgent } from '../core/agents';
import { RandomTeamSource } from '../core/teams';
import { FORMAT, dex, type PokemonSet } from '../core/format';
import { koSpecies, koMove, koType, koAbility, koItem, koAbilityDesc, koItemDesc, STAT_KO, STATUS_KO, eun } from '../core/ko';
import { badgeFor, effectiveness, moveType, speciesTypes } from '../core/typecalc';
import { settings } from '../core/store';
import { prefetch } from '../sprites';

export function startBattle(team: PokemonSet[], opp?: PokemonSet[]) {
	new BattleController(team, opp ?? RandomTeamSource.generate()).start();
}

class BattleController {
	view: BattleView;
	session!: BattleSession;
	queue: string[] = [];
	live = false;
	pumping = false;
	skip = false;
	pendingReq: any = null;
	ended = false;
	megaOn = false;
	logEl!: HTMLElement; cmdEl!: HTMLElement; innerEl!: HTMLElement; fieldEl!: HTMLElement;
	sprEl: Record<string, HTMLElement> = {};
	infoEl: Record<string, HTMLElement> = {};
	shown: Record<string, string> = { p1: '', p2: '' };

	constructor(public team: PokemonSet[], public oppTeam: PokemonSet[]) {
		this.view = new BattleView(settings.playerName, '컴퓨터');
	}

	start() {
		this.session = new BattleSession({
			format: FORMAT,
			p1: { name: settings.playerName, team: this.team },
			p2: { name: '컴퓨터', team: this.oppTeam, agent: RandomAgent },
		}, {
			onLine: line => { if (this.live) { this.queue.push(line); this.pump(); } else this.view.add(line); },
			onRequest: req => {
				if (req.teamPreview) { this.view.setOwnTeam(req.side.pokemon); this.renderPreview(req); return; }
				this.pendingReq = req; this.pump();
			},
			onEnd: () => { this.ended = true; this.pump(); },
			onError: msg => { if (!msg.includes('Unavailable choice')) toast('선택 오류: ' + msg); },
		});
	}

	setFor(details: string, i: number) {
		const sp = details.split(',')[0];
		return this.team.find(s => koSpecies(s.species) === koSpecies(sp)) ?? this.team[i];
	}

	renderPreview(req: any) {
		clear(app);
		const order: number[] = [];
		const btn = h('button', { class: 'btn primary', type: 'button', disabled: true, style: 'min-height:54px;font-size:17px' }, `선출 확정 (0/${FORMAT.pickSize})`);
		const rows: HTMLElement[] = [];
		const refresh = () => {
			rows.forEach((el, i) => {
				const k = order.indexOf(i + 1);
				el.classList.toggle('picked', k >= 0);
				(el.querySelector('.order') as HTMLElement).textContent = k >= 0 ? String(k + 1) : '';
				el.setAttribute('aria-pressed', String(k >= 0));
			});
			btn.disabled = order.length !== FORMAT.pickSize;
			btn.textContent = `선출 확정 (${order.length}/${FORMAT.pickSize})`;
		};
		req.side.pokemon.forEach((p: any, i: number) => {
			const set = this.setFor(p.details, i);
			rows.push(monRow(set, h('span', { class: 'order', 'aria-hidden': 'true' }), () => {
				const k = order.indexOf(i + 1);
				if (k >= 0) order.splice(k, 1); else if (order.length < FORMAT.pickSize) order.push(i + 1);
				refresh();
			}));
		});
		const oppGrid = h('div', { class: 'opp-grid' }, this.view.state.sides.p2.team.map(m => {
			const t = h('div', { class: 'thumb' });
			spriteInto(t, m.species, 'front', 1, { download: false, maxH: 64, slotSize: 56 });
			return h('div', { class: 'cell' }, t, koSpecies(m.species), h('div', null, ...speciesTypes(m.species).map(typeTag)));
		}));
		const status = h('div', { class: 'muted', role: 'status' });
		btn.addEventListener('click', async () => {
			btn.disabled = true;
			if (settings.spriteConsent === 'yes') {
				status.textContent = '스프라이트 준비 중…';
				const names = [...this.team.map(s => s.species), ...this.view.state.sides.p2.team.map(m => m.species)];
				for (const s of [...this.team, ...this.oppTeam]) {
					const stone = dex.items.get(s.item).megaStone;
					if (stone) names.push(...Object.values(stone) as string[]);
				}
				await Promise.race([
					prefetch(names, (d, t) => (status.textContent = `스프라이트 받는 중 ${d}/${t}`)),
					new Promise(r => setTimeout(r, 12000)),
				]);
			}
			this.mountBattle();
			this.session.choose(`team ${order.join('')}`);
		});
		app.appendChild(h('div', { class: 'page' },
			h('div', { class: 'eyebrow' }, 'TEAM PREVIEW'),
			h('section', { class: 'panel' }, h('h2', null, '상대 파티'), oppGrid),
			h('section', { class: 'panel' }, h('h2', null, `선출할 ${FORMAT.pickSize}마리`, h('span', { class: 'muted' }, '누른 순서 = 나오는 순서')), h('div', { class: 'mons' }, rows)),
			btn, status,
			h('button', { class: 'btn ghost', type: 'button', on: { click: nav.home } }, '그만두기')));
		(rows[0] as HTMLElement | undefined)?.focus();
	}

	mountBattle() {
		clear(app);
		this.live = true;
		for (const s of ['p1', 'p2']) { this.sprEl[s] = h('div', { class: 'spr' }); this.infoEl[s] = h('div', { class: 'info' }); }
		this.sprEl.p2.style.cssText = 'left:262px;top:122px';
		this.sprEl.p1.style.cssText = 'left:96px;top:252px';
		this.infoEl.p2.style.cssText = 'left:8px;top:8px;border-radius:4px 14px 4px 4px';
		this.infoEl.p1.style.cssText = 'left:180px;top:170px;border-radius:14px 4px 4px 4px';
		this.fieldEl = h('div', { class: 'field-tags' });
		this.innerEl = h('div', { class: 'inner' },
			h('div', { class: 'ground' }), h('div', { class: 'stripe', style: 'top:120px' }), h('div', { class: 'stripe', style: 'top:150px' }),
			h('div', { class: 'plat', style: 'left:192px;top:100px;width:140px;height:40px' }),
			h('div', { class: 'plat', style: 'left:-24px;top:226px;width:220px;height:60px' }),
			this.sprEl.p2, this.sprEl.p1, this.infoEl.p2, this.infoEl.p1, this.fieldEl);
		const screen = h('div', { class: 'screen', on: { click: () => (this.skip = true) } }, this.innerEl);
		this.logEl = h('div', { class: 'log', role: 'log', 'aria-live': 'polite', on: { click: () => (this.skip = true) } });
		this.cmdEl = h('div', { class: 'cmd' });
		app.appendChild(h('div', { class: 'battle' }, screen, this.logEl, this.cmdEl));
		const fit = () => { this.innerEl.style.transform = `scale(${screen.clientWidth / 360})`; };
		new ResizeObserver(fit).observe(screen); fit();
		for (const e of this.view.state.log) this.appendLog([e]);
		this.renderScene();
		this.cmdWaiting('배틀 준비 중…');
	}

	delayFor(entries: LogEntry[]) {
		if (this.skip || settings.speed === 'instant') return 0;
		const base = { slow: 900, normal: 520, fast: 260, instant: 0 }[settings.speed];
		let d = 0;
		for (const e of entries) d = Math.max(d, e.kind === 'hp' ? base * 0.6 : e.kind === 'turn' ? base * 0.3 : base);
		return d;
	}

	async pump() {
		if (this.pumping || !this.live) return;
		this.pumping = true;
		if (this.queue.length) this.cmdWaiting('▶ 화면을 누르면 빨리 넘긴다', true);
		while (this.queue.length) {
			const line = this.queue.shift()!;
			const before = this.view.state.log.length;
			this.view.add(line);
			const added = this.view.state.log.slice(before);
			if (added.length) {
				this.renderScene(); this.appendLog(added);
				const d = this.delayFor(added);
				if (d) await new Promise(r => setTimeout(r, d));
			}
		}
		this.pumping = false; this.skip = false;
		this.renderScene();
		if (this.ended) { this.showEnd(); return; }
		if (this.pendingReq) { const r = this.pendingReq; this.pendingReq = null; this.showCommands(r); }
	}

	appendLog(entries: LogEntry[]) {
		for (const e of entries) this.logEl.appendChild(h('p', { class: e.kind + (e.side === 'p2' && e.kind !== 'hp' ? ' p2' : '') }, e.text));
		this.logEl.scrollTop = this.logEl.scrollHeight;
	}

	renderScene() {
		const st = this.view.state;
		for (const sid of ['p1', 'p2'] as const) {
			const m = st.sides[sid].active;
			const info = this.infoEl[sid], spr = this.sprEl[sid];
			if (!m) { info.hidden = true; spr.hidden = true; continue; }
			info.hidden = false; spr.hidden = false;
			const p = m.maxhp ? Math.max(0, Math.round((m.hp / m.maxhp) * 100)) : 0;
			const bar = h('i', { class: p <= 20 ? 'low' : p <= 50 ? 'mid' : '', style: `width:${p}%` });
			const prev = info.querySelector('.hpbar i') as HTMLElement | null;
			clear(info);
			info.append(
				h('div', { class: 'nm' }, h('b', null, koSpecies(m.species)), h('span', null, `${m.gender === 'M' ? '♂' : m.gender === 'F' ? '♀' : ''} Lv${m.level}`)),
				h('div', { class: 'hpbar' }, h('em', null, 'HP'), h('div', null, bar)),
				h('div', { class: 'meta' }, m.status ? h('span', { class: `st ${m.status}` }, STATUS_KO[m.status] ?? m.status) : h('span'), h('span', null, sid === 'p1' ? `${m.hp}/${m.maxhp}` : `${p}%`)));
			if (prev) { bar.style.width = prev.style.width; requestAnimationFrame(() => requestAnimationFrame(() => (bar.style.width = `${p}%`))); }
			const key = m.nick + '|' + m.species;
			if (this.shown[sid] !== key) {
				this.shown[sid] = key;
				spr.classList.remove('faint');
				spriteInto(spr, m.species, sid === 'p1' ? 'back' : 'front', sid === 'p1' ? 2 : 1.5, { maxH: sid === 'p1' ? 170 : 120 });
			}
			spr.classList.toggle('faint', m.fainted);
		}
		const tags: string[] = [];
		if (st.weather) tags.push(WEATHER_KO[st.weather] ?? st.weather);
		for (const t of st.terrain) tags.push(koMove(t));
		for (const c of st.sides.p2.conditions) tags.push('상대: ' + koMove(c));
		for (const c of st.sides.p1.conditions) tags.push('우리: ' + koMove(c));
		clear(this.fieldEl);
		for (const t of tags) this.fieldEl.appendChild(h('span', null, t));
	}

	cmdWaiting(text: string, clickable = false) {
		clear(this.cmdEl);
		this.cmdEl.appendChild(h('div', { class: 'prompt muted', on: clickable ? { click: () => (this.skip = true) } : undefined }, text));
	}

	showCommands(req: any) {
		this.view.setOwnTeam(req.side.pokemon);
		this.renderScene();
		if (req.forceSwitch) { this.showSwitch(req, true); return; }
		const act = req.active?.[0];
		if (!act) { this.session.choose('default'); return; }
		const me = req.side.pokemon.find((p: any) => p.active);
		const foe = this.view.state.sides.p2.active?.species;
		if (!act.canMegaEvo) this.megaOn = false;
		clear(this.cmdEl);
		const name = koSpecies(me.details.split(',')[0]);
		const moves = h('div', { class: 'moves' }, act.moves.map((m: any, i: number) => {
			const type = moveType(m.id);
			const eff = foe ? effectiveness(m.id, foe) : null;
			const noPP = m.pp <= 0 && m.maxpp > 0;
			const choice = `move ${i + 1}${this.megaOn ? ' mega' : ''}`;
			const b = h('button', {
				class: 'mv', type: 'button', disabled: !!m.disabled || noPP, style: `background:${TYPE_COLOR[type] ?? '#666'}`,
				'aria-label': `${koMove(m.move)}, ${koType(type)} 타입, PP ${m.pp}/${m.maxpp}${eff == null ? '' : ', ' + badgeFor(eff).label}`,
				on: { click: () => this.send(choice) },
			},
			h('b', null, koMove(m.move)),
			h('small', null, `${koType(type)} · ${m.maxpp ? `${m.pp}/${m.maxpp}` : '-'}`, eff == null ? null : h('span', { class: `eff ${badgeFor(eff).cls}` }, badgeFor(eff).label)));
			b.style.flex = '1';
			return h('div', { style: 'position:relative;display:flex' }, b,
				h('button', {
					class: 'ib', type: 'button', 'aria-label': `${koMove(m.move)} 설명`,
					on: { click: (e: Event) => { e.stopPropagation(); sheet(close => [moveCard(m.move, `${m.pp}/${m.maxpp}`), h('button', { class: 'btn', type: 'button', on: { click: close } }, '닫기')], { label: '기술 정보' }); } },
				}, 'i'));
		}));
		const toggles = h('div', { class: 'toggles' },
			act.canMegaEvo ? h('button', {
				class: 'toggle' + (this.megaOn ? ' on' : ''), type: 'button', 'aria-pressed': String(this.megaOn),
				on: { click: () => { this.megaOn = !this.megaOn; this.showCommands(req); } },
			}, '메가진화') : null,
			h('button', { class: 'toggle', type: 'button', disabled: !!act.trapped, on: { click: () => this.showSwitch(req, false) } }, act.trapped ? '교체 불가' : '교체'),
			h('button', { class: 'toggle', type: 'button', on: { click: () => this.openInfo(req) } }, '정보'));
		this.cmdEl.append(h('div', { class: 'prompt' }, `${eun(name)} 무엇을 할까?`), moves, toggles);
	}

	showSwitch(req: any, forced: boolean) {
		clear(this.cmdEl);
		const reviving = forced && req.side.pokemon.some((p: any) => p.reviving);
		const list = h('div', { class: 'sw-list' }, req.side.pokemon.map((p: any, i: number) => {
			const sp = p.details.split(',')[0];
			const [hp, status] = p.condition.split(' ');
			const fnt = status === 'fnt' || hp === '0';
			const [cur, max] = hp.split('/').map(Number);
			const set = this.team.find(s => koSpecies(s.species) === koSpecies(sp));
			const off = p.active || (reviving ? !fnt : fnt);
			return h('button', {
				class: 'mon', type: 'button', disabled: off, style: off ? 'opacity:.5' : '',
				on: { click: () => this.send(`switch ${i + 1}`) },
			},
			thumb(sp),
			h('div', null,
				h('div', { class: 'nm' }, koSpecies(sp), ' ', status && status !== 'fnt' ? h('span', { class: `st ${status}` }, STATUS_KO[status] ?? status) : null),
				h('div', { class: 'sub' }, fnt ? '기절' : `HP ${cur}/${max}${p.active ? ' · 싸우는 중' : ''}`),
				set ? h('div', { class: 'sub' }, set.moves.map(koMove).join(' / ')) : null),
			h('span'));
		}));
		this.cmdEl.append(h('div', { class: 'prompt' }, reviving ? '되살릴 포켓몬을 고른다' : forced ? '다음 포켓몬을 고른다' : '교체할 포켓몬'), list);
		if (!forced) this.cmdEl.append(h('button', { class: 'btn small', type: 'button', on: { click: () => this.showCommands(req) } }, '돌아가기'));
	}

	send(choice: string) {
		this.megaOn = false;
		this.cmdWaiting('상대를 기다리는 중…');
		this.session.choose(choice);
	}

	openInfo(req: any) {
		const st = this.view.state;
		const me = req.side.pokemon.find((p: any) => p.active);
		const foe = st.sides.p2.active;
		let tab = 'moves';
		sheet(close => {
			const body = h('div', { style: 'display:flex;flex-direction:column;gap:10px' });
			const tabs = h('div', { class: 'tabs', role: 'tablist' });
			const draw = () => {
				clear(tabs); clear(body);
				for (const [k, t] of [['moves', '기술'], ['ability', '특성·도구'], ['boosts', '능력 변화']]) {
					tabs.appendChild(h('button', { type: 'button', role: 'tab', 'aria-selected': String(tab === k), on: { click: () => { tab = k; draw(); } } }, t));
				}
				const foeName = foe ? koSpecies(foe.species) : '-';
				const myName = me ? koSpecies(me.details.split(',')[0]) : '-';
				if (tab === 'moves') {
					body.append(h('h2', null, `내 ${myName}`));
					req.active?.[0]?.moves.forEach((m: any) => body.appendChild(moveCard(m.move, `${m.pp}/${m.maxpp}`)));
					body.append(h('h2', null, `상대 ${foeName}`, h('span', { class: 'muted' }, '지금까지 쓴 기술')));
					if (foe?.moves.length) foe.moves.forEach(m => body.appendChild(moveCard(m)));
					else body.append(h('div', { class: 'muted' }, '아직 공개된 기술이 없다'));
				} else if (tab === 'ability') {
					if (me) body.append(h('h2', null, `내 ${myName}`), h('dl', { class: 'kv' },
						h('dt', null, '특성'), h('dd', null, koAbility(me.ability ?? me.baseAbility), h('div', { class: 'muted' }, koAbilityDesc(me.ability ?? me.baseAbility))),
						h('dt', null, '도구'), h('dd', null, me.item ? koItem(me.item) : '없음', h('div', { class: 'muted' }, me.item ? koItemDesc(me.item) : ''))));
					if (foe) {
						const sp = dex.species.get(foe.species);
						const possible = [...new Set(Object.values(sp.abilities) as string[])].map(koAbility).join(' / ');
						body.append(h('h2', null, `상대 ${foeName}`), h('dl', { class: 'kv' },
							h('dt', null, '타입'), h('dd', null, ...speciesTypes(foe.species).map(typeTag)),
							h('dt', null, '특성'), h('dd', null, foe.ability ? koAbility(foe.ability) : `미공개 (가능: ${possible})`, foe.ability ? h('div', { class: 'muted' }, koAbilityDesc(foe.ability)) : null),
							h('dt', null, '도구'), h('dd', null, foe.item === undefined ? '미공개' : foe.item ? koItem(foe.item) : '없음')));
					}
				} else {
					for (const sid of ['p1', 'p2'] as const) {
						const side = st.sides[sid];
						const a = side.active;
						body.append(h('h2', null, `${sid === 'p1' ? '내' : '상대'} ${a ? koSpecies(a.species) : '-'}`, a?.status ? h('span', { class: `st ${a.status}` }, STATUS_KO[a.status]) : null));
						body.append(h('div', { class: 'boosts' }, ['atk', 'def', 'spa', 'spd', 'spe', 'accuracy', 'evasion'].map(s => {
							const v = side.boosts[s] ?? 0;
							return h('div', { class: v > 0 ? 'up' : v < 0 ? 'down' : '' }, STAT_KO[s], h('b', null, v > 0 ? `+${v}` : String(v)));
						})));
						const vols = [...side.volatiles.map(v => koMove(v)), ...side.conditions.map(c => koMove(c))];
						if (vols.length) body.append(h('div', { class: 'muted' }, '상태: ' + vols.join(', ')));
					}
					body.append(h('button', { class: 'btn small danger', type: 'button', on: { click: () => { close(); confirmSheet('기권할까?', '기권', () => this.session.forfeit()); } } }, '기권'));
				}
			};
			draw();
			return [h('div', { class: 'row', style: 'justify-content:space-between' }, h('h2', null, '배틀 정보'), h('button', { class: 'btn small', type: 'button', on: { click: close } }, '닫기')), tabs, body];
		}, { label: '배틀 정보' });
	}

	showEnd() {
		const won = this.view.state.winner === settings.playerName;
		clear(this.cmdEl);
		this.cmdEl.append(
			h('div', { class: 'result', style: `color:${won ? 'var(--accent)' : 'var(--bad)'}` }, won ? '승리!' : this.view.state.winner ? '패배…' : '무승부'),
			h('div', { class: 'row' },
				h('button', { class: 'btn primary grow', type: 'button', on: { click: () => startBattle(this.team, this.oppTeam) } }, '같은 상대로 다시'),
				h('button', { class: 'btn grow', type: 'button', on: { click: () => startBattle(this.team) } }, '새 상대')),
			h('button', { class: 'btn ghost', type: 'button', on: { click: nav.home } }, '홈으로'));
	}
}
