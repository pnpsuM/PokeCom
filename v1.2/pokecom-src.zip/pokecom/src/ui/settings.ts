import { h, clear, sheet, toast } from './dom';
import { seg } from './common';
import { settings, saveSettings } from '../core/store';
import { resetLadder, RATED } from '../core/ladder';
import { storedCount, probeNetwork, downloadAll, networkBlocked, importFiles, clearSprites, spriteTotal } from '../sprites';

export function askConsent(after?: () => void) {
	sheet(close => [
		h('h2', null, '스프라이트 받기'),
		h('p', { style: 'margin:0' }, '배틀 화면과 파티 짜기에 포켓몬 그림을 띄우려면 GitHub의 PokeAPI/sprites 저장소에서 이미지를 받아 이 기기에 저장한다. 기본은 필요할 때만(선출 확정 시 양측 6마리) 받는다.'),
		h('p', { class: 'muted', style: 'margin:0' }, '받지 않으면 그림 대신 슬롯 카드로 표시한다. 인터넷 없이 쓰려면 설정에서 "전체 미리 받기"를 한 번 실행해 둔다.'),
		h('div', { class: 'row' },
			h('button', {
				class: 'btn primary grow', type: 'button', on: {
					click: async () => {
						settings.spriteConsent = 'yes'; saveSettings(); close();
						if (!(await probeNetwork())) toast('GitHub에 연결하지 못했다. 슬롯 카드로 표시하고, 설정에서 ZIP으로 불러올 수 있다', 4200);
						after?.();
					},
				},
			}, '받기'),
			h('button', { class: 'btn ghost', type: 'button', on: { click: () => { settings.spriteConsent = 'no'; saveSettings(); close(); after?.(); } } }, '받지 않기')),
	], { center: true, label: '스프라이트 받기 동의', dismissable: false });
}

export function openSettings(onClose?: () => void) {
	sheet(close => {
		const count = h('b', null, '…');
		storedCount().then(n => (count.textContent = String(n)));
		const status = h('div', { class: 'muted', role: 'status' });
		const bar = h('div');
		const progress = h('div', { class: 'progress', hidden: true }, bar);
		let ctl = { cancel: false };
		const startBtn = h('button', { class: 'btn', type: 'button' }, settings.spriteAllDone ? '전체 다시 확인' : '전체 받기 시작');
		const stopBtn = h('button', { class: 'btn ghost', type: 'button', hidden: true }, '멈추기');
		const consentBox = h('div');
		const drawConsent = () => {
			clear(consentBox);
			consentBox.appendChild(seg('GitHub에서 받기', [['yes', 'GitHub에서 받기'], ['no', '받지 않기']], settings.spriteConsent === 'yes' ? 'yes' : 'no', v => { settings.spriteConsent = v; saveSettings(); }));
		};
		drawConsent();
		startBtn.addEventListener('click', async () => {
			if (settings.spriteConsent !== 'yes') { settings.spriteConsent = 'yes'; saveSettings(); drawConsent(); }
			if (!(await probeNetwork())) { status.textContent = 'GitHub에 연결하지 못했다. ZIP 불러오기를 쓸 것'; return; }
			ctl = { cancel: false };
			startBtn.disabled = true; stopBtn.hidden = false; progress.hidden = false;
			await downloadAll((d, t, got) => { bar.style.width = `${(d / t) * 100}%`; status.textContent = `${d} / ${t} 확인 · ${got}장 확보`; }, ctl);
			startBtn.disabled = false; stopBtn.hidden = true;
			status.textContent += ctl.cancel ? ' · 멈춤' : networkBlocked() ? ' · 연결 끊김' : ' · 완료';
			count.textContent = String(await storedCount());
		});
		stopBtn.addEventListener('click', () => { ctl.cancel = true; });

		const modeInfo = h('div', { style: 'display:flex;flex-direction:column;gap:8px' },
			h('div', { class: 'muted' }, `Champions 에 나오는 모든 포켓몬(폼·메가 포함)의 앞·뒤 모습. 약 ${spriteTotal()}장, 수십 MB.`),
			h('div', { class: 'row' }, startBtn, stopBtn), progress);
		const modeBox = seg('받는 시점', [['ondemand', '필요할 때만'], ['all', '전체 미리 받기']], settings.spriteMode, v => { settings.spriteMode = v; saveSettings(); modeInfo.hidden = v !== 'all'; });
		modeInfo.hidden = settings.spriteMode !== 'all';

		const fileIn = h('input', { type: 'file', multiple: true, accept: '.zip,.gif,.png' }) as HTMLInputElement;
		const dirIn = h('input', { type: 'file', multiple: true }) as HTMLInputElement;
		dirIn.setAttribute('webkitdirectory', '');
		const onFiles = async (input: HTMLInputElement) => {
			const files = Array.from(input.files ?? []);
			input.value = '';
			if (!files.length) return;
			try { status.textContent = `${await importFiles(files, s => (status.textContent = s))}장 저장 완료`; } catch (e: any) { status.textContent = '불러오기 실패: ' + e.message; }
			count.textContent = String(await storedCount());
		};
		fileIn.addEventListener('change', () => onFiles(fileIn));
		dirIn.addEventListener('change', () => onFiles(dirIn));
		const confirmClear = h('div', { class: 'row', hidden: true },
			h('span', { class: 'grow' }, '저장된 스프라이트를 모두 지울까?'),
			h('button', {
				class: 'btn small danger', type: 'button', on: {
					click: async () => {
						await clearSprites(); settings.spriteAllDone = false; saveSettings();
						count.textContent = '0'; confirmClear.hidden = true; status.textContent = '모두 지웠다';
					},
				},
			}, '지우기'),
			h('button', { class: 'btn small', type: 'button', on: { click: () => (confirmClear.hidden = true) } }, '취소'));

		const resetBox = h('div', { class: 'row', hidden: true },
			h('span', { class: 'grow' }, '레이팅을 1000으로 되돌리고 전적을 모두 지울까? 되돌릴 수 없다.'),
			h('button', { class: 'btn small danger', type: 'button', on: { click: async () => { await resetLadder(); resetBox.hidden = true; toast('레이팅과 전적을 초기화했다'); } } }, '초기화'),
			h('button', { class: 'btn small', type: 'button', on: { click: () => (resetBox.hidden = true) } }, '취소'));
		const nameIn = h('input', { class: 'text', value: settings.playerName, maxlength: 12, 'aria-label': '내 이름', on: { change: () => { settings.playerName = nameIn.value.trim() || '나'; saveSettings(); } } });
		return [
			h('h2', null, '설정', h('button', { class: 'btn small', type: 'button', on: { click: () => { close(); onClose?.(); } } }, '닫기')),
			h('section', { class: 'panel' },
				h('h2', null, '스프라이트', h('span', { class: 'muted' }, '저장됨 ', count, '장')),
				consentBox, modeBox, modeInfo,
				h('div', { class: 'muted' }, '받기가 막힌 환경이면 PC에서 받은 sprites 폴더를 ZIP으로 묶어 불러온다.'),
				h('div', { class: 'row' },
					h('label', { class: 'btn small filebtn' }, 'ZIP·파일 불러오기', fileIn),
					h('label', { class: 'btn small filebtn' }, '폴더 불러오기', dirIn),
					h('button', { class: 'btn small danger', type: 'button', on: { click: () => (confirmClear.hidden = false) } }, '지우기')),
				confirmClear, status),
			h('section', { class: 'panel' }, h('h2', null, '메시지 속도'),
				seg('메시지 속도', [['slow', '느리게'], ['normal', '보통'], ['fast', '빠르게'], ['instant', '즉시']], settings.speed, v => { settings.speed = v; saveSettings(); })),
			h('section', { class: 'panel' }, h('h2', null, '내 이름'), nameIn),
			h('section', { class: 'panel' },
				h('h2', null, '래더'),
				h('div', { class: 'muted' }, `상대 AI ${RATED.length}단계 (레이팅 ${RATED[0]?.rating}~${RATED[RATED.length - 1]?.rating}, AI끼리 자동 대전으로 측정). 기록은 이 기기에만 저장된다.`),
				h('div', { class: 'row' }, h('button', { class: 'btn small danger', type: 'button', on: { click: () => (resetBox.hidden = false) } }, '레이팅·전적 초기화')),
				resetBox),
		];
	}, { label: '설정' });
}
