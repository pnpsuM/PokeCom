// 상황 점수: 판 전체가 0번 편(판단하는 AI)에게 얼마나 유리한가. 모든 단계(L1~L3)가 같은 함수를 쓴다.
import { toID } from '../../sim';
import { activeOf, aliveCount, bestDamage, order, typesOf, type World, type WSide, type WMon } from './world';
import { dex } from '../format';

export interface Weights {
  alive: number;       // 살아 있는 포켓몬 1마리
  hp: number;          // HP 100% 당
  status: Record<string, number>;   // 상태이상별 가치 감소 비율
  matchup: number;     // 현재 대면 유불리 (−1~1 정규화)
  boost: number;       // 유효 랭크 1단계
  hazard: number;      // 스텔스록 등으로 앞으로 깎일 HP 1% 당
  screen: number;      // 벽·순풍 남은 1턴 당
  win: number;         // 승패 확정
  switchCost: number;  // 자진 교체 1회 비용 (교체 반복 방지, 모든 단계 공통)
}

export const DEFAULT_WEIGHTS: Weights = {
  alive: 1.0, hp: 1.2,
  status: { brn: 0.2, par: 0.2, psn: 0.12, tox: 0.25, slp: 0.35, frz: 0.45 },
  matchup: 0.6, boost: 0.1, hazard: 0.01, screen: 0.04, win: 20, switchCost: 0.15,
};

function physical(m: WMon) { const b = dex.species.get(m.set.species).baseStats; return b.atk >= b.spa; }

function monValue(m: WMon, W: Weights): number {
  if (!m.alive) return 0;
  let v = W.alive + W.hp * (m.hp / 100);
  let pen = W.status[m.status] ?? 0;
  if (m.status === 'brn' && !physical(m)) pen *= 0.3;
  if (m.status && toID(m.set.ability) === 'guts') pen = -0.1;
  if ((m.status === 'psn' || m.status === 'tox') && toID(m.set.ability) === 'poisonheal') pen = -0.1;
  v *= 1 - pen;
  return v;
}

function boostValue(m: WMon | undefined, W: Weights): number {
  if (!m?.alive) return 0;
  const b = m.boosts;
  const off = physical(m) ? (b.atk ?? 0) : (b.spa ?? 0);
  const x = off + 0.8 * (b.spe ?? 0) + 0.5 * ((b.def ?? 0) + (b.spd ?? 0)) + 0.3 * ((b.accuracy ?? 0) - 0 + (b.evasion ?? 0));
  // 체감: 높을수록 효용 감소
  return W.boost * Math.sign(x) * Math.sqrt(Math.abs(x)) * 2;
}

function hazardCost(s: WSide, W: Weights): number {
  let hp = 0;
  s.mons.forEach((m, i) => {
    if (!m.alive || i === s.active) return;
    const t = typesOf(m);
    if (s.hazards.stealthrock) hp += 12.5 * Math.pow(2, dex.getEffectiveness('Rock', t));
    if (s.hazards.spikes && !t.includes('Flying')) hp += [0, 12.5, 16.7, 25][s.hazards.spikes];
  });
  return W.hazard * hp;
}

/** 대면 유불리: 서로 몇 턴에 쓰러뜨리는지 (−1~1) */
export function matchupTerm(w: World): number {
  const a = activeOf(w.sides[0]), b = activeOf(w.sides[1]);
  if (!a?.alive || !b?.alive) return 0;
  const mine = Math.max(0.5, bestDamage(w, 0)), theirs = Math.max(0.5, bestDamage(w, 1));
  const myTurns = Math.ceil(b.hp / mine), theirTurns = Math.ceil(a.hp / theirs);
  const first = order(w, 0, 0) > 0;
  let d = theirTurns - myTurns + (myTurns === theirTurns ? (first ? 0.5 : -0.5) : 0);
  d = Math.max(-3, Math.min(3, d));
  return d / 3;
}

export function evaluate(w: World, W: Weights = DEFAULT_WEIGHTS): number {
  const [me, op] = w.sides;
  const aMe = aliveCount(me), aOp = aliveCount(op);
  if (aOp === 0 && aMe > 0) return W.win + aMe;
  if (aMe === 0 && aOp > 0) return -W.win - aOp;
  if (aMe === 0 && aOp === 0) return 0;
  let v = 0;
  for (const m of me.mons) v += monValue(m, W);
  for (const m of op.mons) v -= monValue(m, W);
  v += W.matchup * matchupTerm(w);
  v += boostValue(activeOf(me), W) - boostValue(activeOf(op), W);
  v += hazardCost(op, W) - hazardCost(me, W);
  const sc = (s: WSide) => s.screens.reflect + s.screens.lightscreen + s.screens.auroraveil + s.screens.tailwind;
  v += W.screen * (sc(me) - sc(op));
  return v;
}
