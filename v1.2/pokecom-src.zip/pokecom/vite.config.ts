import { defineConfig, type Plugin } from 'vite';
import fs from 'node:fs';
import path from 'node:path';

// 빌드 결과물 목록으로 sw.js 를 만든다 (오프라인 프리캐시)
function serviceWorker(): Plugin {
	return {
		name: 'pokecom-sw',
		apply: 'build',
		writeBundle(opts, bundle) {
			const out = opts.dir!;
			const files = ['./', 'index.html', 'manifest.webmanifest', 'icon.svg', 'icon-192.png', 'icon-180.png',
				...Object.keys(bundle).filter(f => !f.endsWith('.map'))];
			const version = Date.now().toString(36);
			const tpl = fs.readFileSync(path.resolve('scripts/sw.template.js'), 'utf8');
			fs.writeFileSync(path.join(out, 'sw.js'), tpl.replace('__VERSION__', version).replace('__FILES__', JSON.stringify([...new Set(files)])));
		},
	};
}

export default defineConfig({
	base: './',
	// minify 끔: 시뮬레이터 번들은 이미 압축돼 있고, 다시 압축하면 클래스 이름이 사라져 State(L3 탐색)가 깨진다
	build: { target: 'es2022', chunkSizeWarningLimit: 6000, assetsInlineLimit: 0, assetsDir: '', minify: false },
	plugins: [serviceWorker()],
});
