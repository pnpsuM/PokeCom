// Pokémon Showdown(master) 시뮬레이터를 브라우저용 ESM 하나로 묶는다.
// 사용: PS_DIR=/path/to/pokemon-showdown node scripts/build-sim.mjs
// - base(gen9) 데이터 + champions 모드만 포함
// - 동적 require / fs / path 를 정적 레지스트리로 바꾼다
// - 포맷 목록은 src/sim-formats.ts 로 대체
import * as esbuild from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';

const PS = path.resolve(process.env.PS_DIR || '/tmp/ps');
const ROOT = path.resolve(import.meta.dirname, '..');
const MODS = ['champions'];
const DATA_FILES = ['abilities', 'rulesets', 'formats-data', 'items', 'learnsets', 'moves', 'natures',
	'pokedex', 'pokemongo', 'scripts', 'conditions', 'typechart'];
const TEXT_FILES = ['abilities', 'default', 'items', 'moves', 'pokedex'];

// 레지스트리 모듈 생성
let reg = `const R = Object.create(null);\n`;
let n = 0;
const add = (key, file) => {
	if (!fs.existsSync(file)) return;
	const v = `m${n++}`;
	reg = `import * as ${v} from ${JSON.stringify(file)};\n` + reg + `R[${JSON.stringify(key)}] = ${v};\n`;
};
// base learnsets(3.7MB)는 빼고 champions 모드 learnsets 만 쓴다
for (const f of DATA_FILES) if (f !== 'learnsets') add(`/ps/data/${f}`, `${PS}/data/${f}.ts`);
add('/ps/data/aliases', `${PS}/data/aliases.ts`);
for (const m of MODS) for (const f of DATA_FILES) add(`/ps/data/mods/${m}/${f}`, `${PS}/data/mods/${m}/${f}.ts`);
for (const f of TEXT_FILES) add(`/ps/data/text/${f}`, `${PS}/data/text/${f}.ts`);
add('/ps/config/formats', path.join(ROOT, 'src/sim-formats.ts'));
reg += `
function req(p) {
	p = p.replace(/\\.(ts|js)$/, '');
	const m = R[p];
	if (!m) { const e = new Error('Cannot find module ' + p); e.code = 'MODULE_NOT_FOUND'; throw e; }
	return m;
}
req.resolve = (p) => { req(p); return p; };
globalThis.__PS_REQ = req;
globalThis.__PS_MODS = ${JSON.stringify(MODS)};
`;
const regFile = path.join(ROOT, 'scripts/.ps-registry.mjs');
fs.writeFileSync(regFile, reg);

const entry = path.join(ROOT, 'scripts/.ps-entry.ts');
fs.writeFileSync(entry, `
import ${JSON.stringify(regFile)};
export { Dex, toID } from ${JSON.stringify(PS + '/sim/dex')};
export { BattleStream, getPlayerStreams } from ${JSON.stringify(PS + '/sim/battle-stream')};
export { Teams } from ${JSON.stringify(PS + '/sim/teams')};
export { TeamValidator } from ${JSON.stringify(PS + '/sim/team-validator')};
export { PRNG } from ${JSON.stringify(PS + '/sim/prng')};
export { Battle } from ${JSON.stringify(PS + '/sim/battle')};
export { State } from ${JSON.stringify(PS + '/sim/state')};
export { RandomChampionsTeams } from ${JSON.stringify(PS + '/data/random-battles/champions/teams')};
`);

const shimDir = path.join(ROOT, 'scripts/shims');
fs.mkdirSync(shimDir, { recursive: true });
fs.writeFileSync(path.join(shimDir, 'path.js'), `
function norm(p) { const out = []; for (const s of p.split('/')) { if (!s || s === '.') continue; if (s === '..') out.pop(); else out.push(s); } return '/' + out.join('/'); }
export function resolve(...ps) { let r = ''; for (const p of ps) r = p.startsWith('/') ? p : r + '/' + p; return norm(r); }
export function join(...ps) { return norm(ps.join('/')); }
export function dirname(p) { return norm(p + '/..'); }
export function basename(p) { return p.split('/').pop(); }
export const sep = '/';
export default { resolve, join, dirname, basename, sep };
`);
fs.writeFileSync(path.join(shimDir, 'fs.js'), `
export function readdirSync() { return globalThis.__PS_MODS; }
export function existsSync() { return false; }
export default { readdirSync, existsSync };
`);
fs.writeFileSync(path.join(shimDir, 'util.js'), `
export function isDeepStrictEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== 'object' || typeof b !== 'object' || !a || !b) return false;
	if (Array.isArray(a) !== Array.isArray(b)) return false;
	const ka = Object.keys(a), kb = Object.keys(b);
	if (ka.length !== kb.length) return false;
	return ka.every(k => isDeepStrictEqual(a[k], b[k]));
}
export default { isDeepStrictEqual };
`);
fs.writeFileSync(path.join(shimDir, 'empty.json'), '{"matchups":{}}');
fs.writeFileSync(path.join(shimDir, 'empty.js'), 'export default {};\n');
fs.writeFileSync(path.join(shimDir, 'lib.ts'), `
export * as Streams from ${JSON.stringify(PS + '/lib/streams')};
export * as Utils from ${JSON.stringify(PS + '/lib/utils')};
`);

const patchPlugin = {
	name: 'ps-patch',
	setup(build) {
		build.onResolve({ filter: /^(path|node:path)$/ }, () => ({ path: path.join(shimDir, 'path.js') }));
		build.onResolve({ filter: /^(fs|node:fs)$/ }, () => ({ path: path.join(shimDir, 'fs.js') }));
		// gen9 랜덤 배틀 세트(json)는 champions 가 덮어쓰므로 비운다
		build.onResolve({ filter: /\.json$/ }, (a) => a.importer.endsWith('random-battles/gen9/teams.ts') ? { path: path.join(shimDir, 'empty.json') } : undefined);
		build.onResolve({ filter: /^node:util$/ }, () => ({ path: path.join(shimDir, 'util.js') }));
		build.onResolve({ filter: /^node:crypto$/ }, () => ({ path: path.join(shimDir, 'empty.js') }));
		build.onResolve({ filter: /(^|\/)lib$/ }, (a) => path.resolve(a.resolveDir, a.path) === PS + '/lib' ? { path: path.join(shimDir, 'lib.ts') } : undefined);
		build.onLoad({ filter: /sim\/(dex|dex-formats|dex-text|teams)\.ts$/ }, (a) => {
			let src = fs.readFileSync(a.path, 'utf8');
			src = src.replace(/\brequire\.resolve\(/g, '__PS_REQ.resolve(').replace(/\brequire\(/g, '__PS_REQ(');
			src = src.replace(/\$\{__dirname\}\/\.\.\/config\/custom-formats/, '/ps/config/custom-formats');
			src = src.replace(/\$\{__dirname\}\/\.\.\/config\/formats/, '/ps/config/formats');
			return { contents: src, loader: 'ts' };
		});
	},
};

await esbuild.build({
	entryPoints: [entry],
	bundle: true,
	format: 'esm',
	platform: 'browser',
	target: 'es2022',
	outfile: path.join(ROOT, 'vendor/ps-sim.js'),
	define: { __dirname: '"/ps/sim"', 'process.env.NODE_ENV': '"production"' },
	plugins: [patchPlugin],
	nodePaths: [path.join(ROOT, 'node_modules')],
	minify: true,
	keepNames: true, // State(직렬화)가 클래스 이름으로 참조를 만든다 — L3 탐색에 필요
	legalComments: 'eof',
	logLevel: 'warning',
	banner: { js: `// Pokémon Showdown simulator (MIT) — bundled for PokeCom. Commit ${process.env.PS_COMMIT || ''}\nvar process = globalThis.process || { env: {}, platform: 'browser', version: '', versions: {}, argv: [], exit(){}, on(){}, nextTick: (f, ...a) => Promise.resolve().then(() => f(...a)) };` },
});
const st = fs.statSync(path.join(ROOT, 'vendor/ps-sim.js'));
console.log('vendor/ps-sim.js', (st.size / 1e6).toFixed(2), 'MB');
