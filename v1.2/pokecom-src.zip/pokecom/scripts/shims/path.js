
function norm(p) { const out = []; for (const s of p.split('/')) { if (!s || s === '.') continue; if (s === '..') out.pop(); else out.push(s); } return '/' + out.join('/'); }
export function resolve(...ps) { let r = ''; for (const p of ps) r = p.startsWith('/') ? p : r + '/' + p; return norm(r); }
export function join(...ps) { return norm(ps.join('/')); }
export function dirname(p) { return norm(p + '/..'); }
export function basename(p) { return p.split('/').pop(); }
export const sep = '/';
export default { resolve, join, dirname, basename, sep };
