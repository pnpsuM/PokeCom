
export function readdirSync() { return globalThis.__PS_MODS; }
export function existsSync() { return false; }
export default { readdirSync, existsSync };
