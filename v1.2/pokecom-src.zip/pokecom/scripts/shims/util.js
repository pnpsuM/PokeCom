
export function isDeepStrictEqual(a, b) {
	if (a === b) return true;
	if (typeof a !== 'object' || typeof b !== 'object' || !a || !b) return false;
	if (Array.isArray(a) !== Array.isArray(b)) return false;
	const ka = Object.keys(a), kb = Object.keys(b);
	if (ka.length !== kb.length) return false;
	return ka.every(k => isDeepStrictEqual(a[k], b[k]));
}
export default { isDeepStrictEqual };
